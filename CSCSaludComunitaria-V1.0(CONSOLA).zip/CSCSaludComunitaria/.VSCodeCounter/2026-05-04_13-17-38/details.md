# Details

Date : 2026-05-04 13:17:38

Directory g:\\Proyectos Prog\\POO CLASE\\CSCSaludComunitaria

Total : 67 files,  2821 codes, 37 comments, 449 blanks, all 3307 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [DIAGRAMA.md](/DIAGRAMA.md) | Markdown | 165 | 0 | 6 | 171 |
| [PROYECTO\_FINAL\_CURSO\_JAVA.md](/PROYECTO_FINAL_CURSO_JAVA.md) | Markdown | 147 | 0 | 59 | 206 |
| [pom.xml](/pom.xml) | XML | 20 | 0 | 1 | 21 |
| [src/main/java/Model/Citas/CitaMedica.java](/src/main/java/Model/Citas/CitaMedica.java) | Java | 26 | 0 | 6 | 32 |
| [src/main/java/Model/Citas/Citas.java](/src/main/java/Model/Citas/Citas.java) | Java | 76 | 0 | 25 | 101 |
| [src/main/java/Model/Citas/Consultorio.java](/src/main/java/Model/Citas/Consultorio.java) | Java | 31 | 0 | 12 | 43 |
| [src/main/java/Model/Citas/ConsultorioGeneral.java](/src/main/java/Model/Citas/ConsultorioGeneral.java) | Java | 14 | 0 | 4 | 18 |
| [src/main/java/Model/HistoriaClinica/EntradaMedica.java](/src/main/java/Model/HistoriaClinica/EntradaMedica.java) | Java | 20 | 0 | 5 | 25 |
| [src/main/java/Model/HistoriaClinica/HistoriaClinica.java](/src/main/java/Model/HistoriaClinica/HistoriaClinica.java) | Java | 25 | 0 | 7 | 32 |
| [src/main/java/Model/Persona/Administrador.java](/src/main/java/Model/Persona/Administrador.java) | Java | 19 | 0 | 5 | 24 |
| [src/main/java/Model/Persona/Enfermero.java](/src/main/java/Model/Persona/Enfermero.java) | Java | 19 | 0 | 7 | 26 |
| [src/main/java/Model/Persona/Medico.java](/src/main/java/Model/Persona/Medico.java) | Java | 35 | 0 | 13 | 48 |
| [src/main/java/Model/Persona/Paciente.java](/src/main/java/Model/Persona/Paciente.java) | Java | 33 | 0 | 11 | 44 |
| [src/main/java/Model/Persona/Persona.java](/src/main/java/Model/Persona/Persona.java) | Java | 78 | 8 | 24 | 110 |
| [src/main/java/Model/Persona/Trabajador.java](/src/main/java/Model/Persona/Trabajador.java) | Java | 63 | 0 | 21 | 84 |
| [src/main/java/Model/ServiciosCSC/ConsultaGeneral.java](/src/main/java/Model/ServiciosCSC/ConsultaGeneral.java) | Java | 8 | 0 | 5 | 13 |
| [src/main/java/Model/ServiciosCSC/ExamenLaboratorio.java](/src/main/java/Model/ServiciosCSC/ExamenLaboratorio.java) | Java | 13 | 0 | 5 | 18 |
| [src/main/java/Model/ServiciosCSC/ServicioSalud.java](/src/main/java/Model/ServiciosCSC/ServicioSalud.java) | Java | 5 | 0 | 2 | 7 |
| [src/main/java/Servicios/AuditoriaSistema.java](/src/main/java/Servicios/AuditoriaSistema.java) | Java | 16 | 1 | 5 | 22 |
| [src/main/java/Servicios/GestionCitas/GestionCitas.java](/src/main/java/Servicios/GestionCitas/GestionCitas.java) | Java | 153 | 0 | 20 | 173 |
| [src/main/java/Servicios/GestionHistoriaClinica/GestionHistoriaClinica.java](/src/main/java/Servicios/GestionHistoriaClinica/GestionHistoriaClinica.java) | Java | 117 | 1 | 18 | 136 |
| [src/main/java/Servicios/GestionPersona/ActualizarPersona.java](/src/main/java/Servicios/GestionPersona/ActualizarPersona.java) | Java | 109 | 4 | 31 | 144 |
| [src/main/java/Servicios/GestionPersona/BuscarPersona.java](/src/main/java/Servicios/GestionPersona/BuscarPersona.java) | Java | 56 | 4 | 11 | 71 |
| [src/main/java/Servicios/GestionPersona/EliminarPersona.java](/src/main/java/Servicios/GestionPersona/EliminarPersona.java) | Java | 37 | 2 | 11 | 50 |
| [src/main/java/Servicios/GestionPersona/MostrarPersona.java](/src/main/java/Servicios/GestionPersona/MostrarPersona.java) | Java | 76 | 0 | 7 | 83 |
| [src/main/java/Servicios/GestionPersona/RegistrosPersonas.java](/src/main/java/Servicios/GestionPersona/RegistrosPersonas.java) | Java | 141 | 3 | 34 | 178 |
| [src/main/java/Servicios/Notificaciones.java](/src/main/java/Servicios/Notificaciones.java) | Java | 27 | 1 | 6 | 34 |
| [src/main/java/Servicios/ServiciosPersona.java](/src/main/java/Servicios/ServiciosPersona.java) | Java | 116 | 0 | 26 | 142 |
| [src/main/java/Utils/MenuClinico.java](/src/main/java/Utils/MenuClinico.java) | Java | 28 | 0 | 5 | 33 |
| [src/main/java/Utils/MenuServiciosMEdicos.java](/src/main/java/Utils/MenuServiciosMEdicos.java) | Java | 27 | 0 | 11 | 38 |
| [src/main/java/Utils/SimulacionDemo.java](/src/main/java/Utils/SimulacionDemo.java) | Java | 58 | 4 | 9 | 71 |
| [src/main/java/Utils/UtilServices.java](/src/main/java/Utils/UtilServices.java) | Java | 38 | 0 | 9 | 47 |
| [src/main/java/Utils/ValidadorEntrada.java](/src/main/java/Utils/ValidadorEntrada.java) | Java | 15 | 0 | 4 | 19 |
| [src/main/java/Utils/menuGestionPersonas.java](/src/main/java/Utils/menuGestionPersonas.java) | Java | 60 | 3 | 9 | 72 |
| [src/main/java/com/mycompany/cscsaludcomunitaria/CSCSaludComunitaria.java](/src/main/java/com/mycompany/cscsaludcomunitaria/CSCSaludComunitaria.java) | Java | 56 | 0 | 10 | 66 |
| [target/classes/Model/Citas/CitaMedica.class](/target/classes/Model/Citas/CitaMedica.class) | Java | 29 | 0 | 0 | 29 |
| [target/classes/Model/Citas/Citas.class](/target/classes/Model/Citas/Citas.class) | Java | 25 | 0 | 0 | 25 |
| [target/classes/Model/Citas/Consultorio.class](/target/classes/Model/Citas/Consultorio.class) | Java | 11 | 0 | 0 | 11 |
| [target/classes/Model/Citas/ConsultorioGeneral.class](/target/classes/Model/Citas/ConsultorioGeneral.class) | Java | 15 | 0 | 0 | 15 |
| [target/classes/Model/HistoriaClinica/EntradaMedica.class](/target/classes/Model/HistoriaClinica/EntradaMedica.class) | Java | 6 | 0 | 0 | 6 |
| [target/classes/Model/HistoriaClinica/HistoriaClinica.class](/target/classes/Model/HistoriaClinica/HistoriaClinica.class) | Java | 13 | 0 | 0 | 13 |
| [target/classes/Model/Persona/Administrador.class](/target/classes/Model/Persona/Administrador.class) | Java | 12 | 0 | 0 | 12 |
| [target/classes/Model/Persona/Enfermero.class](/target/classes/Model/Persona/Enfermero.class) | Java | 12 | 0 | 0 | 12 |
| [target/classes/Model/Persona/Medico.class](/target/classes/Model/Persona/Medico.class) | Java | 12 | 0 | 0 | 12 |
| [target/classes/Model/Persona/Paciente.class](/target/classes/Model/Persona/Paciente.class) | Java | 17 | 0 | 0 | 17 |
| [target/classes/Model/Persona/Persona.class](/target/classes/Model/Persona/Persona.class) | Java | 23 | 0 | 0 | 23 |
| [target/classes/Model/Persona/Trabajador.class](/target/classes/Model/Persona/Trabajador.class) | Java | 26 | 0 | 0 | 26 |
| [target/classes/Model/ServiciosCSC/ConsultaGeneral.class](/target/classes/Model/ServiciosCSC/ConsultaGeneral.class) | Java | 8 | 0 | 0 | 8 |
| [target/classes/Model/ServiciosCSC/ExamenLaboratorio.class](/target/classes/Model/ServiciosCSC/ExamenLaboratorio.class) | Java | 16 | 0 | 0 | 16 |
| [target/classes/Model/ServiciosCSC/ServicioSalud.class](/target/classes/Model/ServiciosCSC/ServicioSalud.class) | Java | 2 | 0 | 1 | 3 |
| [target/classes/Servicios/AuditoriaSistema.class](/target/classes/Servicios/AuditoriaSistema.class) | Java | 28 | 0 | 0 | 28 |
| [target/classes/Servicios/GestionCitas/GestionCitas.class](/target/classes/Servicios/GestionCitas/GestionCitas.class) | Java | 73 | 0 | 0 | 73 |
| [target/classes/Servicios/GestionHistoriaClinica/GestionHistoriaClinica.class](/target/classes/Servicios/GestionHistoriaClinica/GestionHistoriaClinica.class) | Java | 66 | 0 | 0 | 66 |
| [target/classes/Servicios/GestionPersona/ActualizarPersona.class](/target/classes/Servicios/GestionPersona/ActualizarPersona.class) | Java | 74 | 0 | 0 | 74 |
| [target/classes/Servicios/GestionPersona/BuscarPersona.class](/target/classes/Servicios/GestionPersona/BuscarPersona.class) | Java | 33 | 0 | 0 | 33 |
| [target/classes/Servicios/GestionPersona/EliminarPersona.class](/target/classes/Servicios/GestionPersona/EliminarPersona.class) | Java | 27 | 0 | 0 | 27 |
| [target/classes/Servicios/GestionPersona/MostrarPersona.class](/target/classes/Servicios/GestionPersona/MostrarPersona.class) | Java | 54 | 0 | 4 | 58 |
| [target/classes/Servicios/GestionPersona/RegistrosPersonas.class](/target/classes/Servicios/GestionPersona/RegistrosPersonas.class) | Java | 56 | 0 | 0 | 56 |
| [target/classes/Servicios/Notificaciones.class](/target/classes/Servicios/Notificaciones.class) | Java | 18 | 0 | 0 | 18 |
| [target/classes/Servicios/ServiciosPersona.class](/target/classes/Servicios/ServiciosPersona.class) | Java | 40 | 0 | 0 | 40 |
| [target/classes/Utils/MenuClinico.class](/target/classes/Utils/MenuClinico.class) | Java | 14 | 0 | 0 | 14 |
| [target/classes/Utils/MenuServiciosMEdicos.class](/target/classes/Utils/MenuServiciosMEdicos.class) | Java | 17 | 0 | 0 | 17 |
| [target/classes/Utils/SimulacionDemo.class](/target/classes/Utils/SimulacionDemo.class) | Java | 86 | 0 | 0 | 86 |
| [target/classes/Utils/UtilServices.class](/target/classes/Utils/UtilServices.class) | Java | 12 | 6 | 0 | 18 |
| [target/classes/Utils/ValidadorEntrada.class](/target/classes/Utils/ValidadorEntrada.class) | Java | 17 | 0 | 0 | 17 |
| [target/classes/Utils/menuGestionPersonas.class](/target/classes/Utils/menuGestionPersonas.class) | Java | 29 | 0 | 0 | 29 |
| [target/classes/com/mycompany/cscsaludcomunitaria/CSCSaludComunitaria.class](/target/classes/com/mycompany/cscsaludcomunitaria/CSCSaludComunitaria.class) | Java | 23 | 0 | 0 | 23 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)