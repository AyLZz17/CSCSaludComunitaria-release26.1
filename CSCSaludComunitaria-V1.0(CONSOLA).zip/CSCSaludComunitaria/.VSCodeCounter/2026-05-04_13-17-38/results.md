# Summary

Date : 2026-05-04 13:17:38

Directory g:\\Proyectos Prog\\POO CLASE\\CSCSaludComunitaria

Total : 67 files,  2821 codes, 37 comments, 449 blanks, all 3307 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 64 | 2,489 | 37 | 383 | 2,909 |
| Markdown | 2 | 312 | 0 | 65 | 377 |
| XML | 1 | 20 | 0 | 1 | 21 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 67 | 2,821 | 37 | 449 | 3,307 |
| . (Files) | 3 | 332 | 0 | 66 | 398 |
| src | 32 | 1,595 | 31 | 378 | 2,004 |
| src\\main | 32 | 1,595 | 31 | 378 | 2,004 |
| src\\main\\java | 32 | 1,595 | 31 | 378 | 2,004 |
| src\\main\\java\\Model | 15 | 465 | 8 | 152 | 625 |
| src\\main\\java\\Model\\Citas | 4 | 147 | 0 | 47 | 194 |
| src\\main\\java\\Model\\HistoriaClinica | 2 | 45 | 0 | 12 | 57 |
| src\\main\\java\\Model\\Persona | 6 | 247 | 8 | 81 | 336 |
| src\\main\\java\\Model\\ServiciosCSC | 3 | 26 | 0 | 12 | 38 |
| src\\main\\java\\Servicios | 10 | 848 | 16 | 169 | 1,033 |
| src\\main\\java\\Servicios (Files) | 3 | 159 | 2 | 37 | 198 |
| src\\main\\java\\Servicios\\GestionCitas | 1 | 153 | 0 | 20 | 173 |
| src\\main\\java\\Servicios\\GestionHistoriaClinica | 1 | 117 | 1 | 18 | 136 |
| src\\main\\java\\Servicios\\GestionPersona | 5 | 419 | 13 | 94 | 526 |
| src\\main\\java\\Utils | 6 | 226 | 7 | 47 | 280 |
| src\\main\\java\\com | 1 | 56 | 0 | 10 | 66 |
| src\\main\\java\\com\\mycompany | 1 | 56 | 0 | 10 | 66 |
| src\\main\\java\\com\\mycompany\\cscsaludcomunitaria | 1 | 56 | 0 | 10 | 66 |
| target | 32 | 894 | 6 | 5 | 905 |
| target\\classes | 32 | 894 | 6 | 5 | 905 |
| target\\classes\\Model | 15 | 227 | 0 | 1 | 228 |
| target\\classes\\Model\\Citas | 4 | 80 | 0 | 0 | 80 |
| target\\classes\\Model\\HistoriaClinica | 2 | 19 | 0 | 0 | 19 |
| target\\classes\\Model\\Persona | 6 | 102 | 0 | 0 | 102 |
| target\\classes\\Model\\ServiciosCSC | 3 | 26 | 0 | 1 | 27 |
| target\\classes\\Servicios | 10 | 469 | 0 | 4 | 473 |
| target\\classes\\Servicios (Files) | 3 | 86 | 0 | 0 | 86 |
| target\\classes\\Servicios\\GestionCitas | 1 | 73 | 0 | 0 | 73 |
| target\\classes\\Servicios\\GestionHistoriaClinica | 1 | 66 | 0 | 0 | 66 |
| target\\classes\\Servicios\\GestionPersona | 5 | 244 | 0 | 4 | 248 |
| target\\classes\\Utils | 6 | 175 | 6 | 0 | 181 |
| target\\classes\\com | 1 | 23 | 0 | 0 | 23 |
| target\\classes\\com\\mycompany | 1 | 23 | 0 | 0 | 23 |
| target\\classes\\com\\mycompany\\cscsaludcomunitaria | 1 | 23 | 0 | 0 | 23 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)