# Proyecto final — Curso de Java  
## Estructura de datos, programación estructurada y programación orientada a objetos

**Institución:** Universidad de Ibagué — curso de Estructura y POO  
**Modalidad:** trabajo en equipo (máximo **3** estudiantes por grupo)  
**Plazo:** **15 días calendario** desde la fecha de publicación oficial del enunciado  
**Exposición de la aplicación (obligatoria):** **miércoles 6 de mayo de 2026** — cada grupo **expone y demuestra** el sistema en vivo (desde VS Code). Horario, sede o enlace virtual: según anuncio del docente.  
**Lenguaje:** **Java** (JDK 17 o superior recomendado)  
**Entorno obligatorio:** **Visual Studio Code** (extensión **Extension Pack for Java** de Microsoft u otra configuración equivalente aprobada por el docente). **Todas** las tareas de edición, compilación, depuración y ejecución se realizan en VS Code.  
**Interfaz:** únicamente **consola** (texto por teclado y pantalla).  
**Datos:** **solo en memoria** mientras el programa corre; **no** hay persistencia en disco de ningún tipo (véase sección 5.5).

---

## 1. Objetivo del proyecto

Diseñar e implementar un **sistema de software consola** (menús en texto) que resuelva una **problemática real** de un dominio concreto (salud, educación, biblioteca, inventario de un negocio pequeño, transporte urbano, voluntariado, medio ambiente local, etc.). El sistema debe ser **grande en alcance**: varios tipos de usuario, muchas entidades, reglas de negocio claras y uso intensivo de **colecciones en memoria** y **POO** con los cuatro pilares bien demostrados. Al cerrar el programa, **no** se conserva información en archivos ni en bases de datos.

Este proyecto integra **todo lo visto en el curso**:

- Fundamentos: tipos de datos, operadores, entrada/salida, control de flujo, métodos, arreglos.
- Programación estructurada: secuencia, selección, repetición, modularización, cohesión y acoplamiento razonables.
- POO: clases, objetos, constructores, sobrecarga, **encapsulación**, **herencia**, **polimorfismo** y **abstracción** (interfaces y/o clases abstractas).

---

## 2. Formación de equipos y plazo

| Aspecto | Regla |
|--------|--------|
| Integrantes | Mínimo 2, **máximo 3** por grupo |
| Plazo | **15 días** para avanzar código y documentación según el cronograma del curso |
| Exposición | **Miércoles 6 de mayo de 2026:** exposición oral y **demo en vivo** de la aplicación desde **VS Code** (flujos principales + preguntas sobre código, diagrama y reglas de negocio) |
| Repositorio | Un solo repositorio o carpeta comprimida por grupo, con historial de commits recomendado |

La fecha límite para **subir o entregar** informe, código y diagramas (si difiere de la exposición) la confirma el docente en clase o en el aula virtual.

Si un estudiante trabaja solo, debe cumplir **los mismos requisitos funcionales**; el docente puede ajustar criterios de extensión según política del curso.

---

## 3. Metodología obligatoria (orden de trabajo)

El trabajo **no** comienza por escribir código en Java. Cada grupo debe seguir **en este orden** y dejar evidencia en los entregables:

| Paso | Qué deben producir |
|------|---------------------|
| **1. Documento de narrativa y problema** | Un **documento de texto** (por ejemplo Word, PDF o equivalente) que incluya, **en este orden**: (a) **narrativa del problema**: contexto real, actores, situación actual y por qué importa; (b) **planteamiento del problema**: redacción clara del problema a resolver, alcance del sistema, qué queda **fuera** del alcance y qué resultado esperan los usuarios. |
| **2. Diagrama de clases en diagrams.net** | El **modelo conceptual en UML** (diagrama de clases) elaborado en **diagrams.net** (antes draw.io): clases principales, atributos relevantes, relaciones (asociación, herencia, interfaces). El diagrama debe ser **coherente** con el documento del paso 1 y **anterior** a la implementación completa (se permite refinarlo una vez iniciada la codificación, pero la entrega debe incluir la versión actualizada). |
| **3. Aplicación en Java** | La implementación en consola en VS Code según las secciones 5 y siguientes, **alineada** con el diagrama y el documento. |

**Nota:** guardar el diagrama como archivo **`.drawio`** (o `.drawio.png`) y adjuntarlo junto al informe, o incrustar una **imagen exportada** (PNG/PDF) en el PDF del informe. Eso es **documentación del proyecto**, no persistencia de datos de la aplicación.

---

## 4. Problemática real (elección del dominio)

Cada grupo elige **un solo dominio** y lo documenta en el informe. Ejemplos válidos (no limitativos):

1. **Centro de salud comunitario:** citas, historiales básicos, inventario de insumos, turnos de personal.  
2. **Biblioteca o centro de documentación:** préstamos, multas, catálogo, reservas, usuarios con diferentes perfiles.  
3. **Cooperativa o tienda de barrio:** proveedores, stock, ventas, clientes frecuentes, reportes simples.  
4. **Gestión académica simplificada:** programación de cursos, inscripciones, notas, asistencia (sin reemplazar sistemas institucionales reales; es un **modelo educativo**).  
5. **Transporte o logística local:** rutas, vehículos, mantenimientos, asignación de conductores.  
6. **ONG o campaña social:** voluntarios, proyectos, donaciones, asignación de tareas.  
7. **Parque ecológico o reciclaje:** registro de visitantes, eventos, métricas de residuos.

La narrativa y el planteamiento del problema (sección 3, paso 1) deben cubrir con suficiente detalle el contexto, los usuarios reales y el **dolor** que el sistema atenúa o resuelve; el informe final puede **incorporar** ese documento o referenciarlo como anexo.

---

## 5. Requisitos obligatorios de programación

### 5.1 Programación estructurada y fundamentos

- Menús jerárquicos en consola (al menos **dos niveles** de profundidad en varias ramas).  
- Validación de entradas (rangos, formatos, opciones inválidas, reintentos).  
- Uso consistente de **métodos estáticos** de utilidad donde tenga sentido (por ejemplo formateo, validación).  
- Al menos un uso justificado de **arreglos** además de colecciones (por ejemplo tabla fija de días, categorías predefinidas, o migración temporal a `ArrayList`).

### 5.2 Colecciones y datos en memoria

- Uso obligatorio de **`List`** (por ejemplo `ArrayList`) para gestionar conjuntos dinámicos de entidades principales.  
- Uso obligatorio de al menos **una** estructura adicional entre: `Set`, `Map`, cola o pila (justificar en informe para qué sirve en el dominio).  
- Operaciones típicas: agregar, buscar, modificar, eliminar (lógica o física), listar con filtros.

### 5.3 Programación orientada a objetos (cuatro pilares)

| Pilar | Qué deben demostrar |
|-------|---------------------|
| **Encapsulación** | Atributos `private`, acceso vía getters/setters o métodos de negocio; invariantes donde aplique. |
| **Herencia** | Mínimo **una jerarquía** de al menos **tres niveles** (clase base → intermedia → concreta) **o** dos jerarquías de dos niveles con roles distintos en el dominio. |
| **Polimorfismo** | Sobrescritura de métodos; uso de referencias de tipo superclase/interface que apunten a subclases; idealmente un método que procese una colección heterogénea con comportamiento distinto por tipo. |
| **Abstracción** | Mínimo **una interfaz** o **clase abstracta** con al menos dos implementaciones concretas distintas (por ejemplo distintos tipos de reporte, distintos roles de usuario, distintos tipos de pago o de notificación). |

### 5.4 Modelo de dominio (mínimos cuantitativos)

Para que el proyecto sea **extremadamente grande** en relación con un curso introductorio-intermedio, cada grupo debe cumplir **como mínimo**:

| Elemento | Mínimo sugerido |
|----------|-----------------|
| Clases de dominio (entidades / value objects) | **12** clases distintas (sin contar `Main` ni utilidades puras) |
| Relaciones entre entidades | Varias asociaciones (uno a muchos, muchos a muchos modelado con listas o mapas) |
| Estados, tipos o categorías fijas en el dominio | Al menos **4** conjuntos distintos de valores permitidos (por ejemplo estados de un préstamo, tipo de usuario, categoría de producto), modelados con `String` validada contra listas o arreglos de opciones, menús de selección numérica o constantes `public static final` |
| Casos de uso / flujos de menú | Al menos **25** operaciones distintas accesibles desde menús (altas, bajas, consultas, reportes, asignaciones, etc.) |
| Roles o tipos de usuario | Al menos **3** perfiles con menús o capacidades **claramente diferentes** (admin, operador, consulta, etc.) |
| Reglas de negocio explícitas | Al menos **8** reglas escritas en el informe e implementadas (ej.: no prestar si hay mora, stock no negativo, cupos, solapamiento de horarios) |
| Reportes o listados especiales | Al menos **5** reportes distintos (por fechas, por usuario, ranking, stock bajo, resumen financiero simple, etc.) |

Los números son **piso**, no techo: se espera que muchos equipos superen estos mínimos.

### 5.5 Persistencia (prohibida)

- **No** se permite guardar ni recuperar el estado del sistema desde **ningún** medio externo: **no** archivos de datos, **no** CSV, **no** bases de datos, **no** serialización Java (`ObjectOutputStream` / `ObjectInputStream`, `Serializable`, etc.), **no** lectura/escritura de ficheros para persistir entidades, usuarios ni reportes.  
- Toda la información vive en **objetos y colecciones en memoria** durante la sesión de ejecución.  
- Sí está permitida la **entrada y salida por consola** (`Scanner`, `System.out`, etc.) para interactuar con el usuario; eso **no** cuenta como persistencia.

### 5.6 Calidad y organización del código

- Paquetes Java (`package`) separando al menos: `modelo`, `servicio` o `logica`, `vista` o `consola`, `util` (nombres pueden adaptarse).  
- Nombres en español o inglés, pero **consistentes**.  
- Evitar clases “dios” de miles de líneas: repartir responsabilidades.  
- Manejo básico de excepciones donde haya lectura desde consola o parseo de números/fechas.

---

## 6. Entregables

1. **Documento de narrativa y planteamiento del problema** (paso 1 de la sección 3): mismo contenido exigido allí; puede entregarse como **archivo aparte** (PDF o Word) o como **primeras secciones** del informe en PDF.  
2. **Diagrama de clases en diagrams.net** (paso 2 de la sección 3): archivo fuente **`.drawio`** (o equivalente de diagrams.net) **más** una **exportación** incluida en el PDF del informe (por ejemplo PNG o PDF de varias páginas si el diagrama es grande). El diagrama debe reflejar el modelo que implementaron (o la versión final alineada con el código).  
3. **Código fuente** completo (paso 3), desarrollado y **probado en Visual Studio Code** (abrir la carpeta del proyecto en VS Code, compilar y ejecutar con **Run Java** o la terminal integrada del editor). No se exige Maven ni Gradle salvo que el docente lo indique.  
4. **Informe en PDF** (máx. 20–30 páginas recomendado), que integre o remita a lo anterior y además incluya:  
   - Portada, integrantes, dominio elegido.  
   - Narrativa + planteamiento del problema (si no van en archivo aparte).  
   - Diagrama de clases exportado desde **diagrams.net** (y, si cabe, enlace o nota al archivo `.drawio` entregado).  
   - Lista de casos de uso y capturas de pantalla de flujos de menú representativos.  
   - Tabla de **reglas de negocio** vs. ubicación en código (clase/método).  
   - Breve texto que relacione **diagrama ↔ código** (qué clases del diagrama corresponden a qué paquetes/archivos).  
   - Explicación de cómo se aplican los **cuatro pilares** del POO en el proyecto (con ejemplos concretos de clases).  
   - Instrucciones de ejecución **en VS Code** y datos de prueba (usuarios ficticios, contraseñas de demo si hay login simple); **aclarar** que los datos se pierden al cerrar la aplicación.  
5. **Exposición oral (obligatoria):** **miércoles 6 de mayo de 2026**. Cada grupo **expone la aplicación**: demo en vivo de los flujos principales **desde VS Code** y respuesta a preguntas sobre implementación, diagrama de clases y reglas de negocio. Confirmar con el docente si la entrega escrita/digital debe coincidir con esa fecha o anticiparse.

---

## 7. Ideas de módulos para ampliar el alcance (elegir varios)

Los equipos pueden combinar módulos según su dominio; la lista ayuda a asegurar un proyecto **grande**:

- Autenticación simple (usuario/contraseña **solo en memoria**, precargados o dados de alta en la misma sesión).  
- Auditoría básica (lista de eventos en memoria: quién hizo qué y cuándo).  
- Búsqueda avanzada (múltiples criterios combinados).  
- Reportes mostrados **solo por consola** (sin guardar el resultado en disco).  
- Simulación de un día de operación (carga masiva ficticia o “modo demo” en memoria).  
- Gestión de excepciones o feriados que afectan reglas (ej.: no hay atención ciertos días).  
- Múltiples sedes o bodegas con transferencias entre ellas.  
- Sistema de notificaciones en consola (cola de mensajes pendientes para el usuario).

---

## 8. Restricciones y buenas prácticas

- **Entorno:** el desarrollo y la entrega se alinean con **Visual Studio Code**; el informe debe permitir reproducir el proyecto abriendo la carpeta en VS Code.  
- **Interfaz:** únicamente **consola**; **no** Swing, JavaFX ni aplicaciones web.  
- **Persistencia:** **prohibida** (archivos, serialización, JDBC, etc.) para los **datos de la aplicación**; véase la sección 5.5. Quedan **excluidos** de esta prohibición los archivos de **documentación** del equipo (informe PDF, documento de narrativa/problema, diagrama `.drawio` e imágenes exportadas del diagrama).  
- **No** copiar proyectos completos de internet: el docente puede solicitar explicación línea por línea de partes críticas.  
- Citar en el informe cualquier fragmento de código o idea adaptada de fuentes externas.  
- Respetar datos personales: usar **datos ficticios** siempre.

---

## 9. Criterios de evaluación orientativos

| Criterio | Peso orientativo |
|----------|------------------|
| Cumplimiento funcional y tamaño del sistema | 35 % |
| Calidad del modelo OO (pilares, cohesión, claridad) | 30 % |
| Uso correcto de estructuras de datos y algoritmos básicos | 15 % |
| Informe, UML/diagramas y trazabilidad reglas–código | 15 % |
| Exposición (6 mayo 2026) / demo y preguntas | 5 % |

*(Los porcentajes los ajusta el docente según la rúbrica oficial del curso.)*

---

## 10. Checklist rápido antes de entregar

- [ ] **Orden metodológico respetado:** documento narrativa + problema → diagrama **diagrams.net** → aplicación Java (véase sección 3).  
- [ ] Entregados documento de problema, archivo **`.drawio`** y diagrama visible en el PDF.  
- [ ] Compila y ejecuta desde cero en **VS Code** en otra máquina siguiendo el informe.  
- [ ] **Sin** persistencia de datos de la app: no hay lectura/escritura de archivos para datos del sistema ni serialización.  
- [ ] Los tres perfiles de usuario se prueban con casos felices y de error.  
- [ ] Herencia, interfaz/clase abstracta y polimorfismo localizables y nombrados en el informe.  
- [ ] `List` + (`Map` o `Set` o cola/pila) en uso real, no decorativo.  
- [ ] Mínimo 25 operaciones de menú documentadas y probadas.  
- [ ] Reglas de negocio implementadas y no solo descritas.  
- [ ] Código ordenado en paquetes; sin credenciales reales.  
- [ ] Equipo listo para **exponer el miércoles 6 de mayo de 2026** (demo en VS Code + repaso del diagrama y del informe).

---

## 11. Mensaje final para los equipos

Este proyecto es **grande a propósito**: en 15 días, en grupo, deben planificar, dividir módulos, integrar menús y modelo de datos, y poder **explicar** cada decisión de diseño. La **exposición** está fijada para el **miércoles 6 de mayo de 2026**. La nota no depende solo de “que funcione”, sino de que el sistema sea **coherente**, **mantenible** y demuestre dominio de **Java**, **estructura** y **POO**.

**Éxitos en el proyecto final.**
