# CSC Salud Comunitaria - Sistema de Gestión de Centro de Salud

![Java](https://img.shields.io/badge/Java-25-blue) ![Maven](https://img.shields.io/badge/Maven-Enabled-green) ![License](https://img.shields.io/badge/License-Educational-orange)

---

## Tabla de Contenidos

1. [Descripción General](#descripción-general)
2. [Objetivo del Proyecto](#objetivo-del-proyecto)
3. [Problemática Real](#problemática-real)
4. [Características Principales](#características-principales)
5. [Arquitectura y Estructura](#arquitectura-y-estructura)
6. [Modelo de Datos](#modelo-de-datos)
7. [Pilares POO Implementados](#pilares-poo-implementados)
8. [Funcionalidades por Módulo](#funcionalidades-por-módulo)
9. [Reglas de Negocio](#reglas-de-negocio)
10. [Diagrama de Clases](#diagrama-de-clases)
11. [Guía de Instalación y Ejecución](#guía-de-instalación-y-ejecución)
12. [Datos de Prueba](#datos-de-prueba)
13. [Tecnologías y Dependencias](#tecnologías-y-dependencias)

---

## Descripción General

**CSC Salud Comunitaria** es un sistema integral de gestión para un centro de salud comunitario. La aplicación está diseñada completamente en **consola** (interfaz de texto) y permite administrar usuarios, servicios médicos, citas médicas, historiales clínicos, auditoría de eventos y notificaciones del sistema.

Toda la información se gestiona en **memoria RAM** durante la sesión de ejecución. Al cerrar el programa, los datos se pierden (no hay persistencia en archivos ni bases de datos, tal como se requiere en el proyecto académico).

---

## Objetivo del Proyecto

Este es el **Proyecto Final del Curso de Java** de la Universidad de Ibagué, donde se integran:

- **Programación Estructurada:** Menús jerárquicos, validación de entradas, métodos de utilidad.
- **Colecciones en Memoria:** `ArrayList`, `HashMap`, `Map` para gestión de datos.
- **Programación Orientada a Objetos (POO):** Implementación de los cuatro pilares (encapsulación, herencia, polimorfismo, abstracción).
- **Dominio Real:** Resuelve un problema real del sector salud.

---

## Problemática Real

### Contexto
Un **centro de salud comunitario** enfrenta desafíos en la organización y gestión de:
- Información de pacientes y personal médico
- Agendamiento y seguimiento de citas médicas
- Historiales clínicos de pacientes
- Servicios médicos y laboratorios
- Auditoría de acciones dentro del sistema
- Notificaciones y eventos importantes

### Solución
El sistema **CSC Salud Comunitaria** proporciona una plataforma centralizada que permite:
- Registrar y gestionar usuarios (pacientes, médicos, enfermeros, administradores)
- Administrar citas médicas con estado y confirmaciones
- Mantener historiales clínicos detallados
- Ofrecer diferentes servicios de salud con costos calculados
- Registrar y auditar todas las acciones en el sistema
- Gestionar notificaciones de eventos críticos

---

## Características Principales

✅ **Gestión de Usuarios (CRUD):** Registro, búsqueda, actualización y eliminación de pacientes, médicos y personal  
✅ **Servicios Médicos Polimórficos:** Diferentes tipos de servicios (consulta general, exámenes de laboratorio)  
✅ **Agendamiento de Citas:** Creación, confirmación y gestión de citas médicas  
✅ **Historiales Clínicos:** Registro de entradas médicas por paciente  
✅ **Sistema de Auditoría:** Registro de eventos en tiempo real con timestamp  
✅ **Notificaciones:** Cola de notificaciones para eventos importantes  
✅ **Validación Robusta:** Manejo seguro de entradas de usuario  
✅ **Datos de Demo:** Precarga de datos para pruebas rápidas  

---

## Arquitectura y Estructura

```
CSCSaludComunitaria/
├── pom.xml                           # Configuración Maven
├── PROYECTO_FINAL_CURSO_JAVA.md      # Requisitos del proyecto
├── README.md                         # Este archivo
└── src/main/java/
    ├── com/mycompany/cscsaludcomunitaria/
    │   └── CSCSaludComunitaria.java  # Clase principal (entrada)
    │
    ├── Model/                        # Modelos de dominio
    │   ├── Citas/                    # Gestión de citas
    │   │   ├── CitaMedica.java
    │   │   ├── Citas.java (abstracta)
    │   │   ├── Consultorio.java
    │   │   └── ConsultorioGeneral.java
    │   │
    │   ├── Persona/                  # Jerarquía de personas
    │   │   ├── Persona.java (clase base)
    │   │   ├── Trabajador.java
    │   │   ├── Paciente.java
    │   │   ├── Medico.java
    │   │   ├── Enfermero.java
    │   │   └── Administrador.java
    │   │
    │   ├── HistoriaClinica/          # Gestión clínica
    │   │   ├── HistoriaClinica.java
    │   │   └── EntradaMedica.java
    │   │
    │   └── ServiciosCSC/             # Servicios de salud
    │       ├── ServicioSalud.java (interfaz)
    │       ├── ConsultaGeneral.java
    │       └── ExamenLaboratorio.java
    │
    ├── Servicios/                    # Servicios del sistema
    │   ├── AuditoriaSistema.java     # Auditoría con Map
    │   ├── Notificaciones.java       # Cola de notificaciones
    │   ├── GestionCitas/
    │   │   └── GestionCitas.java
    │   ├── GestionHistoriaClinica/
    │   │   └── GestionHistoriaClinica.java
    │   └── GestionPersona/
    │       ├── ServiciosPersona.java
    │       ├── RegistrosPersonas.java
    │       ├── ActualizarPersona.java
    │       ├── BuscarPersona.java
    │       ├── EliminarPersona.java
    │       └── MostrarPersona.java
    │
    └── Utils/                        # Utilidades y menús
        ├── MenuClinico.java
        ├── MenuServiciosMedicos.java
        ├── menuGestionPersonas.java
        ├── ValidadorEntrada.java
        ├── UtilServices.java
        └── SimulacionDemo.java
```

---

## Modelo de Datos

### Jerarquía de Personas (Herencia)

```
Persona (clase base)
├── Trabajador
│   ├── Médico
│   └── Enfermero
│
└── Administrador (directa de Persona)
└── Paciente (directa de Persona)
```

**Persona** (clase base con encapsulación):
- `documentoIdentidad` (PK)
- `tipoDocumento`
- `nombreCompleto`
- `contacto`
- `edad`
- `generoNacimiento`
- `fechaNacimiento`
- `direccion`
- `lugarNacimiento`

**Trabajador** (extiende Persona):
- `cargo`
- `codigoTrabajador`
- `salario`
- `estadoContrato`
- `horario`
- `horarioRotativo`
- `turno` (Diurno, Nocturno, Mixto)

**Médico** (extiende Trabajador):
- `especialidad`
- `estadoLicencia`
- `consultorio`

**Enfermero** (extiende Trabajador):
- Hereda características de trabajador

**Paciente** (extiende Persona):
- `estadoCivil`
- `hijos`
- `eps` (entidad aseguradora)

**Administrador** (extiende Persona):
- Gestiona el sistema

### Entidades de Citas

**Consultorio:**
- `idConsultorio`
- `numeroConsultorio`
- `especialidad`
- `disponibilidad`

**Citas** (clase abstracta):
- `id`
- `fecha`
- `hora`
- `motivo`
- `estado` (Pendiente, Confirmada, Atendida, Cancelada)
- `idConsultorio`
- `idPaciente`
- `idMedico`

**CitaMedica** (extiende Citas):
- Implementa métodos específicos de citas médicas
- Permite confirmar citas

### Servicios de Salud (Interfaz - Polimorfismo)

**Interfaz ServicioSalud:**
- `calcularCostoFinal()` : double
- `obtenerDetalles()` : String

**Implementaciones:**
- **ConsultaGeneral:** 50,000 pesos
- **ExamenLaboratorio:** 80,000 pesos + costo de materiales

### Historia Clínica

**HistoriaClinica:**
- `idHistoria`
- `idPaciente`
- `entradas` (List de EntradaMedica)

**EntradaMedica:**
- `id`
- `diagnostico`
- `tratamiento`
- `medicamentos`
- `fecha`

---

## Pilares POO Implementados

### 1. **Encapsulación** ✅
- **Atributos privados** en todas las clases
- **Getters y Setters** para acceso controlado
- **Invariantes:** Validación de datos en constructores y setters

Ejemplo:
```java
public class Persona {
    private int documentoIdentidad;
    private String nombreCompleto;
    
    public void setDocumentoIdentidad(int doc) {
        if (doc > 0) this.documentoIdentidad = doc;
    }
}
```

### 2. **Herencia** ✅
- **3 niveles:** Persona → Trabajador → Médico (jerarquía profunda)
- **2 jerarquías:** Persona → Paciente y Persona → Administrador
- Reutilización de atributos y métodos

Estructura:
```java
public class Trabajador extends Persona { ... }
public class Medico extends Trabajador { ... }
public class Paciente extends Persona { ... }
```

### 3. **Polimorfismo** ✅
- **Sobrescritura de métodos:** Cada clase especializada define su comportamiento
- **Interfaz ServicioSalud:** Múltiples implementaciones (ConsultaGeneral, ExamenLaboratorio)
- **Procesamiento polimórfico:** 

```java
public class MenuServiciosMedicos {
    public static void procesarServicios(List<ServicioSalud> servicios) {
        for (ServicioSalud servicio : servicios) {
            System.out.println(servicio.obtenerDetalles());
            System.out.println("Costo: $" + servicio.calcularCostoFinal());
        }
    }
}
```

### 4. **Abstracción** ✅
- **Interfaz ServicioSalud:** Define el contrato para servicios de salud
- **Clase abstracta Citas:** Base para diferentes tipos de citas
- **Métodos abstractos:** `mostrarCitas()`, `confirmar()`

---

## Funcionalidades por Módulo

### 📋 Módulo 1: Gestión de Usuarios (CRUD Personas)

**Operaciones disponibles:**

| Operación | Descripción |
|-----------|-------------|
| **Registrar Usuario** | Crear nuevo paciente, médico, enfermero o administrador |
| **Buscar Persona** | Búsqueda por documento de identidad |
| **Listar Personas** | Mostrar todos los usuarios registrados |
| **Actualizar Persona** | Modificar datos de un usuario existente |
| **Eliminar Persona** | Dar de baja un usuario |

**Roles disponibles:**
- Paciente
- Médico (con especialidad)
- Enfermero
- Administrador

**Almacenamiento:** `ArrayList<Persona> personas`

---

### 🏥 Módulo 2: Servicios de Salud (Polimorfismo/Interfaz)

**Servicios disponibles:**

| Servicio | Costo | Detalles |
|----------|-------|---------|
| **Consulta General** | $50,000 | Atención médica básica |
| **Examen de Laboratorio** | $80,000 + materiales | Análisis clínicos especializados |

**Características:**
- Interfaz `ServicioSalud` define contrato
- Implementaciones concretas con cálculo de costos
- Procesamiento polimórfico de servicios

**Almacenamiento:** `ArrayList<ServicioSalud> servicios`

---

### 📅 Módulo 3: Gestión Clínica (Citas e Historia Clínica)

#### Gestión de Citas

**Operaciones:**
- Crear nueva cita
- Confirmar cita
- Listar citas por paciente
- Listar citas por médico
- Buscar cita por ID

**Estados de una cita:**
- Pendiente
- Confirmada
- Atendida
- Cancelada

**Almacenamiento:**
- `ArrayList<CitaMedica> citas`
- `ArrayList<Consultorio> consultorios`

#### Gestión de Historia Clínica

**Operaciones:**
- Crear historia clínica para paciente
- Agregar entrada médica a historia
- Consultar historial completo
- Ver diagnósticos por fecha

**Almacenamiento:** `ArrayList<HistoriaClinica> historiasClinicas`

---

### 🔍 Módulo 4: Auditoría del Sistema

**Características:**
- Registro de **todas las acciones** del sistema
- Timestamp automático con `LocalDateTime`
- Almacenamiento en `Map<Integer, String>`
- Visualización de logs completos

**Registro incluye:**
- Inicio/fin de aplicación
- Creación/modificación/eliminación de usuarios
- Citas confirmadas
- Servicios procesados
- Acciones administrativas

**Almacenamiento:** `HashMap<Integer, String> logs`

```java
public static void registrarAccion(String usuario, String accion) {
    String registro = "[" + LocalDateTime.now() + "] Usuario: " + usuario 
                    + " - Accion: " + accion;
    logs.put(contadorEvento++, registro);
}
```

---

### 🔔 Módulo 5: Notificaciones

**Características:**
- Cola de notificaciones tipo FIFO
- Procesamiento de notificaciones pendientes
- Eliminación de notificaciones
- Generación automática de eventos críticos

**Tipos de notificaciones:**
- Confirmación de cita
- Recordatorio de cita próxima
- Resultado de examen
- Avisos administrativos

**Almacenamiento:** `Queue<String> notificaciones` (LinkedList)

---

## Reglas de Negocio

| ID | Regla | Ubicación |
|----|-------|-----------|
| RN-01 | El documento de identidad es único (PK) | Servicios/GestionPersona |
| RN-02 | Un médico no puede tener más de 3 citas en el mismo día | GestionCitas |
| RN-03 | Una cita no puede programarse en fecha pasada | GestionCitas |
| RN-04 | La edad mínima de un paciente es 0 años | Servicios/GestionPersona |
| RN-05 | El salario de un trabajador debe ser positivo | Servicios/GestionPersona |
| RN-06 | Una cita debe ser confirmada antes de 24 horas | CitaMedica |
| RN-07 | No se puede eliminar un paciente con citas activas | Servicios/GestionPersona |
| RN-08 | El costo final de un servicio es calculado por el servicio | MenuServiciosMedicos |
| RN-09 | Solo administrador puede crear otros administradores | menuGestionPersonas |
| RN-10 | Cada entrada clínica debe tener diagnostico y tratamiento | EntradaMedica |

---

## Diagrama de Clases

### Estructura Conceptual

```
┌─────────────────────────┐
│       Persona           │
│  (clase base)           │
├─────────────────────────┤
│ - documentoIdentidad    │
│ - nombreCompleto        │
│ - edad                  │
│ - generoNacimiento      │
├─────────────────────────┤
│ + getters/setters       │
└──┬──────────────────────┘
   │
   ├─────────────────────┬──────────────────┬────────────────┐
   │                     │                  │                │
┌──▼──────────┐   ┌──────▼────────┐   ┌────▼───────┐   ┌───▼────────────┐
│ Trabajador  │   │   Paciente    │   │Administrador│  │   (otras)      │
│ (extend)    │   │   (extend)    │   │ (extend)   │   │                │
└──┬──────────┘   └───────────────┘   └────────────┘   └────────────────┘
   │
   ├──────────┬──────────────┐
   │          │              │
┌──▼────┐  ┌──▼─────┐   ┌───▼──────┐
│Medico │  │Enfermero│   │(extend)  │
│(extend)  │(extend) │   │          │
└────────┘  └─────────┘   └──────────┘


┌──────────────────────┐
│  ServicioSalud       │
│  (Interfaz)          │
├──────────────────────┤
│ + calcularCosto()    │
│ + obtenerDetalles()  │
└──┬───────────────────┘
   │
   ├──────────────────┬────────────────────────┐
   │                  │                        │
┌──▼──────────────┐ ┌─▼─────────────────┐
│ConsultaGeneral  │ │ ExamenLaboratorio │
│(implementa)     │ │ (implementa)      │
└─────────────────┘ └───────────────────┘


┌──────────────────┐
│  Citas (abstracta)
│                  │
├──────────────────┤
│ - id             │
│ - fecha          │
│ - estado         │
└──┬───────────────┘
   │
   └────────────┬──────────────┐
                │              │
           ┌────▼─────────┐
           │ CitaMedica   │
           │ (concreta)   │
           └──────────────┘


┌──────────────────┐
│ HistoriaClinica  │
├──────────────────┤
│ - idHistoria     │
│ - idPaciente     │
│ - entradas: List │
├──────────────────┤
│ + agregarEntrada │
└──────────────────┘

┌──────────────────┐
│ EntradaMedica    │
├──────────────────┤
│ - diagnostico    │
│ - tratamiento    │
│ - medicamentos   │
└──────────────────┘
```

---

## Guía de Instalación y Ejecución

### Requisitos Previos

- **Java 25** (o superior) - JDK instalado
- **Maven 3.8+** (opcional, pero recomendado)
- **Visual Studio Code** con extensión "Extension Pack for Java"

### Pasos de Instalación

#### Opción 1: Usando VS Code

1. **Abrir el proyecto:**
   ```bash
   cd c:\Users\Sofia\Documents\POO\CSCSaludComunitaria-V1.0\CSCSaludComunitaria
   ```

2. **Abrir en VS Code:**
   ```bash
   code .
   ```

3. **Compilar el proyecto:**
   - Presionar `Ctrl + Shift + P`
   - Buscar y ejecutar: `Java: Build Project`
   - O usar la terminal: `mvn clean compile`

4. **Ejecutar la aplicación:**
   - Click en **Run** sobre la clase `CSCSaludComunitaria.java`
   - O en terminal: `mvn exec:java`

#### Opción 2: Usando Terminal

```bash
# Compilar
javac -d target/classes -cp ".:lib/*" src/main/java/**/*.java

# Ejecutar
java -cp target/classes com.mycompany.cscsaludcomunitaria.CSCSaludComunitaria
```

#### Opción 3: Con Maven

```bash
# Limpiar y compilar
mvn clean compile

# Ejecutar
mvn exec:java

# O empaquetar como JAR
mvn package
java -jar target/CSCSaludComunitaria-SNAPSHOT-1.0.jar
```

---

## Flujo de Ejecución Principal

```
┌─────────────────────────────────┐
│  INICIO APLICACIÓN              │
│  CSCSaludComunitaria.main()     │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│ 1. Registrar inicio en auditoría│
│    AuditoriaSistema.registrar() │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│ 2. Cargar datos de demostración │
│    SimulacionDemo.cargarDatos() │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│ 3. MENÚ PRINCIPAL (bucle)       │
│   Mostrar opciones:             │
│   1. Gestión de usuarios        │
│   2. Servicios de salud         │
│   3. Gestión clínica            │
│   4. Ver auditoría              │
│   5. Procesar notificaciones    │
│   6. Eliminar notificación      │
│   0. Salir                      │
└────────────┬────────────────────┘
             │
        ┌────┴────────────────────────┐
        │ switch(opcion)              │
        └──┬──────────────────────────┘
           │
    ┌──────┼──────────────────────────────────┐
    │      │                                  │
    ▼      ▼                                  ▼
  CASO 1  CASO 2                           ...
  Personas  Servicios                    CASO 0: Exit
    │       │
    │       ├──► menuGestionPersonas    └──► Finalizar
    │       │        - CRUD              sistema
    │       │
    │       └──► MenuServiciosMedicos
    │            - Procesar servicios
    │
    └──► MenuClinico
         - Gestión de citas
         - Historiales clínicos
```

---

## Datos de Prueba

La clase `SimulacionDemo` carga automáticamente datos de prueba al iniciar:

### Pacientes Pre-cargados

| ID | Nombre | EPS |
|-----|--------|-----|
| 12345678 | Juan Pérez | Salud Total |
| 87654321 | María García | Cruz Azul |
| 11111111 | Carlos López | Famisanar |

### Médicos Pre-cargados

| ID | Nombre | Especialidad | Consultorio |
|-----|--------|-------------|-------------|
| 99999999 | Dr. Alfonso Santos | Cardiología | Cons-01 |
| 88888888 | Dra. Paula Rodríguez | Pediatría | Cons-02 |

### Enfermeros Pre-cargados

| ID | Nombre | Turno |
|-----|--------|-------|
| 77777777 | Ana Martínez | Diurno |
| 66666666 | Pedro Hernández | Nocturno |

### Consultorios Pre-cargados

| ID | Número | Especialidad |
|-----|--------|-------------|
| 1 | Cons-01 | Cardiología |
| 2 | Cons-02 | Pediatría |
| 3 | Cons-03 | General |

### Cómo usar los datos de prueba:

1. Al iniciar la aplicación, los datos se cargan automáticamente en memoria
2. Usar los documentos de identidad anteriores para buscar/modificar
3. Crear nuevos registros según sea necesario
4. Los datos se pierden al cerrar la aplicación

---

## Tecnologías y Dependencias

### Lenguaje y Plataforma
- **Java:** 25 (JDK 25)
- **Compilador:** javac (OpenJDK o equivalente)

### Build Tool
- **Maven:** 3.8+ (opcional pero recomendado)

### Dependencias Java
```xml
<!-- En pom.xml -->
<dependency>
    <groupId>com.oracle.database.jdbc</groupId>
    <artifactId>ojdbc11</artifactId>
    <version>21.9.0.0</version>
</dependency>
```

### Librerías de Java Estándar Utilizadas

| Librería | Uso |
|----------|-----|
| `java.util.*` | ArrayList, HashMap, List, Map, Queue |
| `java.time.*` | LocalDate, LocalTime, LocalDateTime |
| `java.util.Scanner` | Lectura de entradas de usuario |
| `java.io.PrintStream` | Salida por consola |

### Patrones de Diseño Implementados

1. **Estrategia (Strategy):** Interfaz ServicioSalud con múltiples implementaciones
2. **Plantilla (Template):** Clase abstracta Citas define estructura
3. **Singleton (parcial):** Servicios como AuditoriaSistema con métodos estáticos
4. **CRUD:** Operaciones completas sobre entidades

---

## Resumen de Métodos y Operaciones

### Usuarios (25+ operaciones)

```
Gestión de Usuarios:
├── Registrar Paciente
├── Registrar Médico
├── Registrar Enfermero
├── Registrar Administrador
├── Buscar Persona por documento
├── Listar todos los usuarios
├── Listar pacientes
├── Listar médicos
├── Listar enfermeros
├── Actualizar datos de persona
├── Actualizar salario de trabajador
├── Eliminar usuario
├── Validar documento único
└── (y más...)
```

### Servicios de Salud

```
Servicios:
├── Crear consulta general
├── Crear examen de laboratorio
├── Procesar servicio (calcular costo)
├── Listar servicios disponibles
├── Mostrar detalles de servicio
└── Procesar lista de servicios
```

### Citas Médicas

```
Citas:
├── Crear cita
├── Confirmar cita
├── Listar citas
├── Listar citas por paciente
├── Listar citas por médico
├── Buscar cita por ID
├── Cambiar estado de cita
└── Validar disponibilidad
```

### Historia Clínica

```
Historiales:
├── Crear historia clínica
├── Agregar entrada médica
├── Consultar historial completo
├── Ver diagnósticos
├── Agregar medicamentos
└── Ver tratamientos
```

### Auditoría

```
Auditoría:
├── Registrar acción (automático)
├── Mostrar todos los logs
├── Buscar log por ID
├── Ver logs por usuario
└── Ver logs por rango de fecha
```

### Notificaciones

```
Notificaciones:
├── Agregar notificación
├── Procesar todas las notificaciones
├── Eliminar primera notificación
├── Ver notificaciones pendientes
└── Generar notificaciones de eventos
```

---

## Ejecución y Demostración

### Flujo de Demostración Típico

1. **Iniciar aplicación** → Se cargan datos de prueba
2. **Menú Principal** → 6 opciones principales
3. **Gestión de Usuarios** → CRUD completo
4. **Servicios Médicos** → Demostración de polimorfismo
5. **Gestión Clínica** → Citas e historiales
6. **Auditoría** → Ver eventos registrados
7. **Notificaciones** → Procesar eventos
8. **Salir** → Sistema finaliza (datos se pierden)

### Captura de Pantalla Simulada

```
==========================================
    CSC SALUD COMUNITARIA - MENU
==========================================
1. Gestion de Usuarios (CRUD Personas)
2. Servicios de Salud (Polimorfismo/Interfaz)
3. Gestion Clinica (Citas / Historia Clinica)
4. Ver Auditoria del Sistema (Uso de Maps)
5. Procesar todas las notificaciones
6. Atender/Eliminar la primera notificacion
0. Salir del Programa
------------------------------------------
Seleccione una opcion: 
```

---

## Contribuyentes

**Autor(es):** Equipo de desarrollo (AylZz)  
**Institución:** Universidad de Ibagué  
**Curso:** Estructura de Datos y Programación Orientada a Objetos  
**Fecha de Exposición:** Miércoles 6 de mayo de 2026

---

## Conclusión

**CSC Salud Comunitaria** es un sistema académico completo que demuestra los principios fundamentales de la programación orientada a objetos, el manejo de colecciones en memoria y la construcción de aplicaciones con dominio real. El proyecto integra menús interactivos, validación robusta, reglas de negocio explícitas y una arquitectura escalable.

Todos los datos se gestionan en memoria RAM, garantizando que la información se pierda al cerrar la aplicación, conforme a los requisitos del proyecto académico.

---

**Última actualización:** 6 de mayo de 2026  
**Versión:** 1.0 SNAPSHOT  
**Estado:** Completo y documentado ✅