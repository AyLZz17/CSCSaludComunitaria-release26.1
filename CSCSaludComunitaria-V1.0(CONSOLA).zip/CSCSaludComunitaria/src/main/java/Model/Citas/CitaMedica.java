package Model.Citas;

import java.time.LocalDate;
import java.time.LocalTime;

public class CitaMedica extends Citas {

    public CitaMedica(int id, LocalDate fecha, LocalTime hora, String motivo, String estado, int idConsultorio,
            int idPaciente, int idMedico) {
        super(id, fecha, hora, motivo, estado, idConsultorio, idPaciente, idMedico);
    }

    @Override
    public void mostrarCitas() {
        System.out.println("--- CITA MEDICA ---");
        System.out.println("ID: " + getId());
        System.out.println("Fecha: " + getFecha());
        System.out.println("Hora: " + getHora());
        System.out.println("Motivo: " + getMotivo());
        System.out.println("Estado: " + getEstado());
        System.out.println("Consultorio ID: " + getIdConsultorio());
        System.out.println("Paciente ID: " + getIdPaciente());
        System.out.println("Medico ID: " + getIdMedico());
        System.out.println("-------------------");
    }

    @Override
    public void confirmar() {
        setEstado("Confirmada");
    }
}
