package Model.Citas;

public class ConsultorioGeneral extends Consultorio {

    public ConsultorioGeneral(int id, String nombre, String estado) {
        super(id, nombre, estado);
    }

    @Override
    public void mostrarConsultorios() {
        System.out.println("--- CONSULTORIO ---");
        System.out.println("ID: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Estado: " + getEstado());
        System.out.println("-------------------");
    }
}
