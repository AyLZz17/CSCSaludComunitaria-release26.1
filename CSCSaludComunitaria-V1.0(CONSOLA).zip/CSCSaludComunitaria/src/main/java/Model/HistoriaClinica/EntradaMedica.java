package Model.HistoriaClinica;

public class EntradaMedica {
    private String fecha;
    private String diagnostico;
    private String tratamiento;

    public EntradaMedica(String fecha, String diagnostico, String tratamiento) {
        this.fecha = fecha;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
    }

    public String getFecha() {
        return fecha;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getTratamiento() {
        return tratamiento;
    }
}