package Model.HistoriaClinica;

import java.util.ArrayList;
import java.util.List;

public class HistoriaClinica {
    private int idHistoria;
    private int idPaciente;
    private List<EntradaMedica> entradas;

    public HistoriaClinica(int idHistoria, int idPaciente) {
        this.idHistoria = idHistoria;
        this.idPaciente = idPaciente;
        this.entradas = new ArrayList<>();
    }
    
    public void agregarEntrada(EntradaMedica entrada) {
        this.entradas.add(entrada);
    }

    public int getIdHistoria() {
        return idHistoria;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public List<EntradaMedica> getEntradas() {
        return entradas;
    }
}