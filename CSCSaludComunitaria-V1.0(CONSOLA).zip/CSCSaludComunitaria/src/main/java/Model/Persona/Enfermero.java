package Model.Persona;

public class Enfermero extends Trabajador
{

    private String medicoAsignado;

    public Enfermero(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, 
    String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, 
    String horario, String horarioRotativo, String turno, String medicoAsignado) 
    {
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento, 
        cargo, codigoTrabajador, salario, estadoContrato, horario, horarioRotativo, turno);
        this.medicoAsignado = medicoAsignado;
    }

    public String getMedicoAsignado() {
        return medicoAsignado;
    }

    public void setMedicoAsignado(String medicoAsignado) {
        this.medicoAsignado = medicoAsignado;
    }

}
