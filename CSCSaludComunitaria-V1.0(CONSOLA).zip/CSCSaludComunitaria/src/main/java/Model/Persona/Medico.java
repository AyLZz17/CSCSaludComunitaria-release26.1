package Model.Persona;

public class Medico extends Trabajador
{
    private String especialidad;
    private String estadoLicencia;
    private String consultorio;

    public Medico(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, 
    String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, 
    String horario, String horarioRotativo, String turno, String especialidad, String estadoLicencia, String consultorio) 
    {
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento, 
        cargo, codigoTrabajador, salario, estadoContrato, horario, horarioRotativo, turno);
        this.especialidad = especialidad;
        this.estadoLicencia = estadoLicencia;
        this.consultorio = consultorio;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getEstadoLicencia() {
        return estadoLicencia;
    }

    public void setEstadoLicencia(String estadoLicencia) {
        this.estadoLicencia = estadoLicencia;
    }

    public String getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(String consultorio) {
        this.consultorio = consultorio;
    }




}
