package Model.Persona;

public class Paciente extends Persona
{

    private String estadoCivil;
    private int hijos;
    private String eps;

    public Paciente(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, String fechaNacimiento, 
    String direccion, String lugarNacimiento, String estadoCivil, int hijos, String eps) 
    {
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento);
        this.estadoCivil = estadoCivil;
        this.hijos = hijos;
        this.eps = eps;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public int getHijos() {
        return hijos;
    }

    public void setHijos(int hijos) {
        this.hijos = hijos;
    }

    public String getEps() {
        return eps;
    }

    public void setEps(String eps) {
        this.eps = eps;
    }

}
