/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Persona;

/**
 *
 * @author AylZz
 */
public class Persona 
{
    private int documentoIdentidad; //primary key
    private String tipoDocumento;
    private String nombreCompleto;
    private String contacto; //telefono o correo
    private int edad;
    private String generoNacimiento; // H ó M
    private String fechaNacimiento;
    private String direccion;
    private String lugarNacimiento;

    public Persona(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, String fechaNacimiento, String direccion, String lugarNacimiento) {
        this.contacto = contacto;
        this.documentoIdentidad = documentoIdentidad;
        this.edad = edad;
        this.generoNacimiento = generoNacimiento;
        this.nombreCompleto = nombreCompleto;
        this.tipoDocumento = tipoDocumento;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
        this.lugarNacimiento = lugarNacimiento;
    }

    public int getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public void setDocumentoIdentidad(int documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGeneroNacimiento() {
        return generoNacimiento;
    }

    public void setGeneroNacimiento(String generoNacimiento) {
        this.generoNacimiento = generoNacimiento;
    }

    
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getLugarNacimiento() {
        return lugarNacimiento;
    }

    public void setLugarNacimiento(String lugarNacimiento) {
        this.lugarNacimiento = lugarNacimiento;
    }


}
