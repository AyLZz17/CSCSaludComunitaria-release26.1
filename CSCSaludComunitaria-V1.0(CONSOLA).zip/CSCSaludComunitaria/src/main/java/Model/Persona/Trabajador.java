package Model.Persona;

public class Trabajador extends Persona
{

    private String cargo;
    private int codigoTrabajador;
    private double salario;
    private String estadoContrato;
    private String horario;
    private String horarioRotativo; // Sí o No
    private String turno; // Diurno, Nocturno o Mixto

    public Trabajador(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, String horario, String horarioRotativo, String turno) {
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento);
        this.cargo = cargo;
        this.codigoTrabajador = codigoTrabajador;
        this.salario = salario;
        this.estadoContrato = estadoContrato;
        this.horario = horario;
        this.horarioRotativo = horarioRotativo;
        this.turno = turno;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getCodigoTrabajador() {
        return codigoTrabajador;
    }

    public void setCodigoTrabajador(int codigoTrabajador) {
        this.codigoTrabajador = codigoTrabajador;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getEstadoContrato() {
        return estadoContrato;
    }

    public void setEstadoContrato(String estadoContrato) {
        this.estadoContrato = estadoContrato;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getHorarioRotativo() {
        return horarioRotativo;
    }

    public void setHorarioRotativo(String horarioRotativo) {
        this.horarioRotativo = horarioRotativo;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }



}
