package Model.ServiciosCSC;

public class ConsultaGeneral implements ServicioSalud {
    private double precioBase = 50000;
    
    @Override
    public double calcularCostoFinal() { return precioBase; }
    
    @Override
    public String obtenerDetalles() { return "Consulta de Medicina General"; }
}

