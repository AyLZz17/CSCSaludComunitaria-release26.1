package Model.ServiciosCSC;

public class ExamenLaboratorio implements ServicioSalud {
    private String tipoExamen;
    private double costoMateriales;

    public ExamenLaboratorio(String tipo, double costo) {
        this.tipoExamen = tipo;
        this.costoMateriales = costo;
    }

    @Override
    public double calcularCostoFinal() { return 80000 + costoMateriales; }

    @Override
    public String obtenerDetalles() { return "Examen: " + tipoExamen; }
}
