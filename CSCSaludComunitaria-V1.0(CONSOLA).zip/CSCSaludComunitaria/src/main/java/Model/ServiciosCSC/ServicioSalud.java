package Model.ServiciosCSC;

public interface ServicioSalud 
{
    double calcularCostoFinal();
    String obtenerDetalles();
}
