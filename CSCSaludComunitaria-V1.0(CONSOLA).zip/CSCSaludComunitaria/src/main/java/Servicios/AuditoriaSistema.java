package Servicios;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class AuditoriaSistema {
    //
    private static Map<Integer, String> logs = new HashMap<>();
    private static int contadorEvento = 1;

    public static void registrarAccion(String usuario, String accion) {
        String registro = "[" + LocalDateTime.now() + "] Usuario: " + usuario + " - Accion: " + accion;
        logs.put(contadorEvento++, registro);
    }

    public static void mostrarLogs() {
        System.out.println("\n--- AUDITORÍA DE EVENTOS EN MEMORIA ---");
        logs.forEach((id, msg) -> System.out.println("ID " + id + ": " + msg));
    }
}
