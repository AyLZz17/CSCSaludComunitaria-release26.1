package Servicios.GestionCitas;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Model.Citas.CitaMedica;
import Model.Citas.Consultorio;
import Model.Citas.ConsultorioGeneral;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.RegistrosPersonas;
import Servicios.Notificaciones;
import Utils.UtilServices;
import Utils.ValidadorEntrada;

public class GestionCitas {
    private static final List<CitaMedica> citas = new ArrayList<>();
    private static final List<Consultorio> consultorios = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void inicializarConsultoriosDemo() {
        if (!consultorios.isEmpty()) {
            return;
        }

        consultorios.add(new ConsultorioGeneral(1, "Consultorio 101", "Disponible"));
        consultorios.add(new ConsultorioGeneral(2, "Consultorio 202", "Ocupado"));
        consultorios.add(new ConsultorioGeneral(3, "Consultorio 303", "Disponible"));
    }

    public static void mostrarMenuCitas() {
        inicializarConsultoriosDemo();
        int opcion;
        do {
            System.out.println("\n--- MENU DE CITAS ---");
            System.out.println("1. Ver consultorios disponibles");
            System.out.println("2. Agendar cita");
            System.out.println("3. Ver citas agendadas");
            System.out.println("4. Confirmar cita");
            System.out.println("5. Volver");
            opcion = ValidadorEntrada.leerEnteroSeguro("Seleccione una opcion: ");

            switch (opcion) {
                case 1:
                    mostrarConsultorios();
                    break;
                case 2:
                    agendarCita();
                    break;
                case 3:
                    mostrarCitas();
                    break;
                case 4:
                    confirmarCita();
                    break;
                case 5:
                    System.out.println("Regresando al menu anterior...");
                    break;
                default:
                    System.out.println("Opcion no reconocida. Intente de nuevo.");
            }
        } while (opcion != 5);
    }

    public static void mostrarConsultorios() {
        System.out.println("\n--- LISTA DE CONSULTORIOS ---");
        if (consultorios.isEmpty()) {
            System.out.println("No hay consultorios registrados.");
            return;
        }
        for (Consultorio item : consultorios) {
            item.mostrarConsultorios();
        }
    }

    private static void agendarCita() {
        System.out.println("\n--- AGENDAR CITA ---");
        mostrarConsultorios();
        
        int idConsultorio = ValidadorEntrada.leerEnteroSeguro("Ingrese ID de consultorio: ");
        if (!encontrarConsultorio(idConsultorio)) {
            System.out.println("El consultorio con ese ID no existe.");
            return;
        }
        int idPaciente = ValidadorEntrada.leerEnteroSeguro("Ingrese ID de paciente: ");
        if (!validarPaciente(idPaciente)) {
            System.out.println("El paciente no existe o no es un paciente registrado.");
            return;
        }
        int idMedico = ValidadorEntrada.leerEnteroSeguro("Ingrese ID de medico: ");
        if (!validarMedico(idMedico)) {
            System.out.println("El medico no existe o no es un medico registrado.");
            return;
        }

        System.out.print("Ingrese fecha (YYYY-MM-DD): ");
        String fechaTexto = scanner.nextLine().trim();
        LocalDate fecha;
        try {
            fecha = LocalDate.parse(fechaTexto);
        } catch (DateTimeParseException e) {
            System.out.println("Formato de fecha invalido.");
            return;
        }

        System.out.print("Ingrese hora (HH:MM): ");
        String horaTexto = scanner.nextLine().trim();
        LocalTime hora;
        try {
            hora = LocalTime.parse(horaTexto);
        } catch (DateTimeParseException e) {
            System.out.println("Formato de hora invalido.");
            return;
        }

        System.out.print("Ingrese motivo de la cita: ");
        String motivo = scanner.nextLine();

        int idCita = citas.size() + 1;
        CitaMedica cita = new CitaMedica(idCita, fecha, hora, motivo, "Pendiente", idConsultorio, idPaciente, idMedico);
        citas.add(cita);

        Notificaciones.agregarNotificacion("Nueva cita agendada: " + cita.getId());
        AuditoriaSistema.registrarAccion("Sistema", "Cita agendada: " + cita.getId());
        System.out.println("Cita agendada correctamente con ID " + cita.getId());
    }

    public static void mostrarCitas() {
        System.out.println("\n--- CITAS AGENDADAS ---");
        if (citas.isEmpty()) {
            System.out.println("No hay citas agendadas.");
            return;
        }
        for (CitaMedica cita : citas) {
            cita.mostrarCitas();
        }
    }

    private static void confirmarCita() {
        System.out.println("\n--- CONFIRMAR CITA ---");
        int idCita = ValidadorEntrada.leerEnteroSeguro("Ingrese ID de cita: ");
        for (CitaMedica cita : citas) {
            if (cita.getId() == idCita) {
                cita.confirmar();
                Notificaciones.agregarNotificacion("Cita confirmada: " + idCita);
                AuditoriaSistema.registrarAccion("Sistema", "Cita confirmada: " + idCita);
                System.out.println("Cita " + idCita + " confirmada.");
                return;
            }
        }
        System.out.println("Cita con ID " + idCita + " no encontrada.");
    }

    private static boolean validarPaciente(int documento) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), documento);
        return persona instanceof Paciente;
    }

    private static boolean validarMedico(int documento) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), documento);
        return persona instanceof Medico;
    }

    private static boolean encontrarConsultorio(int idConsultorio) {
        return consultorios.stream().anyMatch(c -> c.getId() == idConsultorio);
    }
}
