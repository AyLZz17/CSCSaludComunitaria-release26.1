package Servicios.GestionHistoriaClinica;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import Model.HistoriaClinica.EntradaMedica;
import Model.HistoriaClinica.HistoriaClinica;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.RegistrosPersonas;
import Servicios.Notificaciones;
import Utils.UtilServices;
import Utils.ValidadorEntrada;

public class GestionHistoriaClinica {
    private static final Map<Integer, HistoriaClinica> historias = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int siguienteHistoria = 1;

    public static void inicializarHistoriasDemo() {
        if (!historias.isEmpty()) {
            return;
        }

        // Crea historias de muestra para algunos pacientes existentes.
        if (UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), 201) instanceof Paciente) {
            HistoriaClinica historia1 = new HistoriaClinica(siguienteHistoria++, 201);
            historia1.agregarEntrada(new EntradaMedica("2026-05-01", "Control general", "Continuar con dieta balanceada"));
            historias.put(201, historia1);
        }

        if (UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), 202) instanceof Paciente) {
            HistoriaClinica historia2 = new HistoriaClinica(siguienteHistoria++, 202);
            historia2.agregarEntrada(new EntradaMedica("2026-05-02", "Dolor de cabeza", "Paracetamol 500mg cada 8 horas"));
            historias.put(202, historia2);
        }
    }

    public static void mostrarMenuHistoriaClinica() {
        inicializarHistoriasDemo();
        int opcion;
        do {
            System.out.println("\n--- MENU DE HISTORIA CLINICA ---");
            System.out.println("1. Agregar entrada medica");
            System.out.println("2. Ver historia clinica de paciente");
            System.out.println("3. Ver todas las historias registradas");
            System.out.println("4. Volver");
            opcion = ValidadorEntrada.leerEnteroSeguro("Seleccione una opcion: ");

            switch (opcion) {
                case 1:
                    registrarEntradaMedica();
                    break;
                case 2:
                    mostrarHistoriaPaciente();
                    break;
                case 3:
                    mostrarTodasHistorias();
                    break;
                case 4:
                    System.out.println("Regresando al menu anterior...");
                    break;
                default:
                    System.out.println("Opcion no reconocida. Intente de nuevo.");
            }
        } while (opcion != 4);
    }

    private static void registrarEntradaMedica() {
        System.out.println("\n--- REGISTRAR ENTRADA MEDICA ---");
        int idPaciente = ValidadorEntrada.leerEnteroSeguro("Ingrese ID de paciente: ");

        Persona paciente = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), idPaciente);
        if (!(paciente instanceof Paciente)) {
            System.out.println("El paciente no existe o no corresponde a un paciente registrado.");
            return;
        }

        System.out.print("Fecha de la entrada (YYYY-MM-DD): ");
        String fecha = scanner.nextLine().trim();
        System.out.print("Diagnostico: ");
        String diagnostico = scanner.nextLine();
        System.out.print("Tratamiento: ");
        String tratamiento = scanner.nextLine();

        HistoriaClinica historia = historias.get(idPaciente);
        if (historia == null) {
            historia = new HistoriaClinica(siguienteHistoria++, idPaciente);
            historias.put(idPaciente, historia);
        }

        historia.agregarEntrada(new EntradaMedica(fecha, diagnostico, tratamiento));
        Notificaciones.agregarNotificacion("Nueva entrada en historia clinica del paciente " + idPaciente);
        AuditoriaSistema.registrarAccion("Sistema", "Entrada medica registrada para paciente " + idPaciente);
        System.out.println("Entrada medica registrada exitosamente.");
    }

    private static void mostrarHistoriaPaciente() {
        System.out.println("\n--- HISTORIA CLINICA POR PACIENTE ---");
        int idPaciente = ValidadorEntrada.leerEnteroSeguro("Ingrese ID de paciente: ");

        HistoriaClinica historia = historias.get(idPaciente);
        if (historia == null) {
            System.out.println("No existe historia clinica para el paciente con ID " + idPaciente + ".");
            return;
        }

        System.out.println("Historia clinica del paciente ID: " + idPaciente);
        historia.getEntradas().forEach(entrada -> {
            System.out.println("Fecha: " + entrada.getFecha());
            System.out.println("Diagnostico: " + entrada.getDiagnostico());
            System.out.println("Tratamiento: " + entrada.getTratamiento());
            System.out.println("-----------------------------");
        });
    }

    private static void mostrarTodasHistorias() {
        System.out.println("\n--- TODAS LAS HISTORIAS CLINICAS ---");
        if (historias.isEmpty()) {
            System.out.println("No hay historias clinicas registradas.");
            return;
        }
        historias.values().forEach(historia -> {
            System.out.println("Historia ID: " + historia.getIdHistoria() + " - Paciente ID: " + historia.getIdPaciente());
            historia.getEntradas().forEach(entrada -> {
                System.out.println("  Fecha: " + entrada.getFecha());
                System.out.println("  Diagnostico: " + entrada.getDiagnostico());
                System.out.println("  Tratamiento: " + entrada.getTratamiento());
                System.out.println("  ---------------------------");
            });
        });
    }
}
