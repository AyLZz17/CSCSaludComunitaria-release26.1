package Servicios.GestionPersona;

import java.util.List;
import java.util.Scanner;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Model.Persona.Trabajador;
import Utils.UtilServices;



public class ActualizarPersona 
{

    private static Scanner scanner = new Scanner(System.in);

    //ACTUALIZAR PACIENTE 
    public static void actualizarPaciente(List<Persona> personas) 
    {
        Paciente paciente = (Paciente) buscarYValidar(personas, Paciente.class);
        if (paciente == null) return;

        actualizarDatosBase(paciente);

        System.out.print("Nuevo Estado Civil [" + paciente.getEstadoCivil() + "]: ");
        String est = scanner.nextLine();
        if (!est.trim().isEmpty()) paciente.setEstadoCivil(est);

        System.out.print("Nueva EPS [" + paciente.getEps() + "]: ");
        String eps = scanner.nextLine();
        if (!eps.trim().isEmpty()) paciente.setEps(eps);

        System.out.print("Nuevo numero de hijos [" + paciente.getHijos() + "]: ");
        String hijos = scanner.nextLine();
        if (!hijos.trim().isEmpty()) {
            try { paciente.setHijos(Integer.parseInt(hijos)); } 
            catch (NumberFormatException e) { System.out.println("Valor no numerico, no se actualizo."); }
        }
        System.out.println("Paciente actualizado exitosamente.");
    }

    //ACTUALIZAR MÉDICO
    public static void actualizarMedico(List<Persona> personas) 
    {
        Medico medico = (Medico) buscarYValidar(personas, Medico.class);
        if (medico == null) return;

        actualizarDatosBase(medico);
        actualizarDatosTrabajador(medico);

        System.out.print("Nueva Especialidad [" + medico.getEspecialidad() + "]: ");
        String esp = scanner.nextLine();
        if (!esp.trim().isEmpty()) medico.setEspecialidad(esp);

        System.out.print("Nuevo Consultorio [" + medico.getConsultorio() + "]: ");
        String cons = scanner.nextLine();
        if (!cons.trim().isEmpty()) medico.setConsultorio(cons);

        System.out.println("Medico actualizado exitosamente.");
    }

    //ACTUALIZAR ENFERMERO
    public static void actualizarEnfermero(List<Persona> personas) 
    {
        Enfermero enfermero = (Enfermero) buscarYValidar(personas, Enfermero.class);
        if (enfermero == null) return;

        actualizarDatosBase(enfermero);
        actualizarDatosTrabajador(enfermero);

        System.out.print("Nuevo Medico Asignado [" + enfermero.getMedicoAsignado() + "]: ");
        String med = scanner.nextLine();
        if (!med.trim().isEmpty()) {
            if (UtilServices.validarExistenciaMedico(personas, med)) {
                enfermero.setMedicoAsignado(med);
            } else {
                System.out.println("Error: El medico no existe. No se actualizo la asignacion.");
            }
        }
        System.out.println("Enfermero actualizado exitosamente.");
    }

    //ACTUALIZAR ADMINISTRADOR
    public static void actualizarAdministrador(List<Persona> personas) 
    {
        Administrador admin = (Administrador) buscarYValidar(personas, Administrador.class);
        if (admin == null) return;

        actualizarDatosBase(admin);
        actualizarDatosTrabajador(admin);

        System.out.print("Nuevo Departamento [" + admin.getDepartamento() + "]: ");
        String dep = scanner.nextLine();
        if (!dep.trim().isEmpty()) admin.setDepartamento(dep);

        System.out.println("Administrador actualizado exitosamente.");
    }


    private static Persona buscarYValidar(List<Persona> personas, Class<?> tipoEsperado) 
    {
        System.out.print("Ingrese el documento de identidad: ");
        int doc = scanner.nextInt(); scanner.nextLine();
        
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == doc && tipoEsperado.isInstance(p)) {
                return p;
            }
        }
        System.out.println("Error: No se encontro el registro o el tipo de persona no coincide.");
        return null;
    }

    private static void actualizarDatosBase(Persona p) 
    {
        System.out.println("\nActualizando: " + p.getNombreCompleto());
        System.out.print("Nueva Direccion [" + p.getDireccion() + "]: ");
        String dir = scanner.nextLine();
        if (!dir.trim().isEmpty()) p.setDireccion(dir);

        System.out.print("Nuevo Contacto [" + p.getContacto() + "]: ");
        String con = scanner.nextLine();
        if (!con.trim().isEmpty()) p.setContacto(con);
    }

    private static void actualizarDatosTrabajador(Trabajador t) 
    {
        System.out.print("Nuevo Salario [" + t.getSalario() + "]: ");
        String sal = scanner.nextLine();
        if (!sal.trim().isEmpty()) {
            try { t.setSalario(Double.parseDouble(sal)); } 
            catch (NumberFormatException e) { System.out.println("Salario invalido, se mantiene el actual."); }
        }

        System.out.print("Nuevo Turno [" + t.getTurno() + "]: ");
        String turno = scanner.nextLine();
        if (!turno.trim().isEmpty()) t.setTurno(turno);
    }
}
