package Servicios.GestionPersona;

import java.util.List;
import java.util.Scanner;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;

public class BuscarPersona {

    private static Scanner scanner = new Scanner(System.in);

    public static void buscarPorDocumento(List<Persona> personas) {
        System.out.println("\n--- CONSULTAR REGISTRO ---");
        System.out.print("Ingrese el documento de identidad: ");
        
        int documento;
        try {
            documento = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Error: Ingrese un numero de documento valido.");
            return;
        }

        Persona encontrado = null;
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documento) {
                encontrado = p;
                break;
            }
        }

        if (encontrado != null) {
            System.out.println("\nInformacion detallada del registro:");
            System.out.println("------------------------------------------");
            
            // Verificamos el tipo de objeto manualmente para usar tus metodos de MostrarPersona
            if (encontrado instanceof Medico) {
                // Aquí podrías llamar directamente al método de MostrarPersona 
                // o imprimir los campos usando los getters
                System.out.println("Tipo: Medico");
                imprimirDatosGenerales(encontrado);
            } else if (encontrado instanceof Paciente) {
                System.out.println("Tipo: Paciente");
                imprimirDatosGenerales(encontrado);
            } else if (encontrado instanceof Enfermero) {
                System.out.println("Tipo: Enfermero");
                imprimirDatosGenerales(encontrado);
            } else if (encontrado instanceof Administrador) {
                System.out.println("Tipo: Administrador");
                imprimirDatosGenerales(encontrado);
            }
            System.out.println("------------------------------------------");
        } else {
            System.out.println("No se encontro ningun registro con el documento: " + documento);
        }
    }

    //codigo de impresion base
    private static void imprimirDatosGenerales(Persona p) {
        System.out.println("Nombre: " + p.getNombreCompleto());
        System.out.println("Documento: " + p.getDocumentoIdentidad() + " (" + p.getTipoDocumento() + ")");
        System.out.println("Edad: " + p.getEdad());
        System.out.println("Contacto: " + p.getContacto());
        System.out.println("Direccion: " + p.getDireccion());
    }
}
