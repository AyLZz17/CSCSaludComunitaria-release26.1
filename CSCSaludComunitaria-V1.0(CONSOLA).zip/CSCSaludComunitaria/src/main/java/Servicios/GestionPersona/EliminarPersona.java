package Servicios.GestionPersona;

import java.util.List;
import java.util.Scanner;

import Model.Persona.Persona;

public class EliminarPersona {

    private static Scanner scanner = new Scanner(System.in);

    
    public static void eliminarPorDocumento(List<Persona> personas) {
        System.out.println("\n--- ELIMINAR REGISTRO ---");
        System.out.print("Ingrese el documento de identidad de la persona a eliminar: ");
        
        int documento;
        try {
            documento = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Error: El documento debe ser un numero.");
            return;
        }

        Persona personaAEliminar = null;

        //Buscar la persona en la lista
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documento) {
                personaAEliminar = p;
                break;
            }
        }

        //Validar y eliminar
        if (personaAEliminar != null) {
            System.out.print("¿Esta seguro de eliminar a " + personaAEliminar.getNombreCompleto() + "? (Si/No): ");
            String confirmacion = scanner.nextLine();

            if (confirmacion.equalsIgnoreCase("Si")) {
                personas.remove(personaAEliminar);
                System.out.println("Registro eliminado exitosamente.");
            } else {
                System.out.println("Operacion cancelada.");
            }
        } else {
            System.out.println("Error: No se encontro ninguna persona con el documento " + documento);
        }
    }
}