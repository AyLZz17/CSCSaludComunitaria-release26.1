package Servicios.GestionPersona;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Utils.UtilServices;


    

public class RegistrosPersonas 
{
    private static List<Persona> personas = new ArrayList<>();
    
    private static Scanner scanner = new Scanner(System.in);

    public static List<Persona> getPersonas() {
        return personas;
    }

    public static Persona capturarDatosBase() 
    {
        System.out.print("Nombre completo: "); 
        String nombre = scanner.nextLine();
        System.out.print("Documento de identidad: "); 
        int documento = scanner.nextInt(); scanner.nextLine();
        System.out.print("Tipo de documento: "); 
        String tipoDoc = scanner.nextLine();
        System.out.print("Edad: "); 
        int edad = scanner.nextInt(); scanner.nextLine();
        System.out.print("Genero de nacimiento: "); 
        String genero = scanner.nextLine();
        System.out.print("Contacto: "); 
        String contacto = scanner.nextLine();
        System.out.print("Fecha de nacimiento: "); 
        String fechaNac = scanner.nextLine();
        System.out.print("Direccion: "); 
        String direccion = scanner.nextLine();
        System.out.print("Lugar de nacimiento: "); 
        String lugarNac = scanner.nextLine();

        return new Persona(contacto, documento, edad, genero, nombre, tipoDoc, fechaNac, direccion, lugarNac);
    }

    public static void registrarPaciente(Persona base) 
    {
        System.out.print("Estado civil: ");
        String estadoCivil = scanner.nextLine();
        System.out.print("Numero de hijos: ");
        int hijos = scanner.nextInt(); scanner.nextLine();
        System.out.print("EPS: ");
        String eps = scanner.nextLine();

        Paciente paciente = new Paciente(base.getContacto(), base.getDocumentoIdentidad(), base.getEdad(), base.getGeneroNacimiento(), 
        base.getNombreCompleto(), base.getTipoDocumento(), base.getFechaNacimiento(), base.getDireccion(), base.getLugarNacimiento(),
        estadoCivil, hijos, eps);

        personas.add(paciente);
        System.out.println("Paciente registrado exitosamente.");
    }

    public static void registrarMedico(Persona base) 
    {
        System.out.print("Codigo de trabajador: ");
        int codigoTabajador = scanner.nextInt(); scanner.nextLine();
        System.out.print("Especialidad: ");
        String especialidad = scanner.nextLine();
        System.out.print("Estado de licencia: ");
        String estadoLicencia = scanner.nextLine();
        System.out.print("Consultorio: ");
        String consultorio = scanner.nextLine();
        System.out.print("Horario de trabajo: ");
        String horario = scanner.nextLine();
        System.out.print("Estado del contrato: ");
        String estadoContrato = scanner.nextLine();
        System.out.print("Horario rotativo: ");
        String horarioRotativo = scanner.nextLine();
        System.out.print("Turno (Diurno/Nocturno): ");
        String turno = scanner.nextLine();
        System.out.print("Salario: ");
        double salario = scanner.nextDouble(); scanner.nextLine();

        Medico medico = new Medico(base.getContacto(), base.getDocumentoIdentidad(), base.getEdad(), base.getGeneroNacimiento(),
        base.getNombreCompleto(), base.getTipoDocumento(), base.getFechaNacimiento(), base.getDireccion(), base.getLugarNacimiento(), 
        "Medico", codigoTabajador, salario, estadoContrato, horario, horarioRotativo, turno, especialidad, estadoLicencia, consultorio);

        personas.add(medico);
        System.out.println("Medico registrado exitosamente.");
    }

    public static void registrarEnfermero(Persona base) 
    {
        //Mostrar médicos disponibles antes de solicitar la asignación
        MostrarPersona.mostrarMedicos();
        
        String medicoAsignado = "";
        boolean esValido = false;

        //Validación de existencia del médico
        while (!esValido) {
            System.out.print("Ingrese el nombre completo del medico asignado: ");
            medicoAsignado = scanner.nextLine();
            
            if (UtilServices.validarExistenciaMedico(personas, medicoAsignado)) {
                esValido = true;
            } else {
                System.out.println("Error: El medico no se encuentra registrado o el nombre es incorrecto.");
                System.out.print("¿Desea ver la lista de nuevo? (si/no): ");
                if (scanner.nextLine().equalsIgnoreCase("si")) {
                    MostrarPersona.mostrarMedicos();
                }
            }
        }

        // 3. Captura de datos laborales
        System.out.print("Codigo de trabajador: ");
        int codigoTabajador = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Horario de trabajo: ");
        String horario = scanner.nextLine();
        
        System.out.print("Estado del contrato: ");
        String estadoContrato = scanner.nextLine();
        
        System.out.print("Horario rotativo: ");
        String horarioRotativo = scanner.nextLine();
        
        System.out.print("Turno (Diurno/Nocturno): ");
        String turno = scanner.nextLine();
        
        System.out.print("Salario: ");
        double salario = scanner.nextDouble(); scanner.nextLine();
        

        Enfermero enfermero = new Enfermero(base.getContacto(), base.getDocumentoIdentidad(), base.getEdad(), base.getGeneroNacimiento(),
        base.getNombreCompleto(), base.getTipoDocumento(), base.getFechaNacimiento(), base.getDireccion(), base.getLugarNacimiento(), 
        "Enfermero", codigoTabajador, salario, estadoContrato, horario, horarioRotativo, turno, medicoAsignado);

        personas.add(enfermero);
        System.out.println("Enfermero registrado exitosamente.");
    }

    public static void registrarAdministrador(Persona base) 
    {
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();
        System.out.print("Codigo de trabajador: ");
        int codigoTabajador = scanner.nextInt(); scanner.nextLine();
        System.out.print("Horario de trabajo: ");
        String horario = scanner.nextLine();
        System.out.print("Estado del contrato: ");
        String estadoContrato = scanner.nextLine();
        System.out.print("Horario rotativo: ");
        String horarioRotativo = scanner.nextLine();
        System.out.print("Turno (Diurno/Nocturno): ");
        String turno = scanner.nextLine();
        System.out.print("Salario: ");
        double salario = scanner.nextDouble(); scanner.nextLine();
        System.out.print("Departamento: ");
        String departamento = scanner.nextLine();

        Administrador admin = new Administrador(base.getContacto(), base.getDocumentoIdentidad(), base.getEdad(), base.getGeneroNacimiento(),
        base.getNombreCompleto(), base.getTipoDocumento(), base.getFechaNacimiento(), base.getDireccion(), base.getLugarNacimiento(),
        cargo, codigoTabajador, salario, estadoContrato, horario, horarioRotativo, turno, departamento);

        personas.add(admin);
        System.out.println("Administrador registrado exitosamente.");
    }

}
