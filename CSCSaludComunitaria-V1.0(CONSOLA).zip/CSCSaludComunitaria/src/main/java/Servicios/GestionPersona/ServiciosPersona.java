package Servicios.GestionPersona;

import java.util.Scanner;

import Model.Persona.Persona;

public class ServiciosPersona 
{

    private static Scanner scanner = new Scanner(System.in);
    


    public static void agregarPersona()
    {
        System.out.println("Seleccione el tipo de persona a registrar:");
        System.out.println("1. Paciente");
        System.out.println("2. Medico");
        System.out.println("3. Enfermero");
        System.out.println("4. Administrador");
        System.out.println("5. Salir");
        System.out.print("Opcion: ");
        
        int seleccion = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (seleccion < 1 || seleccion > 5) {
            System.out.println("Error: Seleccion no valida.");
            return;
        }

        if (seleccion == 5) {
            System.out.println("Saliendo al menu principal...");
            return;
        }

        Persona base = RegistrosPersonas.capturarDatosBase();

        switch (seleccion) {
            case 1:
                RegistrosPersonas.registrarPaciente(base);
                break;
            case 2:
                RegistrosPersonas.registrarMedico(base);
                break;
            case 3:
                RegistrosPersonas.registrarEnfermero(base);
                break;
            case 4:
                RegistrosPersonas.registrarAdministrador(base);
                break;
            default:
                System.out.println("Opcion no valida.");
        }
    }

    public static void mostrarPersonas()
    {
        System.out.println("\n--- MOSTRAR PERSONAS REGISTRADAS ---");
        System.out.println("Seleccione el tipo de personas a mostrar:");
        System.out.println("1. Medicos");
        System.out.println("2. Pacientes");
        System.out.println("3. Enfermeros");
        System.out.println("4. Administradores");
        System.out.print("Opcion: ");
        
        int seleccion = scanner.nextInt();
        scanner.nextLine();

        switch (seleccion) {
            case 1:
                MostrarPersona.mostrarMedicos();
                break;
            case 2:
                MostrarPersona.mostrarPacientes();
                break;
            case 3:
                MostrarPersona.mostrarEnfermeros();
                break;
            case 4:
                MostrarPersona.mostrarAdministradores();
                break;
            default:
                System.out.println("Opcion no valida.");
        }
    }

    public static void actualizarPersona()
    {
        System.out.println("\n--- ACTUALIZAR PERSONA REGISTRADA ---");
        System.out.println("Seleccione el tipo de persona a actualizar:");
        System.out.println("1. Paciente");
        System.out.println("2. Medico");
        System.out.println("3. Enfermero");
        System.out.println("4. Administrador");
        System.out.println("5. Salir");
        System.out.print("Opcion: ");
        
        int seleccion = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (seleccion == 5) {
            System.out.println("Saliendo al menu principal...");
            return;
        }

        switch (seleccion) {
            case 1:
                ActualizarPersona.actualizarPaciente(RegistrosPersonas.getPersonas());
                break;
            case 2:
                ActualizarPersona.actualizarMedico(RegistrosPersonas.getPersonas());
                break;
            case 3:
                ActualizarPersona.actualizarEnfermero(RegistrosPersonas.getPersonas());
                break;
            case 4:
                ActualizarPersona.actualizarAdministrador(RegistrosPersonas.getPersonas());
                break;
            default:
                System.out.println("Error: Opcion no valida.");
        }
    }

    public static void eliminarPersona() {

        EliminarPersona.eliminarPorDocumento(RegistrosPersonas.getPersonas());
    }

    public static void buscarPersona() {
  
        BuscarPersona.buscarPorDocumento(RegistrosPersonas.getPersonas());
    }



}