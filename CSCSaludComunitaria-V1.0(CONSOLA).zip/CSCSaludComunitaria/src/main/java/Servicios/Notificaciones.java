package Servicios;

import java.util.LinkedList;
import java.util.Queue;

public class Notificaciones {

    private static Queue<String> colaNotificaciones = new LinkedList<>();

    public static void agregarNotificacion(String mensaje) {
        colaNotificaciones.add(mensaje); // Encola al final
    }

    public static void eliminarPrimeraNotificacion() {
        if (colaNotificaciones.isEmpty()) {
            System.out.println("No hay notificaciones pendientes para eliminar.");
        } else {
            // .poll() extrae y elimina el elemento al frente de la cola
            String eliminada = colaNotificaciones.poll(); 
            System.out.println("Se ha eliminado la notificacion mas antigua: " + eliminada);
        }
    }

    public static void procesarNotificaciones() {
        if (colaNotificaciones.isEmpty()) {
            System.out.println("Buzon vacio.");
            return;
        }
        System.out.println("--- Lista de Notificaciones ---");
        while (!colaNotificaciones.isEmpty()) {
            System.out.println("Procesada: " + colaNotificaciones.poll());
        }
    }
}