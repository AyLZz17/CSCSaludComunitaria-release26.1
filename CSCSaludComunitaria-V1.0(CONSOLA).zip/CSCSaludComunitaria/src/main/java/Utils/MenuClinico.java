package Utils;

import Servicios.GestionCitas.GestionCitas;
import Servicios.GestionHistoriaClinica.GestionHistoriaClinica;

public class MenuClinico {

    public static void mostrarMenuClinico() {
        int opcion;
        do {
            System.out.println("\n--- MENU CLINICO ---");
            System.out.println("1. Gestionar citas");
            System.out.println("2. Gestionar historia clinica");
            System.out.println("3. Volver al menu principal");
            opcion = ValidadorEntrada.leerEnteroSeguro("Seleccione una opcion: ");

            switch (opcion) {
                case 1:
                    GestionCitas.mostrarMenuCitas();
                    break;
                case 2:
                    GestionHistoriaClinica.mostrarMenuHistoriaClinica();
                    break;
                case 3:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente de nuevo.");
            }
        } while (opcion != 3);
    }
}
