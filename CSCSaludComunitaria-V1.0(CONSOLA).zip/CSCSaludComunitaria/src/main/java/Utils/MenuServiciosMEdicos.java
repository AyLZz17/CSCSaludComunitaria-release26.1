package Utils;


import Model.ServiciosCSC.ConsultaGeneral;
import Model.ServiciosCSC.ExamenLaboratorio;
import Model.ServiciosCSC.ServicioSalud;
import Servicios.AuditoriaSistema;

public class MenuServiciosMEdicos 
{
    

    public static void MenuServiciosMedicos() {
        System.out.println("\n--- MODULO DE COSTOS Y SERVICIOS ---");
        System.out.println("1. Simular Costo Consulta General");
        System.out.println("2. Simular Costo Examen Laboratorio");
        int subOp = ValidadorEntrada.leerEnteroSeguro("Seleccione tipo de servicio: ");

        ServicioSalud servicio;

        if (subOp == 1) {
            servicio = new ConsultaGeneral();
        } else if (subOp == 2) {
            servicio = new ExamenLaboratorio("Prueba de Sangre", 12500.0);
        } else {
            System.out.println("Opcion invalida.");
            return;
        }

        
        System.out.println("\nDETALLES DEL SERVICIO:");
        System.out.println("Descripcion: " + servicio.obtenerDetalles());
        System.out.println("Precio Total: $" + servicio.calcularCostoFinal());
        
        AuditoriaSistema.registrarAccion("Sistema", "Calculo de servicio: " + servicio.obtenerDetalles());
    }
}
