package Utils;

import java.util.List;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Servicios.GestionCitas.GestionCitas;
import Servicios.GestionHistoriaClinica.GestionHistoriaClinica;
import Servicios.GestionPersona.RegistrosPersonas;

public class SimulacionDemo {

    public static void cargarDatosDemo() {
        List<Persona> lista = RegistrosPersonas.getPersonas();

        // --- 10 MÉDICOS ---
        lista.add(new Medico("3101", 101, 35, "M", "Dr. Camilo Perez", "CC", "1989-05-12", "Calle 10", "Ibagué", "Médico Especialista", 1001, 5000000, "Activo", "7am-1pm", "No", "Mañana", "Cardiología", "Vigente", "Consultorio 101"));
        lista.add(new Medico("3102", 102, 40, "F", "Dra. Maria Lopez", "CC", "1984-08-20", "Av 60", "Bogotá", "Médico General", 1002, 4200000, "Activo", "1pm-7pm", "No", "Tarde", "Pediatría", "Vigente", "Consultorio 202"));
        lista.add(new Medico("3103", 103, 45, "M", "Dr. Jorge Ruiz", "CC", "1979-02-15", "Centro", "Cali", "Cirujano", 1003, 7000000, "Activo", "Variable", "Sí", "Noche", "Cirugía", "Vigente", "Quirofano A"));
        lista.add(new Medico("3104", 104, 32, "F", "Dra. Ana Rios", "CC", "1992-11-30", "Salado", "Ibagué", "Médico Especialista", 1004, 4800000, "Activo", "7am-1pm", "No", "Mañana", "Dermatología", "Vigente", "Consultorio 301"));
        lista.add(new Medico("3105", 105, 50, "M", "Dr. Luis Mora", "CC", "1974-06-10", "Jordan", "Medellín", "Médico Internista", 1005, 5500000, "Activo", "1pm-7pm", "No", "Tarde", "Medicina Interna", "Vigente", "Consultorio 105"));
        lista.add(new Medico("3106", 106, 38, "F", "Dra. Elena Sanz", "CC", "1986-03-22", "Picaleña", "Neiva", "Médico General", 1006, 4200000, "Activo", "7am-1pm", "No", "Mañana", "Urgencias", "Vigente", "Urgencias 1"));
        lista.add(new Medico("3107", 107, 55, "M", "Dr. Pedro Juan", "CC", "1969-09-05", "Cádiz", "Ibagué", "Especialista", 1007, 6000000, "Vacaciones", "N/A", "No", "N/A", "Ginecología", "Vigente", "Consultorio 402"));
        lista.add(new Medico("3108", 108, 29, "M", "Dr. Fabio Cano", "CC", "1995-12-12", "Ricaurte", "Espinal", "Médico Rural", 1008, 3000000, "Activo", "7am-7pm", "Sí", "Completo", "General", "Vigente", "Consultorio Rural"));
        lista.add(new Medico("3109", 109, 42, "F", "Dra. Clara Rosa", "CC", "1982-01-01", "Topacio", "Ibagué", "Médico Especialista", 1009, 5200000, "Activo", "1pm-7pm", "No", "Tarde", "Neurología", "Vigente", "Consultorio 505"));
        lista.add(new Medico("3110", 110, 48, "M", "Dr. Hugo Paz", "CC", "1976-07-14", "Belén", "Armenia", "Médico General", 1010, 4200000, "Activo", "7am-1pm", "No", "Mañana", "General", "Vigente", "Consultorio 102"));

        // --- 10 PACIENTES ---
        lista.add(new Paciente("3201", 201, 25, "M", "Juan Alarcón", "CC", "1999-04-04", "Arboleda", "Ibagué", "Soltero", 0, "Sanitas"));
        lista.add(new Paciente("3202", 202, 65, "F", "Marta Gómez", "CC", "1959-10-10", "Galarza", "Ibagué", "Viuda", 3, "Sura"));
        lista.add(new Paciente("3203", 203, 12, "M", "Pipe Bueno", "TI", "2012-05-20", "Estación", "Ibagué", "Soltero", 0, "Salud Total"));
        lista.add(new Paciente("3204", 204, 30, "F", "Sara Cruz", "CC", "1994-08-15", "Centro", "Cajamarca", "Casada", 1, "Nueva EPS"));
        lista.add(new Paciente("3205", 205, 18, "M", "Kevin Roldan", "CC", "2006-01-25", "Jardín", "Ibagué", "Soltero", 0, "Famisanar"));
        lista.add(new Paciente("3206", 206, 45, "F", "Lucía Mendez", "CC", "1981-03-30", "Kennedy", "Ibagué", "Unión Libre", 2, "Sanitas"));
        lista.add(new Paciente("3207", 207, 7, "F", "Sofia Niño", "RC", "2017-09-12", "Cádiz", "Ibagué", "Soltera", 0, "Sura"));
        lista.add(new Paciente("3208", 208, 55, "M", "Oscar Hurtado", "CC", "1969-02-28", "Ambalá", "Lérida", "Divorciado", 4, "Compensar"));
        lista.add(new Paciente("3209", 209, 22, "F", "Valentina Rios", "CC", "2004-11-03", "Interlaken", "Ibagué", "Soltera", 0, "Aliansalud"));
        lista.add(new Paciente("3210", 210, 38, "M", "Diego Torres", "CC", "1986-06-18", "Varsovia", "Ibagué", "Casado", 2, "Nueva EPS"));

        // --- 10 ENFERMEROS ---
        lista.add(new Enfermero("3301", 301, 28, "F", "Laura Téllez", "CC", "1996-05-12", "Piedrapintada", "Ibagué", "Enfermera Jefe", 2001, 2800000, "Activo", "7am-7pm", "Sí", "Día", "Dr. Camilo Perez"));
        lista.add(new Enfermero("3302", 302, 33, "M", "Andrés Cepeda", "CC", "1991-09-22", "Modelia", "Ibagué", "Auxiliar", 2002, 1800000, "Activo", "7pm-7am", "Sí", "Noche", "Dra. Maria Lopez"));
        lista.add(new Enfermero("3303", 303, 24, "F", "Paola Jara", "CC", "2000-02-14", "Vergel", "Ibagué", "Auxiliar", 2003, 1800000, "Activo", "7am-1pm", "No", "Mañana", "Dr. Jorge Ruiz"));
        lista.add(new Enfermero("3304", 304, 40, "M", "Yeison Jimenez", "CC", "1984-07-26", "Centro", "Manizales", "Enfermero Jefe", 2004, 2800000, "Activo", "1pm-7pm", "No", "Tarde", "Dr. Luis Mora"));
        lista.add(new Enfermero("3305", 305, 31, "F", "Arelys Henao", "CC", "1993-10-05", "Arkanzúa", "Ibagué", "Auxiliar", 2005, 1800000, "Licencia", "N/A", "No", "N/A", "Dra. Ana Rios"));
        lista.add(new Enfermero("3306", 306, 26, "M", "Jhonny Rivera", "CC", "1998-12-30", "Libertador", "Pereira", "Auxiliar", 2006, 1800000, "Activo", "7am-7pm", "Sí", "Día", "Dr. Pedro Juan"));
        lista.add(new Enfermero("3307", 307, 29, "F", "Francy", "CC", "1995-04-18", "Salado", "Ibagué", "Auxiliar", 2007, 1800000, "Activo", "7pm-7am", "Sí", "Noche", "Dr. Fabio Cano"));
        lista.add(new Enfermero("3308", 308, 35, "M", "Galy Galiano", "CC", "1989-01-20", "Jordan", "Cali", "Jefe Area", 2008, 3000000, "Activo", "7am-1pm", "No", "Mañana", "Dra. Clara Rosa"));
        lista.add(new Enfermero("3309", 309, 27, "F", "Shakira", "CC", "1997-02-02", "Praderas", "Barranquilla", "Auxiliar", 2009, 1800000, "Activo", "1pm-7pm", "No", "Tarde", "Dr. Hugo Paz"));
        lista.add(new Enfermero("3310", 310, 42, "M", "Juanes", "CC", "1982-08-07", "Santa Ana", "Medellín", "Enfermero Jefe", 2010, 2800000, "Activo", "Variable", "Sí", "Rotativo", "Dr. Camilo Perez"));

        // --- 10 ADMINISTRADORES ---
        lista.add(new Administrador("3401", 401, 40, "F", "Claudia Lopez", "CC", "1984-03-12", "Cádiz", "Bogotá", "Gerente", 3001, 8000000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Dirección General"));
        lista.add(new Administrador("3402", 402, 38, "M", "Federico G.", "CC", "1986-06-25", "Interlaken", "Medellín", "Subgerente", 3002, 6000000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Operaciones"));
        lista.add(new Administrador("3403", 403, 33, "F", "Irene V.", "CC", "1991-05-14", "Centro", "Ibagué", "Jefe RRHH", 3003, 4500000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Recursos Humanos"));
        lista.add(new Administrador("3404", 404, 45, "M", "Ricardo B.", "CC", "1979-11-20", "Ambalá", "Ibagué", "Contador", 3004, 4200000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Finanzas"));
        lista.add(new Administrador("3405", 405, 29, "F", "Francia M.", "CC", "1995-02-01", "Sur", "Cauca", "Secretaria", 3005, 2000000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Atención al Usuario"));
        lista.add(new Administrador("3406", 406, 52, "M", "Gustavo P.", "CC", "1972-04-19", "Belén", "Ciénaga", "Coordinador", 3006, 5000000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Logística"));
        lista.add(new Administrador("3407", 407, 31, "F", "Diana S.", "CC", "1993-08-30", "Macarena", "Ibagué", "Auditora", 3007, 3800000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Calidad"));
        lista.add(new Administrador("3408", 408, 36, "M", "Sergio F.", "CC", "1988-12-10", "Jordan", "Bogotá", "Analista", 3008, 3500000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Sistemas"));
        lista.add(new Administrador("3409", 409, 41, "F", "Marta L.", "CC", "1983-01-25", "Varsovia", "Ibagué", "Tesorera", 3009, 4000000, "Activo", "8am-5pm", "No", "Mañana/Tarde", "Finanzas"));
        lista.add(new Administrador("3410", 410, 44, "M", "Enrique P.", "CC", "1980-10-02", "Calle 10", "Ibagué", "Director Medico", 3010, 9000000, "Activo", "Flexible", "No", "Completo", "Dirección Médica"));

        System.out.println("\n>>> MODO DEMO: Se han cargado 40 registros de prueba exitosamente.");
        GestionCitas.inicializarConsultoriosDemo();
        GestionHistoriaClinica.inicializarHistoriasDemo();
    }
}