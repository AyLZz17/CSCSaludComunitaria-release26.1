package Utils;

import java.util.Scanner;

public class ValidadorEntrada {
    private static Scanner sc = new Scanner(System.in);

    
    public static int leerEnteroSeguro(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("ERROR: Ingrese un valor numerico valido.");
            }
        }
    }
}