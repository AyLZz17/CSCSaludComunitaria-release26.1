package Utils;

import java.util.Scanner;

import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.ServiciosPersona;
import Servicios.Notificaciones;

public class menuGestionPersonas
{
    
    //
    private static Notificaciones notificador = new Notificaciones();

    public static void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        System.out.println("==========================================");
        System.out.println("   SISTEMA DE SALUD COMUNITARIA (CSC)");
        System.out.println("==========================================");

        while (!salir) {
            System.out.println("\n--- MENU PRINCIPAL DE GESTION ---");
            System.out.println("1. Registrar nueva persona");
            System.out.println("2. Ver listados por tipo");
            System.out.println("3. Buscar persona por documento");
            System.out.println("4. Actualizar datos de un registro");
            System.out.println("5. Eliminar un registro");
            System.out.println("6. Salir al Menu Principal");
            System.out.print("Seleccione una opcion: ");

            int opcion = -1;
            try {
                // Uso de Integer.parseInt para evitar problemas con el salto de línea del scanner
                opcion = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero valido de la lista.");
                continue;
            }

            switch (opcion) {
                case 1:
                    ServiciosPersona.agregarPersona();
                    AuditoriaSistema.registrarAccion("AyLZz", "Registro de nueva persona");
                    break;
                case 2:
                    ServiciosPersona.mostrarPersonas();
                    break;
                case 3:
                    ServiciosPersona.buscarPersona();
                    break;
                case 4:
                    ServiciosPersona.actualizarPersona();
                    AuditoriaSistema.registrarAccion("AyLZz", "Actualizacion de registro");
                    break;
                case 5:
                    ServiciosPersona.eliminarPersona();
                    notificador.agregarNotificacion("Se ha eliminado un registro del sistema.");
                    AuditoriaSistema.registrarAccion("AyLZz", "Eliminacion de registro");
                    break;
                case 6:
                    System.out.println("Regresando al menu anterior...");
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion no reconocida. Intente de nuevo.");
            }
        }
        // Nota: No cerramos el scanner aquí porque cerraría System.in para todo el programa
    }
}