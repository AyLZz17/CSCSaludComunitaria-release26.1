package com.mycompany.cscsaludcomunitaria;

import Servicios.AuditoriaSistema;
import Servicios.Notificaciones;
import Utils.MenuClinico;
import Utils.MenuServiciosMEdicos;
import Utils.SimulacionDemo;
import Utils.ValidadorEntrada;
import Utils.menuGestionPersonas;


public class CSCSaludComunitaria {

    public static void main(String[] args) {
        
        AuditoriaSistema.registrarAccion("Sistema", "Inicio de aplicación - AyLZz");
        SimulacionDemo.cargarDatosDemo(); // Carga datos de prueba para demostración
        AuditoriaSistema.registrarAccion("Sistema", "Datos de demostración cargados");
        
        int opcion;

        do {
            System.out.println("\n==========================================");
            System.out.println("       CSC SALUD COMUNITARIA - MENU       ");
            System.out.println("==========================================");
            System.out.println("1. Gestion de Usuarios (CRUD Personas)");
            System.out.println("2. Servicios de Salud (Polimorfismo/Interfaz)");
            System.out.println("3. Gestion Clinica (Citas / Historia Clinica)");
            System.out.println("4. Ver Auditoria del Sistema (Uso de Maps)");
            System.out.println("5. Procesar todas las notificaciones");
            System.out.println("6. Atender/Eliminar la primera notificacion");
            System.out.println("0. Salir del Programa");
            System.out.println("------------------------------------------");
            
            opcion = ValidadorEntrada.leerEnteroSeguro("Seleccione una opcion: ");

            switch (opcion) {
                case 1:
                    menuGestionPersonas.mostrarMenu();
                    break;
                case 2:
                    MenuServiciosMEdicos.MenuServiciosMedicos();
                    break;
                case 3:
                    MenuClinico.mostrarMenuClinico();
                    break;
                case 4:
                    AuditoriaSistema.mostrarLogs();
                    break;
                case 5:
                    System.out.println("\n--- Procesando mensajes pendientes ---");
                    Notificaciones.procesarNotificaciones();
                    break;
                case 6:
                    Notificaciones.eliminarPrimeraNotificacion();
                    break;
                case 0:
                    System.out.println("Finalizando sistema... Gracias por usar CSC.");
                    break;
                default:
                    System.out.println("Opcion no reconocida. Intente de nuevo.");
            }
        } while (opcion != 0);
    }

}