# Procedimiento de Actualización de Personas por Tipo

## Descripción General

Se ha implementado un procedimiento completo para actualizar datos de personas en el sistema CSC Salud Comunitaria, organizados por tipo. El sistema valida el tipo de persona y pide los datos específicos según el tipo.

## Estructura Implementada

### 1. Servicio de Búsqueda y Validación: `ActualizarPersonaPorTipo.java`

**Ubicación:** `Servicios/GestionPersona/ActualizarPersonaPorTipo.java`

**Funcionalidad:**
- `buscarPersonaPorDocumento(int, Class)` - Busca una persona por documento y valida su tipo
- `buscarPaciente(int)` - Busca específicamente un paciente
- `buscarMedico(int)` - Busca específicamente un médico
- `buscarEnfermero(int)` - Busca específicamente un enfermero
- `buscarAdministrador(int)` - Busca específicamente un administrador
- `existePersona(int)` - Verifica si una persona existe
- `obtenerTipoPersona(int)` - Obtiene el tipo de persona

### 2. Interfaz Gráfica Principal: `GUIActualizarPersona.java`

**Ubicación:** `GUIServicioComunitarioCSC/GUIActualizarPersona.java`

**Descripción:**
- GUI principal que permite seleccionar el tipo de persona a actualizar
- Muestra un ComboBox con opciones: MEDICO, ENFERMERO, ADMINISTRADOR, PACIENTE
- Abre el formulario específico del tipo seleccionado

**Flujo:**
```
1. Usuario abre GUIActualizarPersona
2. Selecciona tipo de persona del ComboBox
3. Hace clic en "ABRIR FORMULARIO DE ACTUALIZACIÓN"
4. Se abre el GUI específico para ese tipo
```

### 3. Interfaces de Actualización por Tipo

#### a) **GUIActualizarMedico.java**
- **Ubicación:** `GUIServicioComunitarioCSC/ActualizarPersona/GUIActualizarMedico.java`
- **Campos actualizables:**
  - Datos básicos: Nombre, Contacto, Edad, Género, Fecha Nacimiento, Dirección, etc.
  - Datos laborales: Código Trabajador, Salario, Horario, Turno, Horario Rotativo
  - Datos específicos: Especialidad, Consultorio

#### b) **GUIActualizarPaciente.java**
- **Ubicación:** `GUIServicioComunitarioCSC/ActualizarPersona/GUIActualizarPaciente.java`
- **Campos actualizables:**
  - Datos básicos: Nombre, Contacto, Edad, Género, Fecha Nacimiento, Dirección, etc.
  - Datos específicos: Estado Civil, Número de Hijos, EPS

#### c) **GUIActualizarEnfermero.java**
- **Ubicación:** `GUIServicioComunitarioCSC/ActualizarPersona/GUIActualizarEnfermero.java`
- **Campos actualizables:**
  - Datos básicos: Nombre, Contacto, Edad, Género, Fecha Nacimiento, Dirección, etc.
  - Datos laborales: Código Trabajador, Salario, Horario, Turno, Horario Rotativo
  - Datos específicos: Médico Asignado

#### d) **GUIActualizarAdministrador.java**
- **Ubicación:** `GUIServicioComunitarioCSC/ActualizarPersona/GUIActualizarAdministrador.java`
- **Campos actualizables:**
  - Datos básicos: Nombre, Contacto, Edad, Género, Fecha Nacimiento, Dirección, etc.
  - Datos laborales: Código Trabajador, Salario, Horario, Turno, Horario Rotativo
  - Datos específicos: Departamento

## Flujo de Actualización por Tipo

### Flujo General

```
┌─────────────────────────────────────────┐
│   GUIActualizarPersona (Principal)      │
│                                         │
│  Seleccionar Tipo:                      │
│  □ Médico                               │
│  □ Enfermero                            │
│  □ Administrador                        │
│  □ Paciente                             │
└────────────┬────────────────────────────┘
             │
             ├─── Médico ──────┬──→ GUIActualizarMedico
             │                 ├─ Buscar por Documento
             │                 ├─ Cargar Datos Actuales
             │                 ├─ Mostrar Campos Específicos
             │                 └─ Guardar Cambios
             │
             ├─── Paciente ────┬──→ GUIActualizarPaciente
             │                 └─ [Similar al proceso anterior]
             │
             ├─── Enfermero ───┬──→ GUIActualizarEnfermero
             │                 └─ [Similar al proceso anterior]
             │
             └─── Admin ───────┬──→ GUIActualizarAdministrador
                               └─ [Similar al proceso anterior]
```

### Proceso en Cada GUI Específico

```
1. ┌─────────────────────────┐
   │  GUI de Actualización   │
   │  (ej: Médico)           │
   └────────────┬────────────┘
                │
2.              ▼
   ┌─────────────────────────────────┐
   │ Ingrese Documento de Identidad  │
   │ [                    ] [BUSCAR]  │
   └────────────┬────────────────────┘
                │
3.              ▼
   ┌──────────────────────────────────┐
   │ Búsqueda y Validación            │
   │ - Buscar en RegistrosPersonas    │
   │ - Validar tipo de persona        │
   │ - Cargar datos actuales          │
   └────────────┬─────────────────────┘
                │
4.              ▼
        ┌───────────────┐
        │ ¿Encontrado?  │
        └───────┬───────┘
         Sí     │     No
             (4a)     (4b)
                      ▼
                  Mostrar Error
                  Limpiar Campos
                  
       (4a) ▼
   ┌──────────────────────────────────┐
   │ Habilitar Campos de Edición      │
   │ - Mostrar datos actuales         │
   │ - Permitir modificaciones        │
   └────────────┬─────────────────────┘
                │
5.              ▼
   ┌──────────────────────────────────┐
   │ Usuario Actualiza Datos          │
   │ [Nombre: ...................]     │
   │ [Contacto: ................]      │
   │ [Campos específicos del tipo]     │
   │                                  │
   │ [GUARDAR]  [CANCELAR]            │
   └────────────┬─────────────────────┘
                │
6.              ▼
   ┌──────────────────────────────────┐
   │ Validar Datos                    │
   │ - Verificar campos numéricos     │
   │ - Validar rangos de valores      │
   └────────────┬─────────────────────┘
                │
7.              ▼
        ┌───────────────┐
        │  ¿Válido?     │
        └───────┬───────┘
         Sí     │     No
            (7a)     (7b)
                      ▼
                  Mostrar Error
                  
       (7a) ▼
   ┌──────────────────────────────────┐
   │ Guardar Cambios                  │
   │ - Actualizar objeto en memoria   │
   │ - Registrar en auditoría         │
   │ - Mostrar confirmación           │
   └──────────────────────────────────┘
```

## Validaciones Implementadas

### 1. Validación de Documento
- Debe ser un número entero válido
- Debe existir en RegistrosPersonas
- Debe coincider con el tipo de persona seleccionado

### 2. Validación de Campos Numéricos
- Edad: Valor entero positivo
- Salario: Valor decimal positivo
- Código Trabajador: Número entero
- Hijos: Número entero no negativo

### 3. Validación de Tipo de Persona
- Busca específicamente el tipo seleccionado
- Si existe otra persona con ese documento pero de tipo diferente, muestra error

## Datos Actualizables por Tipo

### PACIENTE
```
Datos Básicos:
- Nombre Completo
- Contacto
- Edad
- Género de Nacimiento
- Fecha de Nacimiento
- Dirección
- Tipo de Documento
- Lugar de Nacimiento

Datos Específicos:
- Estado Civil
- Número de Hijos
- EPS (Entidad Prestadora de Salud)
```

### MEDICO
```
Datos Básicos:
- Nombre Completo
- Contacto
- Edad
- Género de Nacimiento
- Fecha de Nacimiento
- Dirección
- Tipo de Documento
- Lugar de Nacimiento

Datos Laborales:
- Código Trabajador
- Salario
- Horario de Trabajo
- Turno
- Horario Rotativo

Datos Específicos:
- Especialidad
- Consultorio Asignado
```

### ENFERMERO
```
Datos Básicos:
- Nombre Completo
- Contacto
- Edad
- Género de Nacimiento
- Fecha de Nacimiento
- Dirección
- Tipo de Documento
- Lugar de Nacimiento

Datos Laborales:
- Código Trabajador
- Salario
- Horario de Trabajo
- Turno
- Horario Rotativo

Datos Específicos:
- Médico Asignado
```

### ADMINISTRADOR
```
Datos Básicos:
- Nombre Completo
- Contacto
- Edad
- Género de Nacimiento
- Fecha de Nacimiento
- Dirección
- Tipo de Documento
- Lugar de Nacimiento

Datos Laborales:
- Código Trabajador
- Salario
- Horario de Trabajo
- Turno
- Horario Rotativo

Datos Específicos:
- Departamento
```

## Características Principales

### ✓ Búsqueda Validada
- Busca por documento de identidad
- Valida que existe la persona
- Valida que es del tipo correcto

### ✓ Carga de Datos Actuales
- Al encontrar la persona, se cargan todos sus datos actuales
- El usuario ve qué está editando

### ✓ Edición Selectively Habilitada
- Los campos solo se habilitan después de encontrar la persona
- Previene errores de usuario

### ✓ Validación de Entrada
- Campos numéricos se validan antes de guardar
- Mensajes de error claros y específicos

### ✓ Auditoría
- Cada actualización se registra en el sistema de auditoría
- Rastrea quién actualizó y qué persona

### ✓ Interfaz Intuitiva
- Nombres de campos claros
- Mensajes de retroalimentación en español
- Botones de acción obvios

## Integración con Sistema Existente

### Acceso
Se puede acceder desde el menú principal del sistema:
1. Ir a "Actualizar Persona"
2. Seleccionar tipo
3. Actualizar datos

### Datos Persistentes
- Los cambios se guardan en RegistrosPersonas
- Se mantiene sincronización con toda la aplicación
- Cambios inmediatos sin necesidad de reiniciar

### Auditoría
- AuditoriaSistema.registrarAccion() registra cada actualización
- Log completo de cambios realizados

## Ejemplos de Uso

### Ejemplo 1: Actualizar Médico
```
1. Abrir GUIActualizarPersona
2. Seleccionar "MEDICO"
3. Hacer clic en "ABRIR FORMULARIO DE ACTUALIZACIÓN"
4. Se abre GUIActualizarMedico
5. Ingresar documento: 123456789
6. Hacer clic en BUSCAR
7. Se cargan datos del médico
8. Actualizar especialidad, consultorio, etc.
9. Hacer clic en GUARDAR
10. Se registra en auditoría y se cierra
```

### Ejemplo 2: Actualizar Paciente
```
1. Abrir GUIActualizarPersona
2. Seleccionar "PACIENTE"
3. Hacer clic en "ABRIR FORMULARIO DE ACTUALIZACIÓN"
4. Se abre GUIActualizarPaciente
5. Ingresar documento: 987654321
6. Hacer clic en BUSCAR
7. Se cargan datos del paciente
8. Actualizar EPS, estado civil, etc.
9. Hacer clic en GUARDAR
10. Se registra en auditoría y se cierra
```

## Manejo de Errores

| Error | Causa | Solución |
|-------|-------|----------|
| "Por favor seleccione un tipo de persona" | No seleccionó tipo en ComboBox | Seleccione un tipo antes de continuar |
| "El documento debe ser un número válido" | Ingresó caracteres no numéricos | Ingrese solo números |
| "No se encontró un [tipo] con ese documento" | Documento no existe o tipo no coincide | Verifique el documento ingresado |
| "Verifique que todos los campos numéricos sean válidos" | Campos como edad o salario tienen valores inválidos | Revise y corrija valores numéricos |

## Notas Importantes

1. **Persistencia**: Los cambios se guardan en la lista de RegistrosPersonas en memoria
2. **Validación**: El sistema valida tanto que exista la persona como que sea del tipo correcto
3. **Campos Específicos**: Cada tipo tiene sus propios campos que solo aparecen en ese GUI
4. **Auditoría**: Toda actualización queda registrada para auditoría del sistema
5. **Interfaz**: Los campos se habilitan solo después de encontrar la persona, evitando errores

---

**Versión:** 1.0  
**Fecha:** Mayo 2026  
**Sistema:** CSC Salud Comunitaria
