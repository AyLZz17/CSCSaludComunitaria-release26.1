# CSC Salud Comunitaria

## Índice de Acceso Rápido

* [Descripción del Proyecto](#descripción-del-proyecto)
* [Objetivos del Proyecto](#objetivos-del-proyecto)
* [Tecnologías Utilizadas](#tecnologías-utilizadas)
* [Arquitectura del Proyecto](#arquitectura-del-proyecto)
* [Principios de Diseño Aplicados](#principios-de-diseño-aplicados)
* [Funcionalidades Principales](#funcionalidades-principales)
* [Modelo Relacional General](#modelo-relacional-general)
* [Estructuras de Datos Utilizadas](#estructuras-de-datos-utilizadas)
* [Gestión de Datos](#gestión-de-datos)
* [Interfaz Gráfica](#interfaz-gráfica)
* [Buenas Prácticas Implementadas](#buenas-prácticas-implementadas)
* [Instalación](#instalación)
* [Estado del Proyecto](#estado-del-proyecto)
* [Autor](#autor)
* [Licencia](#licencia)

Sistema de gestión para un Centro de Salud Comunitario desarrollado en Java aplicando Programación Orientada a Objetos (POO), estructuras de datos y arquitectura modular.

---

# Descripción del Proyecto

CSC Salud Comunitaria es una aplicación diseñada para administrar procesos fundamentales de un centro médico comunitario, permitiendo la gestión organizada de:

* Pacientes
* Médicos
* Citas médicas
* Historias clínicas
* Servicios médicos
* Administración del sistema

El proyecto fue desarrollado con un enfoque académico y arquitectónico, implementando buenas prácticas de diseño de software, separación por capas y modularización de componentes.

---

# Objetivos del Proyecto

* Aplicar conceptos de Programación Orientada a Objetos.
* Implementar estructuras de datos en un sistema real.
* Diseñar una arquitectura escalable y mantenible.
* Gestionar información clínica de manera organizada.
* Simular el funcionamiento básico de un centro de salud comunitario.

---

# Tecnologías Utilizadas

| Tecnología              | Uso                            |
| ----------------------- | ------------------------------ |
| Java                    | Lógica principal del sistema   |
| Swing / GUI             | Interfaz gráfica               |
| POO                     | Modelado del sistema           |
| Estructuras de Datos    | Gestión interna de información |
| Persistencia en memoria | Gestión temporal de datos      |
| NetBeans                | Entorno de desarrollo          |
| Git & GitHub            | Control de versiones           |

---

# Arquitectura del Proyecto

El proyecto está organizado en módulos independientes para mejorar la mantenibilidad y escalabilidad.

```text
CSCSaludComunitaria
│
├── Model
│   ├── Personas
│   ├── Citas
│   ├── HistoriaClinica
│   └── Servicios
│
├── Servicios
│   ├── GestionPersonas
│   ├── GestionCitas
│   └── HistoriasClinicas
│
├── GUI
│
│
├── Utilidades
│
└── Main
```

---

# Principios de Diseño Aplicados

## Programación Orientada a Objetos

El sistema implementa:

* Encapsulamiento
* Herencia
* Polimorfismo
* Abstracción

Ejemplo:

```text
Persona
 ├── Paciente
 ├── Medico
 └── Administrador
```

---

# Funcionalidades Principales

## Gestión de Pacientes

* Registro de pacientes
* Consulta de información
* Actualización de datos
* Gestión de historial clínico

## Gestión de Médicos

* Registro de médicos
* Especialidades
* Administración de disponibilidad

## Gestión de Citas

* Agendamiento de citas
* Cancelación de citas
* Consulta de horarios
* Relación médico-paciente

## Historias Clínicas

* Registro de consultas
* Diagnósticos
* Tratamientos
* Seguimiento clínico

## Administración

* Gestión del sistema
* Control administrativo
* Organización de módulos

---

# Modelo Relacional General

Relaciones principales del sistema:

* Un paciente puede tener múltiples citas.
* Un médico puede atender múltiples citas.
* Un paciente posee una historia clínica.
* Una historia clínica contiene múltiples consultas.
* Una factura puede contener múltiples servicios.

---

# Estructuras de Datos Utilizadas

El sistema contempla el uso de estructuras de datos para optimizar la gestión de información:

* Listas
* Colas
* Árboles
* Colecciones dinámicas

Aplicaciones:

| Estructura | Uso                       |
| ---------- | ------------------------- |
| Cola       | Gestión de turnos y citas |
| Lista      | Pacientes e historiales   |
| Árbol      | Búsquedas organizadas     |

---

# Gestión de Datos

Actualmente el proyecto trabaja con almacenamiento temporal en memoria utilizando estructuras de datos y objetos durante la ejecución del programa.

No se implementa persistencia en bases de datos en esta versión.

La arquitectura fue diseñada para permitir una futura integración con sistemas de persistencia como Oracle, MySQL o PostgreSQL.

---

# Interfaz Gráfica

La aplicación incluye una interfaz gráfica orientada a escritorio para facilitar la interacción del usuario con el sistema.

Características:

* Navegación modular
* Formularios de registro
* Gestión visual de citas
* Administración intuitiva

---

# Buenas Prácticas Implementadas

* Separación de responsabilidades
* Modularización
* Arquitectura escalable
* Reutilización de código
* Organización por paquetes
* Manejo centralizado de lógica

---

# Instalación

## Requisitos

* Java JDK 17 o superior
* NetBeans IDE (Recomendado para editar la GUI) o Visual Studio Code 
* Git

## Clonar el Repositorio

```bash
git clone <URL_DEL_REPOSITORIO>
```

## Ejecutar el Proyecto

1. Abrir el proyecto en NetBeans.
2. Compilar el proyecto.
3. Ejecutar la clase principal.

---


# Estado del Proyecto

Proyecto en desarrollo activo.

Actualmente incluye:

* Arquitectura principal
* Modelado orientado a objetos
* Gestión de citas
* Gestión de pacientes
* Historias clínicas
* Estructura modular

---

# Autores

AyLZz (Daniel Ayala), Laura Ramirez, Johan Soto

Proyecto desarrollado como sistema académico y arquitectónico para gestión de un Centro de Salud Comunitario.

---

# Licencia

Este proyecto es de uso académico y educativo.
