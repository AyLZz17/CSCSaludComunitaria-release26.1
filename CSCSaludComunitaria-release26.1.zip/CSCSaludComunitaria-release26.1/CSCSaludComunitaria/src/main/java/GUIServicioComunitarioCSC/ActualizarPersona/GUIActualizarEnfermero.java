package GUIServicioComunitarioCSC.ActualizarPersona;

import javax.swing.JOptionPane;

import Model.Persona.Enfermero;
import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.ActualizarPersonaPorTipo;

/**
 * GUI para actualizar datos de un Enfermero.
 * Permite buscar un enfermero por documento y actualizar sus datos personales y laborales.
 * 
 * @author CSC Salud Comunitaria
 */
public class GUIActualizarEnfermero extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIActualizarEnfermero.class.getName());
    private Enfermero enfermeroActual = null;

    public GUIActualizarEnfermero() {
        initComponents();
        habilitarPanel(false);
    }

    private void habilitarPanel(boolean habilitar) {
        txtNombreCompleto.setEnabled(habilitar);
        txtContacto.setEnabled(habilitar);
        txtEdad.setEnabled(habilitar);
        cmbGeneroNacimiento.setEnabled(habilitar);
        txtFechaNacimiento.setEnabled(habilitar);
        txtDireccion.setEnabled(habilitar);
        cmbTipoDoc.setEnabled(habilitar);
        txtLugarNacimiento.setEnabled(habilitar);
        txtCodigoTrabajador.setEnabled(habilitar);
        txtSalario.setEnabled(habilitar);
        txtHorarioTrabajo.setEnabled(habilitar);
        cmbTurno.setEnabled(habilitar);
        cmbHorarioRotativo.setEnabled(habilitar);
        txtMedicoAsignado.setEnabled(habilitar);
        btnGuardarEnfermero.setEnabled(habilitar);
    }

    private void cargarDatos(Enfermero enfermero) {
        txtDocumentoIdentidad.setText(String.valueOf(enfermero.getDocumentoIdentidad()));
        txtNombreCompleto.setText(enfermero.getNombreCompleto());
        txtContacto.setText(enfermero.getContacto());
        txtEdad.setText(String.valueOf(enfermero.getEdad()));
        cmbGeneroNacimiento.setSelectedItem(enfermero.getGeneroNacimiento());
        txtFechaNacimiento.setText(enfermero.getFechaNacimiento());
        txtDireccion.setText(enfermero.getDireccion());
        cmbTipoDoc.setSelectedItem(enfermero.getTipoDocumento());
        txtLugarNacimiento.setText(enfermero.getLugarNacimiento());
        txtCodigoTrabajador.setText(String.valueOf(enfermero.getCodigoTrabajador()));
        txtSalario.setText(String.valueOf(enfermero.getSalario()));
        txtHorarioTrabajo.setText(enfermero.getHorario());
        cmbTurno.setSelectedItem(enfermero.getTurno());
        cmbHorarioRotativo.setSelectedItem(enfermero.getHorarioRotativo());
        txtMedicoAsignado.setText(enfermero.getMedicoAsignado());
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabelTitulo = new javax.swing.JLabel();
        txtDocumentoIdentidad = new javax.swing.JTextField();
        txtNombreCompleto = new javax.swing.JTextField();
        txtContacto = new javax.swing.JTextField();
        txtEdad = new javax.swing.JTextField();
        cmbGeneroNacimiento = new javax.swing.JComboBox<>();
        txtFechaNacimiento = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        cmbTipoDoc = new javax.swing.JComboBox<>();
        txtLugarNacimiento = new javax.swing.JTextField();
        txtCodigoTrabajador = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        txtHorarioTrabajo = new javax.swing.JTextField();
        cmbTurno = new javax.swing.JComboBox<>();
        cmbHorarioRotativo = new javax.swing.JComboBox<>();
        txtMedicoAsignado = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnGuardarEnfermero = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setTitle("Actualizar Enfermero");
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 1, 24));
        jLabelTitulo.setText("ACTUALIZAR ENFERMERO");

        jLabel1.setText("Documento Identidad:");
        jLabel2.setText("Nombre Completo:");
        jLabel3.setText("Contacto:");
        jLabel4.setText("Edad:");
        jLabel5.setText("Género:");
        jLabel6.setText("Fecha Nacimiento:");
        jLabel7.setText("Dirección:");
        jLabel8.setText("Tipo Documento:");
        jLabel9.setText("Lugar Nacimiento:");
        jLabel10.setText("Código Trabajador:");
        jLabel11.setText("Salario:");
        jLabel12.setText("Horario Trabajo:");
        jLabel13.setText("Turno:");
        jLabel14.setText("Médico Asignado:");

        cmbGeneroNacimiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "H" }));
        cmbTipoDoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CC", "CE", "TI", "PEP", "PA" }));
        cmbTurno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Diurno", "Nocturno", "Mixto" }));
        cmbHorarioRotativo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sí", "No" }));

        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(evt -> btnBuscarActionPerformed(evt));

        btnGuardarEnfermero.setText("GUARDAR");
        btnGuardarEnfermero.addActionListener(evt -> btnGuardarEnfermeroActionPerformed(evt));

        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(evt -> dispose());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelTitulo)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(10, 10, 10)
                        .addComponent(txtDocumentoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnBuscar))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9))
                            .addGap(20, 20, 20)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtNombreCompleto, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtContacto, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtEdad, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(cmbGeneroNacimiento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(cmbTipoDoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtLugarNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                            .addGap(50, 50, 50)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10)
                                .addComponent(jLabel11)
                                .addComponent(jLabel12)
                                .addComponent(jLabel13)
                                .addComponent(jLabel14))
                            .addGap(20, 20, 20)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtCodigoTrabajador, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(txtSalario, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(txtHorarioTrabajo, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(cmbTurno, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtMedicoAsignado, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(150, 150, 150)
                            .addComponent(btnGuardarEnfermero, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(50, 50, 50)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabelTitulo)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtDocumentoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNombreCompleto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtCodigoTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(txtSalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtHorarioTrabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmbGeneroNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(cmbTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(txtMedicoAsignado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(cmbTipoDoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtLugarNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarEnfermero)
                    .addComponent(btnCancelar))
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        String docStr = txtDocumentoIdentidad.getText().trim();
        
        if (docStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un documento de identidad.", 
                "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int documento = Integer.parseInt(docStr);
            Enfermero enfermero = ActualizarPersonaPorTipo.buscarEnfermero(documento);
            
            if (enfermero != null) {
                enfermeroActual = enfermero;
                cargarDatos(enfermero);
                habilitarPanel(true);
                JOptionPane.showMessageDialog(this, "Enfermero encontrado. Puede actualizar los datos.", 
                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
            } else {
                habilitarPanel(false);
                JOptionPane.showMessageDialog(this, "No se encontró un enfermero con ese documento.", 
                    "No encontrado", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El documento debe ser un número válido.", 
                "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnGuardarEnfermeroActionPerformed(java.awt.event.ActionEvent evt) {
        if (enfermeroActual == null) {
            JOptionPane.showMessageDialog(this, "Por favor busque un enfermero primero.", 
                "Enfermero no cargado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Actualizar datos básicos
            enfermeroActual.setNombreCompleto(txtNombreCompleto.getText());
            enfermeroActual.setContacto(txtContacto.getText());
            enfermeroActual.setEdad(Integer.parseInt(txtEdad.getText()));
            enfermeroActual.setGeneroNacimiento((String) cmbGeneroNacimiento.getSelectedItem());
            enfermeroActual.setFechaNacimiento(txtFechaNacimiento.getText());
            enfermeroActual.setDireccion(txtDireccion.getText());
            enfermeroActual.setTipoDocumento((String) cmbTipoDoc.getSelectedItem());
            enfermeroActual.setLugarNacimiento(txtLugarNacimiento.getText());
            
            // Actualizar datos de trabajador
            enfermeroActual.setCodigoTrabajador(Integer.parseInt(txtCodigoTrabajador.getText()));
            enfermeroActual.setSalario(Double.parseDouble(txtSalario.getText()));
            enfermeroActual.setHorario(txtHorarioTrabajo.getText());
            enfermeroActual.setTurno((String) cmbTurno.getSelectedItem());
            enfermeroActual.setHorarioRotativo((String) cmbHorarioRotativo.getSelectedItem());
            
            // Actualizar datos específicos de enfermero
            enfermeroActual.setMedicoAsignado(txtMedicoAsignado.getText());
            
            // Registrar en auditoría
            AuditoriaSistema.registrarAccion("Sistema", "Actualización de Enfermero: " + enfermeroActual.getNombreCompleto());
            
            JOptionPane.showMessageDialog(this, "Enfermero actualizado correctamente.", 
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            // Limpiar formulario
            limpiarFormulario();
            habilitarPanel(false);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Verifique que todos los campos numéricos sean válidos.", 
                "Error de validación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarFormulario() {
        txtDocumentoIdentidad.setText("");
        txtNombreCompleto.setText("");
        txtContacto.setText("");
        txtEdad.setText("");
        txtFechaNacimiento.setText("");
        txtDireccion.setText("");
        txtLugarNacimiento.setText("");
        txtCodigoTrabajador.setText("");
        txtSalario.setText("");
        txtHorarioTrabajo.setText("");
        txtMedicoAsignado.setText("");
        cmbGeneroNacimiento.setSelectedIndex(0);
        cmbTipoDoc.setSelectedIndex(0);
        cmbTurno.setSelectedIndex(0);
        cmbHorarioRotativo.setSelectedIndex(0);
        enfermeroActual = null;
    }

    // Declaración de variables
    private javax.swing.JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9, jLabel10, jLabel11, jLabel12, jLabel13, jLabel14;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JTextField txtDocumentoIdentidad, txtNombreCompleto, txtContacto, txtEdad, txtFechaNacimiento, txtDireccion, txtLugarNacimiento, txtCodigoTrabajador, txtSalario, txtHorarioTrabajo, txtMedicoAsignado;
    private javax.swing.JComboBox<String> cmbGeneroNacimiento, cmbTipoDoc, cmbTurno, cmbHorarioRotativo;
    private javax.swing.JButton btnBuscar, btnGuardarEnfermero, btnCancelar;
}
