package GUIServicioComunitarioCSC.ActualizarPersona;

import javax.swing.JOptionPane;

import Model.Citas.Consultorio;
import Model.Persona.Medico;
import Servicios.AuditoriaSistema;
import Servicios.GestionCitas.GestionCitas;
import Servicios.GestionPersona.ActualizarPersonaPorTipo;

/**
 * GUI para actualizar datos de un Médico.
 * Permite buscar un médico por documento y actualizar sus datos personales y laborales.
 * 
 * @author CSC Salud Comunitaria
 */
public class GUIActualizarMedico extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIActualizarMedico.class.getName());
    private Medico medicoActual = null;

    public GUIActualizarMedico() {
        initComponents();
        cargarConsultorios();
        // Inicialmente desabilitar el panel de edición
        habilitarPanel(false);
    }

    private void cargarConsultorios() {
        cmbConsultorio.removeAllItems();
        java.util.List<Consultorio> listaConsultorios = GestionCitas.obtenerConsultorios();
        if (listaConsultorios.isEmpty()) {
            cmbConsultorio.addItem("No hay consultorios");
            return;
        }
        java.util.Set<String> nombresConsultorios = new java.util.LinkedHashSet<>();
        for (Consultorio consultorio : listaConsultorios) {
            nombresConsultorios.add(consultorio.getNombre());
        }
        for (String nombre : nombresConsultorios) {
            cmbConsultorio.addItem(nombre);
        }
    }

    private void habilitarPanel(boolean habilitar) {
        txtNombreCompleto.setEnabled(habilitar);
        txtContacto.setEnabled(habilitar);
        txtEdad.setEnabled(habilitar);
        cmbGeneroNacimiento.setEnabled(habilitar);
        txtFechaNacimiento.setEnabled(habilitar);
        txtDireccion.setEnabled(habilitar);
        cmbTipoDoc.setEnabled(habilitar);
        txtLugarNacimiento.setEnabled(habilitar);
        cmbTurno.setEnabled(habilitar);
        cmbHorarioRotativo.setEnabled(habilitar);
        txtSalario.setEnabled(habilitar);
        txtEspecialidad.setEnabled(habilitar);
        cmbConsultorio.setEnabled(habilitar);
        txtHorarioTrabajo.setEnabled(habilitar);
        txtCodigoTrabajador.setEnabled(habilitar);
        btnGuardarMedico.setEnabled(habilitar);
    }

    private void cargarDatos(Medico medico) {
        txtDocumentoIdentidad.setText(String.valueOf(medico.getDocumentoIdentidad()));
        txtNombreCompleto.setText(medico.getNombreCompleto());
        txtContacto.setText(medico.getContacto());
        txtEdad.setText(String.valueOf(medico.getEdad()));
        cmbGeneroNacimiento.setSelectedItem(medico.getGeneroNacimiento());
        txtFechaNacimiento.setText(medico.getFechaNacimiento());
        txtDireccion.setText(medico.getDireccion());
        cmbTipoDoc.setSelectedItem(medico.getTipoDocumento());
        txtLugarNacimiento.setText(medico.getLugarNacimiento());
        txtCodigoTrabajador.setText(String.valueOf(medico.getCodigoTrabajador()));
        txtSalario.setText(String.valueOf(medico.getSalario()));
        txtHorarioTrabajo.setText(medico.getHorario());
        cmbTurno.setSelectedItem(medico.getTurno());
        cmbHorarioRotativo.setSelectedItem(medico.getHorarioRotativo());
        txtEspecialidad.setText(medico.getEspecialidad());
        cmbConsultorio.setSelectedItem(medico.getConsultorio());
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabelTitulo = new javax.swing.JLabel();
        txtDocumentoIdentidad = new javax.swing.JTextField();
        txtNombreCompleto = new javax.swing.JTextField();
        txtContacto = new javax.swing.JTextField();
        txtEdad = new javax.swing.JTextField();
        cmbGeneroNacimiento = new javax.swing.JComboBox<>();
        txtFechaNacimiento = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        cmbTipoDoc = new javax.swing.JComboBox<>();
        txtLugarNacimiento = new javax.swing.JTextField();
        cmbTurno = new javax.swing.JComboBox<>();
        cmbHorarioRotativo = new javax.swing.JComboBox<>();
        txtSalario = new javax.swing.JTextField();
        txtEspecialidad = new javax.swing.JTextField();
        cmbConsultorio = new javax.swing.JComboBox<>();
        txtHorarioTrabajo = new javax.swing.JTextField();
        txtCodigoTrabajador = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnGuardarMedico = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setTitle("Actualizar Médico");
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 1, 24));
        jLabelTitulo.setText("ACTUALIZAR MÉDICO");

        jLabel1.setText("Documento Identidad:");
        jLabel2.setText("Nombre Completo:");
        jLabel3.setText("Contacto:");
        jLabel4.setText("Edad:");
        jLabel5.setText("Género:");
        jLabel6.setText("Fecha Nacimiento:");
        jLabel7.setText("Dirección:");
        jLabel8.setText("Tipo Documento:");
        jLabel9.setText("Lugar Nacimiento:");
        jLabel10.setText("Código Trabajador:");
        jLabel11.setText("Salario:");
        jLabel12.setText("Horario Trabajo:");
        jLabel13.setText("Turno:");
        jLabel14.setText("Horario Rotativo:");
        jLabel15.setText("Especialidad:");
        jLabel16.setText("Consultorio:");

        cmbGeneroNacimiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "H" }));
        cmbTipoDoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CC", "CE", "TI", "PEP", "PA" }));
        cmbTurno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Diurno", "Nocturno", "Mixto" }));
        cmbHorarioRotativo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sí", "No" }));

        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(evt -> btnBuscarActionPerformed(evt));

        btnGuardarMedico.setText("GUARDAR");
        btnGuardarMedico.addActionListener(evt -> btnGuardarMedicoActionPerformed(evt));

        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(evt -> dispose());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelTitulo)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(10, 10, 10)
                        .addComponent(txtDocumentoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnBuscar))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9))
                            .addGap(20, 20, 20)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtNombreCompleto, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtContacto, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtEdad, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(cmbGeneroNacimiento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(cmbTipoDoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtLugarNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                            .addGap(50, 50, 50)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10)
                                .addComponent(jLabel11)
                                .addComponent(jLabel12)
                                .addComponent(jLabel13)
                                .addComponent(jLabel14)
                                .addComponent(jLabel15)
                                .addComponent(jLabel16))
                            .addGap(20, 20, 20)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtCodigoTrabajador, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(txtSalario, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(txtHorarioTrabajo, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(cmbTurno, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cmbHorarioRotativo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtEspecialidad, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                .addComponent(cmbConsultorio, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(150, 150, 150)
                            .addComponent(btnGuardarMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(50, 50, 50)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabelTitulo)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtDocumentoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNombreCompleto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtCodigoTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(txtSalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtHorarioTrabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmbGeneroNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(cmbTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(cmbHorarioRotativo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(cmbTipoDoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(cmbConsultorio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtLugarNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarMedico)
                    .addComponent(btnCancelar))
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        String docStr = txtDocumentoIdentidad.getText().trim();
        
        if (docStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un documento de identidad.", 
                "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int documento = Integer.parseInt(docStr);
            Medico medico = ActualizarPersonaPorTipo.buscarMedico(documento);
            
            if (medico != null) {
                medicoActual = medico;
                cargarDatos(medico);
                habilitarPanel(true);
                JOptionPane.showMessageDialog(this, "Médico encontrado. Puede actualizar los datos.", 
                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
            } else {
                habilitarPanel(false);
                JOptionPane.showMessageDialog(this, "No se encontró un médico con ese documento.", 
                    "No encontrado", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El documento debe ser un número válido.", 
                "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnGuardarMedicoActionPerformed(java.awt.event.ActionEvent evt) {
        if (medicoActual == null) {
            JOptionPane.showMessageDialog(this, "Por favor busque un médico primero.", 
                "Médico no cargado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Actualizar datos básicos
            medicoActual.setNombreCompleto(txtNombreCompleto.getText());
            medicoActual.setContacto(txtContacto.getText());
            medicoActual.setEdad(Integer.parseInt(txtEdad.getText()));
            medicoActual.setGeneroNacimiento((String) cmbGeneroNacimiento.getSelectedItem());
            medicoActual.setFechaNacimiento(txtFechaNacimiento.getText());
            medicoActual.setDireccion(txtDireccion.getText());
            medicoActual.setTipoDocumento((String) cmbTipoDoc.getSelectedItem());
            medicoActual.setLugarNacimiento(txtLugarNacimiento.getText());
            
            // Actualizar datos de trabajador
            medicoActual.setCodigoTrabajador(Integer.parseInt(txtCodigoTrabajador.getText()));
            medicoActual.setSalario(Double.parseDouble(txtSalario.getText()));
            medicoActual.setHorario(txtHorarioTrabajo.getText());
            medicoActual.setTurno((String) cmbTurno.getSelectedItem());
            medicoActual.setHorarioRotativo((String) cmbHorarioRotativo.getSelectedItem());
            
            // Actualizar datos específicos de médico
            medicoActual.setEspecialidad(txtEspecialidad.getText());
            medicoActual.setConsultorio((String) cmbConsultorio.getSelectedItem());
            
            // Registrar en auditoría
            AuditoriaSistema.registrarAccion("Sistema", "Actualización de Médico: " + medicoActual.getNombreCompleto());
            
            JOptionPane.showMessageDialog(this, "Médico actualizado correctamente.", 
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            // Limpiar formulario
            limpiarFormulario();
            habilitarPanel(false);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Verifique que todos los campos numéricos sean válidos.", 
                "Error de validación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarFormulario() {
        txtDocumentoIdentidad.setText("");
        txtNombreCompleto.setText("");
        txtContacto.setText("");
        txtEdad.setText("");
        txtFechaNacimiento.setText("");
        txtDireccion.setText("");
        txtLugarNacimiento.setText("");
        txtCodigoTrabajador.setText("");
        txtSalario.setText("");
        txtHorarioTrabajo.setText("");
        txtEspecialidad.setText("");
        cmbGeneroNacimiento.setSelectedIndex(0);
        cmbTipoDoc.setSelectedIndex(0);
        cmbTurno.setSelectedIndex(0);
        cmbHorarioRotativo.setSelectedIndex(0);
        cmbConsultorio.setSelectedIndex(0);
        medicoActual = null;
    }

    // Declaración de variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9, jLabel10, jLabel11, jLabel12, jLabel13, jLabel14, jLabel15, jLabel16, jLabel17, jLabel18;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JTextField txtDocumentoIdentidad, txtNombreCompleto, txtContacto, txtEdad, txtFechaNacimiento, txtDireccion, txtLugarNacimiento, txtCodigoTrabajador, txtSalario, txtHorarioTrabajo, txtEspecialidad;
    private javax.swing.JComboBox<String> cmbGeneroNacimiento, cmbTipoDoc, cmbTurno, cmbHorarioRotativo, cmbConsultorio;
    private javax.swing.JButton btnBuscar, btnGuardarMedico, btnCancelar;
}
