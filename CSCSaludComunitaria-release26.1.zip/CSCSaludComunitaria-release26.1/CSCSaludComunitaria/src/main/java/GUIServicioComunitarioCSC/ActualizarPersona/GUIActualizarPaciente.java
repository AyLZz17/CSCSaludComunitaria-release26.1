package GUIServicioComunitarioCSC.ActualizarPersona;

import javax.swing.JOptionPane;

import Model.Persona.Paciente;
import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.ActualizarPersonaPorTipo;

/**
 * GUI para actualizar datos de un Paciente.
 * Permite buscar un paciente por documento y actualizar sus datos personales.
 * 
 * @author CSC Salud Comunitaria
 */
public class GUIActualizarPaciente extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIActualizarPaciente.class.getName());
    private Paciente pacienteActual = null;

    public GUIActualizarPaciente() {
        initComponents();
        // Inicialmente desabilitar el panel de edición
        habilitarPanel(false);
    }

    private void habilitarPanel(boolean habilitar) {
        txtNombreCompleto.setEnabled(habilitar);
        txtContacto.setEnabled(habilitar);
        txtEdad.setEnabled(habilitar);
        cmbGeneroNacimiento.setEnabled(habilitar);
        txtFechaNacimiento.setEnabled(habilitar);
        txtDireccion.setEnabled(habilitar);
        cmbTipoDoc.setEnabled(habilitar);
        txtLugarNacimiento.setEnabled(habilitar);
        txtEstadoCivil.setEnabled(habilitar);
        txtHijos.setEnabled(habilitar);
        txtEps.setEnabled(habilitar);
        btnGuardarPaciente.setEnabled(habilitar);
    }

    private void cargarDatos(Paciente paciente) {
        txtDocumentoIdentidad.setText(String.valueOf(paciente.getDocumentoIdentidad()));
        txtNombreCompleto.setText(paciente.getNombreCompleto());
        txtContacto.setText(paciente.getContacto());
        txtEdad.setText(String.valueOf(paciente.getEdad()));
        cmbGeneroNacimiento.setSelectedItem(paciente.getGeneroNacimiento());
        txtFechaNacimiento.setText(paciente.getFechaNacimiento());
        txtDireccion.setText(paciente.getDireccion());
        cmbTipoDoc.setSelectedItem(paciente.getTipoDocumento());
        txtLugarNacimiento.setText(paciente.getLugarNacimiento());
        txtEstadoCivil.setText(paciente.getEstadoCivil());
        txtHijos.setText(String.valueOf(paciente.getHijos()));
        txtEps.setText(paciente.getEps());
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabelTitulo = new javax.swing.JLabel();
        txtDocumentoIdentidad = new javax.swing.JTextField();
        txtNombreCompleto = new javax.swing.JTextField();
        txtContacto = new javax.swing.JTextField();
        txtEdad = new javax.swing.JTextField();
        cmbGeneroNacimiento = new javax.swing.JComboBox<>();
        txtFechaNacimiento = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        cmbTipoDoc = new javax.swing.JComboBox<>();
        txtLugarNacimiento = new javax.swing.JTextField();
        txtEstadoCivil = new javax.swing.JTextField();
        txtHijos = new javax.swing.JTextField();
        txtEps = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnGuardarPaciente = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setTitle("Actualizar Paciente");
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 1, 24));
        jLabelTitulo.setText("ACTUALIZAR PACIENTE");

        jLabel1.setText("Documento Identidad:");
        jLabel2.setText("Nombre Completo:");
        jLabel3.setText("Contacto:");
        jLabel4.setText("Edad:");
        jLabel5.setText("Género:");
        jLabel6.setText("Fecha Nacimiento:");
        jLabel7.setText("Dirección:");
        jLabel8.setText("Tipo Documento:");
        jLabel9.setText("Lugar Nacimiento:");
        jLabel10.setText("Estado Civil:");
        jLabel11.setText("Número de Hijos:");
        jLabel12.setText("EPS:");

        cmbGeneroNacimiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "H" }));
        cmbTipoDoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CC", "CE", "TI", "PEP", "PA" }));

        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(evt -> btnBuscarActionPerformed(evt));

        btnGuardarPaciente.setText("GUARDAR");
        btnGuardarPaciente.addActionListener(evt -> btnGuardarPacienteActionPerformed(evt));

        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(evt -> dispose());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelTitulo)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(10, 10, 10)
                        .addComponent(txtDocumentoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnBuscar))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9)
                                .addComponent(jLabel10)
                                .addComponent(jLabel11)
                                .addComponent(jLabel12))
                            .addGap(20, 20, 20)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtNombreCompleto, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtContacto, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtEdad, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(cmbGeneroNacimiento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(cmbTipoDoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtLugarNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtEstadoCivil, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtHijos, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(txtEps, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(100, 100, 100)
                            .addComponent(btnGuardarPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(50, 50, 50)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabelTitulo)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtDocumentoIdentidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNombreCompleto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmbGeneroNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(cmbTipoDoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtLugarNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtHijos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtEps, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarPaciente)
                    .addComponent(btnCancelar))
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        String docStr = txtDocumentoIdentidad.getText().trim();
        
        if (docStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un documento de identidad.", 
                "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int documento = Integer.parseInt(docStr);
            Paciente paciente = ActualizarPersonaPorTipo.buscarPaciente(documento);
            
            if (paciente != null) {
                pacienteActual = paciente;
                cargarDatos(paciente);
                habilitarPanel(true);
                JOptionPane.showMessageDialog(this, "Paciente encontrado. Puede actualizar los datos.", 
                    "Búsqueda exitosa", JOptionPane.INFORMATION_MESSAGE);
            } else {
                habilitarPanel(false);
                JOptionPane.showMessageDialog(this, "No se encontró un paciente con ese documento.", 
                    "No encontrado", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El documento debe ser un número válido.", 
                "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnGuardarPacienteActionPerformed(java.awt.event.ActionEvent evt) {
        if (pacienteActual == null) {
            JOptionPane.showMessageDialog(this, "Por favor busque un paciente primero.", 
                "Paciente no cargado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Actualizar datos básicos
            pacienteActual.setNombreCompleto(txtNombreCompleto.getText());
            pacienteActual.setContacto(txtContacto.getText());
            pacienteActual.setEdad(Integer.parseInt(txtEdad.getText()));
            pacienteActual.setGeneroNacimiento((String) cmbGeneroNacimiento.getSelectedItem());
            pacienteActual.setFechaNacimiento(txtFechaNacimiento.getText());
            pacienteActual.setDireccion(txtDireccion.getText());
            pacienteActual.setTipoDocumento((String) cmbTipoDoc.getSelectedItem());
            pacienteActual.setLugarNacimiento(txtLugarNacimiento.getText());
            
            // Actualizar datos específicos de paciente
            pacienteActual.setEstadoCivil(txtEstadoCivil.getText());
            pacienteActual.setHijos(Integer.parseInt(txtHijos.getText()));
            pacienteActual.setEps(txtEps.getText());
            
            // Registrar en auditoría
            AuditoriaSistema.registrarAccion("Sistema", "Actualización de Paciente: " + pacienteActual.getNombreCompleto());
            
            JOptionPane.showMessageDialog(this, "Paciente actualizado correctamente.", 
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            // Limpiar formulario
            limpiarFormulario();
            habilitarPanel(false);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Verifique que todos los campos numéricos sean válidos.", 
                "Error de validación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarFormulario() {
        txtDocumentoIdentidad.setText("");
        txtNombreCompleto.setText("");
        txtContacto.setText("");
        txtEdad.setText("");
        txtFechaNacimiento.setText("");
        txtDireccion.setText("");
        txtLugarNacimiento.setText("");
        txtEstadoCivil.setText("");
        txtHijos.setText("");
        txtEps.setText("");
        cmbGeneroNacimiento.setSelectedIndex(0);
        cmbTipoDoc.setSelectedIndex(0);
        pacienteActual = null;
    }

    // Declaración de variables
    private javax.swing.JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9, jLabel10, jLabel11, jLabel12;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JTextField txtDocumentoIdentidad, txtNombreCompleto, txtContacto, txtEdad, txtFechaNacimiento, txtDireccion, txtLugarNacimiento, txtEstadoCivil, txtHijos, txtEps;
    private javax.swing.JComboBox<String> cmbGeneroNacimiento, cmbTipoDoc;
    private javax.swing.JButton btnBuscar, btnGuardarPaciente, btnCancelar;
}
