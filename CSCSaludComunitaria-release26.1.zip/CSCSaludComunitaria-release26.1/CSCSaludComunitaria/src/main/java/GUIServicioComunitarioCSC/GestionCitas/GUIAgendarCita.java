/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUIServicioComunitarioCSC.GestionCitas;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

import Model.Citas.Consultorio;
import Model.Persona.Medico;
import Servicios.GestionCitas.GestionCitas;

/**
 *
 * @author danie
 */
public class GUIAgendarCita extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIAgendarCita.class.getName());

    /**
     * Creates new form GUIAgendarCita
     */
    public GUIAgendarCita() {
        initComponents();
        cargarConsultorios();
        cargarMedicos();
        btnAgendar.addActionListener(this::btnAgendarActionPerformed);
    }

    private void cargarConsultorios() {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        List<Consultorio> consultorios = GestionCitas.obtenerConsultorios();
        if (consultorios.isEmpty()) {
            model.addElement("No hay consultorios disponibles");
        } else {
            for (Consultorio consultorio : consultorios) {
                model.addElement(consultorio.getId() + " - " + consultorio.getNombre() + " (" + consultorio.getEstado() + ")");
            }
        }
        cmbConsultorios.setModel(model);
    }

    private void cargarMedicos() {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        List<Medico> medicos = GestionCitas.obtenerMedicos();
        if (medicos.isEmpty()) {
            model.addElement("No hay médicos registrados");
        } else {
            for (Medico medico : medicos) {
                model.addElement(medico.getDocumentoIdentidad() + " - " + medico.getNombreCompleto() + " [" + medico.getEspecialidad() + "]");
            }
        }
        cmbAsignarMedico.setModel(model);
    }

    private void btnAgendarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String consultorioItem = (String) cmbConsultorios.getSelectedItem();
            if (consultorioItem == null || consultorioItem.startsWith("No hay")) {
                JOptionPane.showMessageDialog(this, "Seleccione un consultorio válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String medicoItem = (String) cmbAsignarMedico.getSelectedItem();
            if (medicoItem == null || medicoItem.startsWith("No hay")) {
                JOptionPane.showMessageDialog(this, "Seleccione un médico válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int documentoPaciente = Integer.parseInt(txtDocumento.getText().trim());
            int idConsultorio = Integer.parseInt(consultorioItem.split(" ")[0]);
            int idMedico = Integer.parseInt(medicoItem.split(" ")[0]);

            String fechaTexto = txtFechaCita.getText().trim();
            if (fechaTexto.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese la fecha de la cita.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            LocalDate fecha;
            try {
                fecha = LocalDate.parse(fechaTexto);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Fecha inválida. Use el formato YYYY-MM-DD.", "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String horaTexto = txtHoraCita.getText().trim();
            if (horaTexto.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese la hora de la cita.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            LocalTime hora;
            try {
                hora = LocalTime.parse(horaTexto);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Hora inválida. Use el formato HH:MM.", "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String motivo = txtMotivoCita.getText().trim();

            if (motivo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese el motivo de la cita.", "Información incompleta", JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean success = GestionCitas.agendarCita(idConsultorio, documentoPaciente, idMedico, fecha, hora, motivo);
            if (success) {
                JOptionPane.showMessageDialog(this, "Cita agendada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                txtDocumento.setText("");
                txtFechaCita.setText("");
                txtHoraCita.setText("");
                txtMotivoCita.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "No fue posible agendar la cita. Verifique los datos ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El documento del paciente, el consultorio y el médico deben ser valores numéricos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Ocurrió un error al agendar la cita.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cmbConsultorios = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txtDocumento = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        cmbAsignarMedico = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txtFechaCita = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtHoraCita = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtMotivoCita = new javax.swing.JTextArea();
        btnAgendar = new javax.swing.JButton();

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("AGENDAMIENTO CITAS");

        jLabel1.setText("Consultorios Disponibles: ");

        jLabel3.setText("Documento Identificación del paciente:");

        jLabel4.setText("Asignar Medico:");

        jLabel5.setText("Ingrese fecha (YYYY-MM-DD):");

        jLabel6.setText("Ingrese hora (HH:MM):");

        jLabel7.setText("Ingrese motivo de la cita:");

        txtMotivoCita.setColumns(20);
        txtMotivoCita.setRows(5);
        jScrollPane1.setViewportView(txtMotivoCita);

        btnAgendar.setText("Agendar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel2))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cmbAsignarMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDocumento))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbConsultorios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(83, 83, 83))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtFechaCita, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtHoraCita, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(btnAgendar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 24, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbConsultorios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbAsignarMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtFechaCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtHoraCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(31, 31, 31)
                        .addComponent(btnAgendar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GUIAgendarCita().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgendar;
    private javax.swing.JComboBox<String> cmbAsignarMedico;
    private javax.swing.JComboBox<String> cmbConsultorios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtDocumento;
    private javax.swing.JTextField txtFechaCita;
    private javax.swing.JTextField txtHoraCita;
    private javax.swing.JTextArea txtMotivoCita;
    // End of variables declaration//GEN-END:variables
}
