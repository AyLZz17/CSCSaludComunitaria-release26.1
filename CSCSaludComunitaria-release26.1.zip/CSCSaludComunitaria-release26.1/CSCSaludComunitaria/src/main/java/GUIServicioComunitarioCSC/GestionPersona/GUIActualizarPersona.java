/*
 * GUI para Actualizar Personas por Tipo
 * Este módulo permite seleccionar el tipo de persona (Médico, Enfermero, Administrador, Paciente)
 * y abre la interfaz correspondiente para actualizar sus datos.
 */
package GUIServicioComunitarioCSC.GestionPersona;

import javax.swing.JOptionPane;

import GUIServicioComunitarioCSC.ActualizarPersona.GUIActualizarAdministrador;
import GUIServicioComunitarioCSC.ActualizarPersona.GUIActualizarEnfermero;
import GUIServicioComunitarioCSC.ActualizarPersona.GUIActualizarMedico;
import GUIServicioComunitarioCSC.ActualizarPersona.GUIActualizarPaciente;

/**
 * GUI principal para actualizar personas según su tipo.
 * Permite seleccionar el tipo de persona y abre el formulario de actualización correspondiente.
 * 
 * @author CSC Salud Comunitaria
 */
public class GUIActualizarPersona extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIActualizarPersona.class.getName());

    /**
     * Constructor que inicializa la interfaz gráfica
     */
    public GUIActualizarPersona() {
        initComponents();
    }

    /**
     * Inicializa los componentes de la interfaz gráfica
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cmbTipoPersona = new javax.swing.JComboBox<>();
        btnActualizarPersona = new javax.swing.JButton();

        setTitle("Actualizar Persona por Tipo");
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);

        jLabel1.setText("Seleccione el tipo de Persona que desea Actualizar: ");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("ACTUALIZAR PERSONA");

        cmbTipoPersona.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Seleccione --", "MEDICO", "ENFERMERO", "ADMINISTRADOR", "PACIENTE" }));

        btnActualizarPersona.setText("ABRIR FORMULARIO DE ACTUALIZACIÓN");
        btnActualizarPersona.addActionListener(this::btnActualizarPersonaActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbTipoPersona, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(btnActualizarPersona)))
                .addContainerGap(100, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbTipoPersona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(btnActualizarPersona)
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Evento del botón para abrir el formulario de actualización según el tipo seleccionado
     */
    private void btnActualizarPersonaActionPerformed(java.awt.event.ActionEvent evt) {
        String tipoSeleccionado = (String) cmbTipoPersona.getSelectedItem();
        
        if (tipoSeleccionado == null || tipoSeleccionado.equals("-- Seleccione --")) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione un tipo de persona.", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        switch (tipoSeleccionado) {
            case "MEDICO":
                java.awt.EventQueue.invokeLater(() -> new GUIActualizarMedico().setVisible(true));
                break;
            case "ENFERMERO":
                java.awt.EventQueue.invokeLater(() -> new GUIActualizarEnfermero().setVisible(true));
                break;
            case "ADMINISTRADOR":
                java.awt.EventQueue.invokeLater(() -> new GUIActualizarAdministrador().setVisible(true));
                break;
            case "PACIENTE":
                java.awt.EventQueue.invokeLater(() -> new GUIActualizarPaciente().setVisible(true));
                break;
            default:
                JOptionPane.showMessageDialog(this, "Tipo de persona no reconocido.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método principal para iniciar la aplicación
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new GUIActualizarPersona().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarPersona;
    private javax.swing.JComboBox<String> cmbTipoPersona;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
