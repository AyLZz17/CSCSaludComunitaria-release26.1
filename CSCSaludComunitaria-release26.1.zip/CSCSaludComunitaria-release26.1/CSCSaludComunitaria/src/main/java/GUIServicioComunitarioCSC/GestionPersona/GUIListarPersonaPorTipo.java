/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUIServicioComunitarioCSC.GestionPersona;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Model.Persona.Persona;
import Servicios.GestionPersona.RegistrosPersonas;

/**
 * JFrame para listar personas por tipo en CSC Salud Comunitaria.
 * Permite seleccionar un tipo de persona y ver los resultados en una tabla editable.
 *
 * @author danie
 */
public class GUIListarPersonaPorTipo extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUIListarPersonaPorTipo.class.getName());

    /**
     * Creates new form GUIListarPersonaPorTipo
     */
    public GUIListarPersonaPorTipo() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cmbTipoPersona = new javax.swing.JComboBox<>();
        btnListar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPersonas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Listar Personas por Tipo");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Listar Personas por Tipo");

        cmbTipoPersona.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Seleccione --", "TODAS", "MEDICO", "ENFERMERO", "ADMINISTRADOR", "PACIENTE" }));

        btnListar.setText("Listar");
        btnListar.addActionListener(this::btnListarActionPerformed);

        tblPersonas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tipo", "Nombre", "Documento", "Edad", "Género", "Dirección"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblPersonas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(cmbTipoPersona, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 142, Short.MAX_VALUE)
                        .addComponent(btnListar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbTipoPersona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnListar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>                        

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {
        String tipoSeleccionado = (String) cmbTipoPersona.getSelectedItem();
        if (tipoSeleccionado == null || "-- Seleccione --".equals(tipoSeleccionado)) {
            JOptionPane.showMessageDialog(this,
                    "Por favor seleccione un tipo de persona para listar.",
                    "Tipo no seleccionado",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<Persona> personas = RegistrosPersonas.getPersonasPorTipo(tipoSeleccionado);
        DefaultTableModel model = (DefaultTableModel) tblPersonas.getModel();
        model.setRowCount(0);

        if (personas.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No se encontraron personas del tipo seleccionado.",
                    "Listado vacío",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        for (Persona persona : personas) {
            model.addRow(new Object[] {
                persona.getClass().getSimpleName(),
                persona.getNombreCompleto(),
                persona.getDocumentoIdentidad(),
                persona.getEdad(),
                persona.getGeneroNacimiento(),
                persona.getDireccion()
            });
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new GUIListarPersonaPorTipo().setVisible(true));
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnListar;
    private javax.swing.JComboBox<String> cmbTipoPersona;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblPersonas;
    // End of variables declaration                   
}
