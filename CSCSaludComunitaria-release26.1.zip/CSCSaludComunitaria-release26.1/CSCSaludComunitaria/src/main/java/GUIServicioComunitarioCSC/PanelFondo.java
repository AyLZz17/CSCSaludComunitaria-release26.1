package GUIServicioComunitarioCSC;

import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class PanelFondo extends JPanel {
    private Image imagen;

    public PanelFondo() {
        imagen = loadImage("/Resources/image/fondo.png");
        if (imagen == null) {
            imagen = loadImage("/img/fondo.png");
        }
        if (imagen == null) {
            imagen = loadImage("/fondo.png");
        }
        if (imagen == null) {
            java.io.File file = new java.io.File("src/main/java/Resources/image/fondo.png");
            if (file.exists()) {
                imagen = new ImageIcon(file.getAbsolutePath()).getImage();
            }
        }
    }

    private Image loadImage(String path) {
        URL recurso = getClass().getResource(path);
        return recurso != null ? new ImageIcon(recurso).getImage() : null;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }
}