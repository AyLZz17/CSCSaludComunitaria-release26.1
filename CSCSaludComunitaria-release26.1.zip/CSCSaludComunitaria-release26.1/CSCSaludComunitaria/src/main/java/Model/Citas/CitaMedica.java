package Model.Citas;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Clase que representa una cita médica en el sistema CSC Salud Comunitaria.
 * Extiende la clase Citas agregando funcionalidad específica para citas médicas,
 * como mostrar detalles y confirmar la cita.
 */
public class CitaMedica extends Citas {

    /**
     * Constructor que inicializa una nueva cita médica con todos los atributos.
     *
     * @param id Identificador único de la cita
     * @param fecha Fecha de la cita
     * @param hora Hora de la cita
     * @param motivo Motivo de la cita
     * @param estado Estado de la cita
     * @param idConsultorio ID del consultorio
     * @param idPaciente ID del paciente
     * @param idMedico ID del médico
     */
    public CitaMedica(int id, LocalDate fecha, LocalTime hora, String motivo, String estado, int idConsultorio,
            int idPaciente, int idMedico) {
        // Llamar al constructor de la superclase Citas
        super(id, fecha, hora, motivo, estado, idConsultorio, idPaciente, idMedico);
    }

    /**
     * Muestra los detalles de la cita médica en consola.
     * Sobrescribe el método de la superclase para mostrar información específica.
     */
    @Override
    public void mostrarCitas() {
        // Imprimir encabezado de la cita médica
        System.out.println("--- CITA MEDICA ---");
        // Mostrar atributos de la cita
        System.out.println("ID: " + getId());
        System.out.println("Fecha: " + getFecha());
        System.out.println("Hora: " + getHora());
        System.out.println("Motivo: " + getMotivo());
        System.out.println("Estado: " + getEstado());
        System.out.println("Consultorio ID: " + getIdConsultorio());
        System.out.println("Paciente ID: " + getIdPaciente());
        System.out.println("Medico ID: " + getIdMedico());
        System.out.println("-------------------");
    }

    /**
     * Confirma la cita médica cambiando su estado a "Confirmada".
     * Sobrescribe el método de la superclase.
     */
    @Override
    public void confirmar() {
        // Cambiar el estado de la cita a confirmada
        setEstado("Confirmada");
    }
}
