package Model.Citas;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Clase abstracta que representa una cita en el sistema CSC Salud Comunitaria.
 * Define los atributos comunes a todas las citas y métodos abstractos que deben
 * ser implementados por las subclases.
 */
public abstract class Citas 
{
    // Atributos de la cita
    private int id; // Identificador único de la cita
    private LocalDate fecha; // Fecha de la cita
    private LocalTime hora; // Hora de la cita
    private String motivo; // Motivo de la cita
    private String estado; // Estado de la cita (ej. Pendiente, Confirmada)
    
    private int idConsultorio; // ID del consultorio asignado
    private int idPaciente; // ID del paciente
    private int idMedico; // ID del médico

    /**
     * Constructor que inicializa una nueva cita con todos los atributos.
     *
     * @param id Identificador único
     * @param fecha Fecha de la cita
     * @param hora Hora de la cita
     * @param motivo Motivo de la cita
     * @param estado Estado de la cita
     * @param idConsultorio ID del consultorio
     * @param idPaciente ID del paciente
     * @param idMedico ID del médico
     */
    public Citas(int id, LocalDate fecha, LocalTime hora, String motivo, String estado, int idConsultorio,
            int idPaciente, int idMedico) {
        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.motivo = motivo;
        this.estado = estado;
        this.idConsultorio = idConsultorio;
        this.idPaciente = idPaciente;
        this.idMedico = idMedico;
    }

    /**
     * Obtiene el ID de la cita.
     *
     * @return el ID
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el ID de la cita.
     *
     * @param id el ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la fecha de la cita.
     *
     * @return la fecha
     */
    public LocalDate getFecha() {
        return fecha;
    }

    /**
     * Establece la fecha de la cita.
     *
     * @param fecha la fecha
     */
    public void setFechas(LocalDate fecha) {
        this.fecha = fecha;
    }

    /**
     * Obtiene la hora de la cita.
     *
     * @return la hora
     */
    public LocalTime getHora() {
        return hora;
    }

    /**
     * Establece la hora de la cita.
     *
     * @param hora la hora
     */
    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    /**
     * Obtiene el motivo de la cita.
     *
     * @return el motivo
     */
    public String getMotivo() {
        return motivo;
    }

    /**
     * Establece el motivo de la cita.
     *
     * @param motivo el motivo
     */
    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    /**
     * Obtiene el estado de la cita.
     *
     * @return el estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado de la cita.
     *
     * @param estado el estado
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene el ID del consultorio.
     *
     * @return el ID del consultorio
     */
    public int getIdConsultorio() {
        return idConsultorio;
    }

    /**
     * Establece el ID del consultorio.
     *
     * @param idConsultorio el ID del consultorio
     */
    public void setIdConsultorio(int idConsultorio) {
        this.idConsultorio = idConsultorio;
    }

    /**
     * Obtiene el ID del paciente.
     *
     * @return el ID del paciente
     */
    public int getIdPaciente() {
        return idPaciente;
    }

    /**
     * Establece el ID del paciente.
     *
     * @param idPaciente el ID del paciente
     */
    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    /**
     * Obtiene el ID del médico.
     *
     * @return el ID del médico
     */
    public int getIdMedico() {
        return idMedico;
    }

    /**
     * Establece el ID del médico.
     *
     * @param idMedico el ID del médico
     */
    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    /**
     * Método para confirmar la cita. Implementación por defecto vacía,
     * debe ser sobrescrito por subclases.
     */
    public void confirmar(){
        // Implementación por defecto vacía
    }
    
    /**
     * Método abstracto para mostrar los detalles de la cita.
     * Debe ser implementado por las subclases.
     */
    public abstract void mostrarCitas();

    
}
