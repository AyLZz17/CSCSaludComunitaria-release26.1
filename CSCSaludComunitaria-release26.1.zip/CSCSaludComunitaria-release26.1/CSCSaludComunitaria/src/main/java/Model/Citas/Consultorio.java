package Model.Citas;

/**
 * Clase abstracta que representa un consultorio en el sistema CSC Salud Comunitaria.
 * Define los atributos comunes a todos los consultorios y un método abstracto
 * para mostrar información.
 */
public abstract class Consultorio 
{
    // Atributos del consultorio
    private int id; // Identificador único del consultorio
    private String nombre; // Nombre del consultorio
    private String estado; // Estado del consultorio (ej. Disponible, Ocupado)

    /**
     * Constructor que inicializa un nuevo consultorio con sus atributos básicos.
     *
     * @param id Identificador único
     * @param nombre Nombre del consultorio
     * @param estado Estado del consultorio
     */
    public Consultorio(int id, String nombre, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.estado = estado;
    }

    /**
     * Obtiene el ID del consultorio.
     *
     * @return el ID
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el ID del consultorio.
     *
     * @param id el ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del consultorio.
     *
     * @return el nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del consultorio.
     *
     * @param nombre el nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el estado del consultorio.
     *
     * @return el estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado del consultorio.
     *
     * @param estado el estado
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Método abstracto para mostrar los detalles del consultorio.
     * Debe ser implementado por las subclases.
     */
    public abstract void mostrarConsultorios();
    
    
}
