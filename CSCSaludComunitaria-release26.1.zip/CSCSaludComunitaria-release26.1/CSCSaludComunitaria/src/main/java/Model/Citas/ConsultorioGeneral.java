package Model.Citas;

/**
 * Clase que representa un consultorio general en el sistema CSC Salud Comunitaria.
 * Extiende la clase Consultorio e implementa el método para mostrar detalles.
 */
public class ConsultorioGeneral extends Consultorio {

    /**
     * Constructor que inicializa un nuevo consultorio general.
     *
     * @param id Identificador único
     * @param nombre Nombre del consultorio
     * @param estado Estado del consultorio
     */
    public ConsultorioGeneral(int id, String nombre, String estado) {
        // Llamar al constructor de la superclase Consultorio
        super(id, nombre, estado);
    }

    /**
     * Muestra los detalles del consultorio general en consola.
     * Sobrescribe el método abstracto de la superclase.
     */
    @Override
    public void mostrarConsultorios() {
        // Imprimir encabezado del consultorio
        System.out.println("--- CONSULTORIO ---");
        // Mostrar atributos del consultorio
        System.out.println("ID: " + getId());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Estado: " + getEstado());
        System.out.println("-------------------");
    }
}
