package Model.HistoriaClinica;

/**
 * Clase que representa una entrada médica en la historia clínica de un paciente.
 * Contiene información sobre fecha, diagnóstico, tratamiento y el médico que la registró.
 */
public class EntradaMedica {
    // Atributos de la entrada médica
    private String fecha; // Fecha de la entrada médica
    private String diagnostico; // Diagnóstico realizado
    private String tratamiento; // Tratamiento prescrito
    private int idMedico; // ID del médico que registró la entrada

    /**
     * Constructor que inicializa una nueva entrada médica.
     *
     * @param fecha Fecha de la entrada
     * @param diagnostico Diagnóstico médico
     * @param tratamiento Tratamiento aplicado
     * @param idMedico ID del médico
     */
    public EntradaMedica(String fecha, String diagnostico, String tratamiento, int idMedico) {
        this.fecha = fecha;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.idMedico = idMedico;
    }

    /**
     * Obtiene la fecha de la entrada médica.
     *
     * @return la fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * Obtiene el diagnóstico de la entrada médica.
     *
     * @return el diagnóstico
     */
    public String getDiagnostico() {
        return diagnostico;
    }

    /**
     * Obtiene el tratamiento de la entrada médica.
     *
     * @return el tratamiento
     */
    public String getTratamiento() {
        return tratamiento;
    }

    /**
     * Obtiene el ID del médico que registró la entrada.
     *
     * @return el ID del médico
     */
    public int getIdMedico() {
        return idMedico;
    }
}