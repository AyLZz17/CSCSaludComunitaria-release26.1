package Model.HistoriaClinica;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa la historia clínica de un paciente en el sistema CSC Salud Comunitaria.
 * Contiene el ID de la historia, ID del paciente y una lista de entradas médicas.
 */
public class HistoriaClinica {
    // Atributos de la historia clínica
    private int idHistoria; // Identificador único de la historia clínica
    private int idPaciente; // ID del paciente asociado
    private List<EntradaMedica> entradas; // Lista de entradas médicas

    /**
     * Constructor que inicializa una nueva historia clínica.
     *
     * @param idHistoria ID único de la historia
     * @param idPaciente ID del paciente
     */
    public HistoriaClinica(int idHistoria, int idPaciente) {
        this.idHistoria = idHistoria;
        this.idPaciente = idPaciente;
        // Inicializar la lista de entradas
        this.entradas = new ArrayList<>();
    }
    
    /**
     * Agrega una nueva entrada médica a la historia clínica.
     *
     * @param entrada La entrada médica a agregar
     */
    public void agregarEntrada(EntradaMedica entrada) {
        // Agregar la entrada a la lista
        this.entradas.add(entrada);
    }

    /**
     * Obtiene el ID de la historia clínica.
     *
     * @return el ID de la historia
     */
    public int getIdHistoria() {
        return idHistoria;
    }

    /**
     * Obtiene el ID del paciente.
     *
     * @return el ID del paciente
     */
    public int getIdPaciente() {
        return idPaciente;
    }

    /**
     * Obtiene la lista de entradas médicas.
     *
     * @return la lista de entradas
     */
    public List<EntradaMedica> getEntradas() {
        return entradas;
    }
}