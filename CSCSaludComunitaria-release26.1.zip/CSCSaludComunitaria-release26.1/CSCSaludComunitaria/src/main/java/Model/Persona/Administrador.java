package Model.Persona;

/**
 * Clase que representa a un administrador en el sistema CSC Salud Comunitaria.
 * Extiende la clase Trabajador agregando información específica del departamento
 * al que pertenece el administrador.
 */
public class Administrador extends Trabajador
{
    // Atributo específico del administrador
    private String departamento; // Departamento al que pertenece el administrador

    /**
     * Constructor que inicializa un nuevo administrador con todos los atributos,
     * incluyendo los heredados de Trabajador y el departamento específico.
     *
     * @param contacto Información de contacto
     * @param documentoIdentidad Documento de identidad
     * @param edad Edad
     * @param generoNacimiento Género de nacimiento
     * @param nombreCompleto Nombre completo
     * @param tipoDocumento Tipo de documento
     * @param fechaNacimiento Fecha de nacimiento
     * @param direccion Dirección
     * @param lugarNacimiento Lugar de nacimiento
     * @param cargo Cargo laboral
     * @param codigoTrabajador Código del trabajador
     * @param salario Salario
     * @param estadoContrato Estado del contrato
     * @param horario Horario de trabajo
     * @param horarioRotativo Horario rotativo
     * @param turno Turno asignado
     * @param departamento Departamento del administrador
     */
    public Administrador(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, 
    String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, 
    String horario, String horarioRotativo, String turno, String departamento) 
    {
        // Llamar al constructor de la superclase Trabajador
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento, 
        cargo, codigoTrabajador, salario, estadoContrato, horario, horarioRotativo, turno);
        this.departamento = departamento;
    }

    /**
     * Obtiene el departamento del administrador.
     *
     * @return el departamento
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * Establece el departamento del administrador.
     *
     * @param departamento el departamento
     */
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
}
