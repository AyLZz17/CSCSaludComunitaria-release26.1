package Model.Persona;

/**
 * Clase que representa a un enfermero en el sistema CSC Salud Comunitaria.
 * Extiende la clase Trabajador agregando información específica del médico
 * asignado al enfermero.
 */
public class Enfermero extends Trabajador
{

    // Atributo específico del enfermero
    private String medicoAsignado; // Nombre del médico asignado al enfermero

    /**
     * Constructor que inicializa un nuevo enfermero con todos los atributos,
     * incluyendo los heredados de Trabajador y el médico asignado.
     *
     * @param contacto Información de contacto
     * @param documentoIdentidad Documento de identidad
     * @param edad Edad
     * @param generoNacimiento Género de nacimiento
     * @param nombreCompleto Nombre completo
     * @param tipoDocumento Tipo de documento
     * @param fechaNacimiento Fecha de nacimiento
     * @param direccion Dirección
     * @param lugarNacimiento Lugar de nacimiento
     * @param cargo Cargo laboral
     * @param codigoTrabajador Código del trabajador
     * @param salario Salario
     * @param estadoContrato Estado del contrato
     * @param horario Horario de trabajo
     * @param horarioRotativo Horario rotativo
     * @param turno Turno asignado
     * @param medicoAsignado Médico asignado al enfermero
     */
    public Enfermero(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, 
    String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, 
    String horario, String horarioRotativo, String turno, String medicoAsignado) 
    {
        // Llamar al constructor de la superclase Trabajador
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento, 
        cargo, codigoTrabajador, salario, estadoContrato, horario, horarioRotativo, turno);
        this.medicoAsignado = medicoAsignado;
    }

    /**
     * Obtiene el médico asignado al enfermero.
     *
     * @return el médico asignado
     */
    public String getMedicoAsignado() {
        return medicoAsignado;
    }

    /**
     * Establece el médico asignado al enfermero.
     *
     * @param medicoAsignado el médico asignado
     */
    public void setMedicoAsignado(String medicoAsignado) {
        this.medicoAsignado = medicoAsignado;
    }

}
