package Model.Persona;

/**
 * Clase que representa a un médico en el sistema CSC Salud Comunitaria.
 * Extiende la clase Trabajador agregando información específica como especialidad,
 * estado de la licencia médica y consultorio asignado.
 */
public class Medico extends Trabajador
{
    // Atributos específicos del médico
    private String especialidad; // Especialidad médica
    private String estadoLicencia; // Estado de la licencia médica
    private String consultorio; // Consultorio asignado

    /**
     * Constructor que inicializa un nuevo médico con todos los atributos,
     * incluyendo los heredados de Trabajador y los específicos del médico.
     *
     * @param contacto Información de contacto
     * @param documentoIdentidad Documento de identidad
     * @param edad Edad
     * @param generoNacimiento Género de nacimiento
     * @param nombreCompleto Nombre completo
     * @param tipoDocumento Tipo de documento
     * @param fechaNacimiento Fecha de nacimiento
     * @param direccion Dirección
     * @param lugarNacimiento Lugar de nacimiento
     * @param cargo Cargo laboral
     * @param codigoTrabajador Código del trabajador
     * @param salario Salario
     * @param estadoContrato Estado del contrato
     * @param horario Horario de trabajo
     * @param horarioRotativo Horario rotativo
     * @param turno Turno asignado
     * @param especialidad Especialidad médica
     * @param estadoLicencia Estado de la licencia
     * @param consultorio Consultorio asignado
     */
    public Medico(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, 
    String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, 
    String horario, String horarioRotativo, String turno, String especialidad, String estadoLicencia, String consultorio) 
    {
        // Llamar al constructor de la superclase Trabajador
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento, 
        cargo, codigoTrabajador, salario, estadoContrato, horario, horarioRotativo, turno);
        this.especialidad = especialidad;
        this.estadoLicencia = estadoLicencia;
        this.consultorio = consultorio;
    }

    /**
     * Obtiene la especialidad del médico.
     *
     * @return la especialidad
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * Establece la especialidad del médico.
     *
     * @param especialidad la especialidad
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    /**
     * Obtiene el estado de la licencia médica.
     *
     * @return el estado de la licencia
     */
    public String getEstadoLicencia() {
        return estadoLicencia;
    }

    /**
     * Establece el estado de la licencia médica.
     *
     * @param estadoLicencia el estado de la licencia
     */
    public void setEstadoLicencia(String estadoLicencia) {
        this.estadoLicencia = estadoLicencia;
    }

    /**
     * Obtiene el consultorio asignado al médico.
     *
     * @return el consultorio
     */
    public String getConsultorio() {
        return consultorio;
    }

    /**
     * Establece el consultorio asignado al médico.
     *
     * @param consultorio el consultorio
     */
    public void setConsultorio(String consultorio) {
        this.consultorio = consultorio;
    }




}
