package Model.Persona;

/**
 * Clase que representa a un paciente en el sistema CSC Salud Comunitaria.
 * Extiende la clase Persona agregando información específica como estado civil,
 * número de hijos y entidad prestadora de salud (EPS).
 */
public class Paciente extends Persona
{

    // Atributos específicos del paciente
    private String estadoCivil; // Estado civil del paciente
    private int hijos; // Número de hijos
    private String eps; // Entidad prestadora de salud

    /**
     * Constructor que inicializa un nuevo paciente con todos los atributos,
     * incluyendo los heredados de Persona y los específicos del paciente.
     *
     * @param contacto Información de contacto
     * @param documentoIdentidad Documento de identidad
     * @param edad Edad
     * @param generoNacimiento Género de nacimiento
     * @param nombreCompleto Nombre completo
     * @param tipoDocumento Tipo de documento
     * @param fechaNacimiento Fecha de nacimiento
     * @param direccion Dirección
     * @param lugarNacimiento Lugar de nacimiento
     * @param estadoCivil Estado civil
     * @param hijos Número de hijos
     * @param eps Entidad prestadora de salud
     */
    public Paciente(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, String fechaNacimiento, 
    String direccion, String lugarNacimiento, String estadoCivil, int hijos, String eps) 
    {
        // Llamar al constructor de la superclase Persona
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento);
        this.estadoCivil = estadoCivil;
        this.hijos = hijos;
        this.eps = eps;
    }

    /**
     * Obtiene el estado civil del paciente.
     *
     * @return el estado civil
     */
    public String getEstadoCivil() {
        return estadoCivil;
    }

    /**
     * Establece el estado civil del paciente.
     *
     * @param estadoCivil el estado civil
     */
    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    /**
     * Obtiene el número de hijos del paciente.
     *
     * @return el número de hijos
     */
    public int getHijos() {
        return hijos;
    }

    /**
     * Establece el número de hijos del paciente.
     *
     * @param hijos el número de hijos
     */
    public void setHijos(int hijos) {
        this.hijos = hijos;
    }

    /**
     * Obtiene la entidad prestadora de salud (EPS) del paciente.
     *
     * @return la EPS
     */
    public String getEps() {
        return eps;
    }

    /**
     * Establece la entidad prestadora de salud (EPS) del paciente.
     *
     * @param eps la EPS
     */
    public void setEps(String eps) {
        this.eps = eps;
    }

}
