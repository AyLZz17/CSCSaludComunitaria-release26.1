/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Persona;

/**
 * Clase base que representa a una persona en el sistema CSC Salud Comunitaria.
 * Contiene información básica como documento de identidad, nombre, contacto, etc.
 * Es la superclase para clases como Paciente, Medico, Enfermero, Administrador.
 *
 * @author AylZz
 */
public class Persona 
{
    // Atributos de la persona
    private int documentoIdentidad; // Llave primaria para identificar a la persona
    private String tipoDocumento; // Tipo de documento (ej. CC, TI, etc.)
    private String nombreCompleto; // Nombre completo de la persona
    private String contacto; // Información de contacto (teléfono o correo)
    private int edad; // Edad de la persona
    private String generoNacimiento; // Género de nacimiento (H ó M)
    private String fechaNacimiento; // Fecha de nacimiento en formato string
    private String direccion; // Dirección de residencia
    private String lugarNacimiento; // Lugar de nacimiento

    /**
     * Constructor que inicializa una nueva instancia de Persona con todos los atributos.
     *
     * @param contacto Información de contacto de la persona
     * @param documentoIdentidad Número del documento de identidad
     * @param edad Edad de la persona
     * @param generoNacimiento Género de nacimiento
     * @param nombreCompleto Nombre completo
     * @param tipoDocumento Tipo de documento
     * @param fechaNacimiento Fecha de nacimiento
     * @param direccion Dirección
     * @param lugarNacimiento Lugar de nacimiento
     */
    public Persona(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, String fechaNacimiento, String direccion, String lugarNacimiento) {
        this.contacto = contacto;
        this.documentoIdentidad = documentoIdentidad;
        this.edad = edad;
        this.generoNacimiento = generoNacimiento;
        this.nombreCompleto = nombreCompleto;
        this.tipoDocumento = tipoDocumento;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
        this.lugarNacimiento = lugarNacimiento;
    }

    /**
     * Obtiene el documento de identidad de la persona.
     *
     * @return el número del documento de identidad
     */
    public int getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    /**
     * Establece el documento de identidad de la persona.
     *
     * @param documentoIdentidad el número del documento de identidad
     */
    public void setDocumentoIdentidad(int documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    /**
     * Obtiene el tipo de documento de la persona.
     *
     * @return el tipo de documento
     */
    public String getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * Establece el tipo de documento de la persona.
     *
     * @param tipoDocumento el tipo de documento
     */
    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    /**
     * Obtiene el nombre completo de la persona.
     *
     * @return el nombre completo
     */
    public String getNombreCompleto() {
        return nombreCompleto;
    }

    /**
     * Establece el nombre completo de la persona.
     *
     * @param nombreCompleto el nombre completo
     */
    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    /**
     * Obtiene la información de contacto de la persona.
     *
     * @return el contacto (teléfono o correo)
     */
    public String getContacto() {
        return contacto;
    }

    /**
     * Establece la información de contacto de la persona.
     *
     * @param contacto el contacto
     */
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    /**
     * Obtiene la edad de la persona.
     *
     * @return la edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Establece la edad de la persona.
     *
     * @param edad la edad
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Obtiene el género de nacimiento de la persona.
     *
     * @return el género de nacimiento
     */
    public String getGeneroNacimiento() {
        return generoNacimiento;
    }

    /**
     * Establece el género de nacimiento de la persona.
     *
     * @param generoNacimiento el género de nacimiento
     */
    public void setGeneroNacimiento(String generoNacimiento) {
        this.generoNacimiento = generoNacimiento;
    }

    
    /**
     * Obtiene la fecha de nacimiento de la persona.
     *
     * @return la fecha de nacimiento
     */
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Establece la fecha de nacimiento de la persona.
     *
     * @param fechaNacimiento la fecha de nacimiento
     */
    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Obtiene la dirección de la persona.
     *
     * @return la dirección
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección de la persona.
     *
     * @param direccion la dirección
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene el lugar de nacimiento de la persona.
     *
     * @return el lugar de nacimiento
     */
    public String getLugarNacimiento() {
        return lugarNacimiento;
    }

    /**
     * Establece el lugar de nacimiento de la persona.
     *
     * @param lugarNacimiento el lugar de nacimiento
     */
    public void setLugarNacimiento(String lugarNacimiento) {
        this.lugarNacimiento = lugarNacimiento;
    }


}
