package Model.Persona;

/**
 * Clase que representa a un trabajador en el sistema CSC Salud Comunitaria.
 * Extiende la clase Persona agregando información laboral como cargo, salario,
 * horario y estado de contrato. Es la superclase para Medico, Enfermero y Administrador.
 */
public class Trabajador extends Persona
{

    // Atributos específicos del trabajador
    private String cargo; // Cargo laboral del trabajador
    private int codigoTrabajador; // Código único del trabajador
    private double salario; // Salario del trabajador
    private String estadoContrato; // Estado del contrato (Activo, Inactivo, etc.)
    private String horario; // Horario de trabajo
    private String horarioRotativo; // Indica si el horario es rotativo (Sí o No)
    private String turno; // Turno asignado (Diurno, Nocturno o Mixto)

    /**
     * Constructor que inicializa un nuevo trabajador con todos los atributos,
     * incluyendo los heredados de Persona y los específicos del trabajador.
     *
     * @param contacto Información de contacto
     * @param documentoIdentidad Documento de identidad
     * @param edad Edad
     * @param generoNacimiento Género de nacimiento
     * @param nombreCompleto Nombre completo
     * @param tipoDocumento Tipo de documento
     * @param fechaNacimiento Fecha de nacimiento
     * @param direccion Dirección
     * @param lugarNacimiento Lugar de nacimiento
     * @param cargo Cargo laboral
     * @param codigoTrabajador Código único del trabajador
     * @param salario Salario
     * @param estadoContrato Estado del contrato
     * @param horario Horario de trabajo
     * @param horarioRotativo Si el horario es rotativo
     * @param turno Turno asignado
     */
    public Trabajador(String contacto, int documentoIdentidad, int edad, String generoNacimiento, String nombreCompleto, String tipoDocumento, String fechaNacimiento, String direccion, String lugarNacimiento, String cargo, int codigoTrabajador, double salario, String estadoContrato, String horario, String horarioRotativo, String turno) {
        // Llamar al constructor de la superclase Persona
        super(contacto, documentoIdentidad, edad, generoNacimiento, nombreCompleto, tipoDocumento, fechaNacimiento, direccion, lugarNacimiento);
        this.cargo = cargo;
        this.codigoTrabajador = codigoTrabajador;
        this.salario = salario;
        this.estadoContrato = estadoContrato;
        this.horario = horario;
        this.horarioRotativo = horarioRotativo;
        this.turno = turno;
    }

    /**
     * Obtiene el cargo del trabajador.
     *
     * @return el cargo
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * Establece el cargo del trabajador.
     *
     * @param cargo el cargo
     */
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    /**
     * Obtiene el código del trabajador.
     *
     * @return el código del trabajador
     */
    public int getCodigoTrabajador() {
        return codigoTrabajador;
    }

    /**
     * Establece el código del trabajador.
     *
     * @param codigoTrabajador el código del trabajador
     */
    public void setCodigoTrabajador(int codigoTrabajador) {
        this.codigoTrabajador = codigoTrabajador;
    }

    /**
     * Obtiene el salario del trabajador.
     *
     * @return el salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * Establece el salario del trabajador.
     *
     * @param salario el salario
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }

    /**
     * Obtiene el estado del contrato del trabajador.
     *
     * @return el estado del contrato
     */
    public String getEstadoContrato() {
        return estadoContrato;
    }

    /**
     * Establece el estado del contrato del trabajador.
     *
     * @param estadoContrato el estado del contrato
     */
    public void setEstadoContrato(String estadoContrato) {
        this.estadoContrato = estadoContrato;
    }

    /**
     * Obtiene el horario del trabajador.
     *
     * @return el horario
     */
    public String getHorario() {
        return horario;
    }

    /**
     * Establece el horario del trabajador.
     *
     * @param horario el horario
     */
    public void setHorario(String horario) {
        this.horario = horario;
    }

    /**
     * Obtiene si el horario es rotativo.
     *
     * @return si es rotativo
     */
    public String getHorarioRotativo() {
        return horarioRotativo;
    }

    /**
     * Establece si el horario es rotativo.
     *
     * @param horarioRotativo si es rotativo
     */
    public void setHorarioRotativo(String horarioRotativo) {
        this.horarioRotativo = horarioRotativo;
    }

    /**
     * Obtiene el turno del trabajador.
     *
     * @return el turno
     */
    public String getTurno() {
        return turno;
    }

    /**
     * Establece el turno del trabajador.
     *
     * @param turno el turno
     */
    public void setTurno(String turno) {
        this.turno = turno;
    }



}
