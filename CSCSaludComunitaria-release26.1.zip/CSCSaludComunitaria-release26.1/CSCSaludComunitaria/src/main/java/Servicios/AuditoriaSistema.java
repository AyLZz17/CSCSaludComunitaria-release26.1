package Servicios;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Servicio de auditoría del sistema CSC Salud Comunitaria.
 * Registra acciones realizadas por usuarios en memoria para seguimiento y control.
 */
public class AuditoriaSistema {
    // Mapa que almacena los logs de auditoría con ID único
    private static Map<Integer, String> logs = new HashMap<>();
    // Contador para asignar IDs únicos a los eventos
    private static int contadorEvento = 1;

    /**
     * Registra una acción realizada por un usuario en el sistema de auditoría.
     * Crea un registro con timestamp, usuario y acción, y lo almacena en memoria.
     *
     * @param usuario el identificador del usuario que realizó la acción
     * @param accion la descripción de la acción realizada
     */
    public static void registrarAccion(String usuario, String accion) {
        // Crear el registro con timestamp actual
        String registro = "[" + LocalDateTime.now() + "] Usuario: " + usuario + " - Accion: " + accion;
        // Almacenar el registro con ID incremental
        logs.put(contadorEvento++, registro);
    }

    /**
     * Muestra todos los logs de auditoría almacenados en memoria.
     * Imprime en consola los eventos registrados con sus IDs.
     */
    public static void mostrarLogs() {
        // Imprimir encabezado de la auditoría
        System.out.println("\n--- AUDITORÍA DE EVENTOS EN MEMORIA ---");
        // Iterar y mostrar cada log
        logs.forEach((id, msg) -> System.out.println("ID " + id + ": " + msg));
    }
}
