package Servicios.GestionCitas;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import Model.Citas.CitaMedica;
import Model.Citas.Consultorio;
import Model.Citas.ConsultorioGeneral;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.RegistrosPersonas;
import Servicios.Notificaciones;
import Utils.UtilServices;

public class GestionCitas {
    private static final List<CitaMedica> citas = new ArrayList<>();
    private static final List<Consultorio> consultorios = new ArrayList<>();
    

    static {
        inicializarConsultoriosDemo();
    }

    public static void inicializarConsultoriosDemo() {
        if (!consultorios.isEmpty()) {
            return;
        }

        consultorios.add(new ConsultorioGeneral(1, "Consultorio 101", "Disponible"));
        consultorios.add(new ConsultorioGeneral(2, "Consultorio 202", "Ocupado"));
        consultorios.add(new ConsultorioGeneral(3, "Consultorio 303", "Disponible"));
    }

    public static java.util.List<Consultorio> obtenerConsultorios() {
        return new java.util.ArrayList<>(consultorios);
    }

    public static java.util.List<Medico> obtenerMedicos() {
        return new java.util.ArrayList<>(RegistrosPersonas.getMedicos());
    }

    public static java.util.List<CitaMedica> obtenerCitas() {
        return new java.util.ArrayList<>(citas);
    }

    public static boolean agendarCita(int idConsultorio, int idPaciente, int idMedico, LocalDate fecha, LocalTime hora,
            String motivo) {
        if (!encontrarConsultorio(idConsultorio)) {
            return false;
        }
        if (!validarPaciente(idPaciente)) {
            return false;
        }
        if (!validarMedico(idMedico)) {
            return false;
        }

        int idCita = citas.size() + 1;
        CitaMedica cita = new CitaMedica(idCita, fecha, hora, motivo, "Pendiente", idConsultorio, idPaciente, idMedico);
        citas.add(cita);

        Notificaciones.agregarNotificacion("Nueva cita agendada: " + cita.getId());
        AuditoriaSistema.registrarAccion("Sistema", "Cita agendada: " + cita.getId());
        return true;
    }

    public static boolean confirmarCita(int idCita) {
        for (CitaMedica cita : citas) {
            if (cita.getId() == idCita) {
                cita.confirmar();
                Notificaciones.agregarNotificacion("Cita confirmada: " + idCita);
                AuditoriaSistema.registrarAccion("Sistema", "Cita confirmada: " + idCita);
                return true;
            }
        }
        return false;
    }

    public static String obtenerNombrePacientePorId(int idPaciente) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), idPaciente);
        return persona != null ? persona.getNombreCompleto() : "Paciente no encontrado";
    }

    public static String obtenerNombreMedicoPorId(int idMedico) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), idMedico);
        return persona != null ? persona.getNombreCompleto() : "Médico no encontrado";
    }

    public static String obtenerNombreConsultorioPorId(int idConsultorio) {
        return consultorios.stream()
                .filter(c -> c.getId() == idConsultorio)
                .map(Consultorio::getNombre)
                .findFirst()
                .orElse("Consultorio no encontrado");
    }

    public static void inicializarCitasDemo() {
        if (!citas.isEmpty() || consultorios.isEmpty()) {
            return;
        }

        List<Persona> pacientes = new ArrayList<>();
        for (Persona persona : RegistrosPersonas.getPersonas()) {
            if (persona instanceof Paciente) {
                pacientes.add(persona);
            }
        }

        List<Medico> medicos = RegistrosPersonas.getMedicos();
        if (pacientes.isEmpty() || medicos.isEmpty()) {
            return;
        }

        int[] consultorioIds = consultorios.stream().mapToInt(Consultorio::getId).toArray();
        java.time.LocalDate baseFecha = java.time.LocalDate.now().plusDays(1);

        for (int i = 0; i < pacientes.size(); i++) {
            Persona paciente = pacientes.get(i);
            Medico medico = medicos.get(i % medicos.size());
            int consultorioId = consultorioIds[i % consultorioIds.length];
            String estado = (i % 2 == 0) ? "Confirmada" : "Pendiente";

            CitaMedica cita = new CitaMedica(
                    citas.size() + 1,
                    baseFecha.plusDays(i),
                    java.time.LocalTime.of(8 + (i % 8), 0),
                    "Consulta de seguimiento",
                    estado,
                    consultorioId,
                    paciente.getDocumentoIdentidad(),
                    medico.getDocumentoIdentidad());
            citas.add(cita);
        }
    }

    private static boolean validarPaciente(int documento) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), documento);
        return persona instanceof Paciente;
    }

    private static boolean validarMedico(int documento) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), documento);
        return persona instanceof Medico;
    }

    private static boolean encontrarConsultorio(int idConsultorio) {
        return consultorios.stream().anyMatch(c -> c.getId() == idConsultorio);
    }
}
