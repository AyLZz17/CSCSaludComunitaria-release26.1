package Servicios.GestionHistoriaClinica;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import Model.HistoriaClinica.EntradaMedica;
import Model.HistoriaClinica.HistoriaClinica;
import Model.Persona.Paciente;
import Model.Persona.Persona;
import Servicios.AuditoriaSistema;
import Servicios.GestionPersona.RegistrosPersonas;
import Servicios.Notificaciones;
import Utils.UtilServices;

public class GestionHistoriaClinica {
    private static final Map<Integer, HistoriaClinica> historias = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int siguienteHistoria = 1;

    public static void inicializarHistoriasDemo() {
        if (!historias.isEmpty()) {
            return;
        }

        // Crea historias de muestra para algunos pacientes existentes.
        if (UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), 201) instanceof Paciente) {
            HistoriaClinica historia1 = new HistoriaClinica(siguienteHistoria++, 201);
            historia1.agregarEntrada(new EntradaMedica("2026-05-01", "Control general", "Continuar con dieta balanceada", 101)); // Assuming doctor ID 101
            historias.put(201, historia1);
        }

        if (UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), 202) instanceof Paciente) {
            HistoriaClinica historia2 = new HistoriaClinica(siguienteHistoria++, 202);
            historia2.agregarEntrada(new EntradaMedica("2026-05-02", "Dolor de cabeza", "Paracetamol 500mg cada 8 horas", 102)); // Assuming doctor ID 102
            historias.put(202, historia2);
        }
    }

    

    public static boolean existePaciente(int idPaciente) {
        return UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), idPaciente) instanceof Paciente;
    }

    public static String obtenerNombrePaciente(int idPaciente) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), idPaciente);
        if (persona instanceof Paciente) {
            return persona.getNombreCompleto();
        }
        return null;
    }

    public static String obtenerNombreMedico(int idMedico) {
        Persona persona = UtilServices.buscarPersonaPorDocumento(RegistrosPersonas.getPersonas(), idMedico);
        if (persona != null) {
            return persona.getNombreCompleto();
        }
        return "Médico desconocido";
    }

    public static HistoriaClinica obtenerHistoriaPorPaciente(int idPaciente) {
        if (!existePaciente(idPaciente)) {
            return null;
        }
        return historias.get(idPaciente);
    }

    public static String generarResumenHistoriaClinica(int idPaciente) {
        HistoriaClinica historia = obtenerHistoriaPorPaciente(idPaciente);
        if (historia == null) {
            return null;
        }

        StringBuilder resumen = new StringBuilder();
        resumen.append("HISTORIA CLÍNICA\n");
        resumen.append("================\n\n");
        resumen.append("ID Paciente: ").append(idPaciente).append("\n\n");

        if (historia.getEntradas().isEmpty()) {
            resumen.append("No hay entradas registradas para este paciente.");
            return resumen.toString();
        }

        resumen.append("ENTRADAS MÉDICAS:\n");
        resumen.append("=================\n\n");

        for (int i = 0; i < historia.getEntradas().size(); i++) {
            EntradaMedica entrada = historia.getEntradas().get(i);
            resumen.append("Entrada #").append(i + 1).append("\n");
            resumen.append("Fecha: ").append(entrada.getFecha()).append("\n");
            resumen.append("Médico: ").append(obtenerNombreMedico(entrada.getIdMedico())).append("\n");
            resumen.append("Diagnóstico: ").append(entrada.getDiagnostico()).append("\n");
            resumen.append("Tratamiento: ").append(entrada.getTratamiento()).append("\n");
            resumen.append("----------------------------------------\n\n");
        }

        return resumen.toString();
    }

    public static boolean registrarEntradaMedica(int idPaciente, String fecha, String diagnostico, String tratamiento, int idMedico) {
        if (!existePaciente(idPaciente)) {
            return false;
        }

        HistoriaClinica historia = historias.get(idPaciente);
        if (historia == null) {
            historia = new HistoriaClinica(siguienteHistoria++, idPaciente);
            historias.put(idPaciente, historia);
        }

        historia.agregarEntrada(new EntradaMedica(fecha, diagnostico, tratamiento, idMedico));
        Notificaciones.agregarNotificacion("Nueva entrada en historia clinica del paciente " + idPaciente);
        AuditoriaSistema.registrarAccion("Sistema", "Entrada medica registrada para paciente " + idPaciente);
        return true;
    }

    
}
