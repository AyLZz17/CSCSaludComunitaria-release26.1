package Servicios.GestionPersona;

import java.util.List;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;

/**
 * Servicio para actualizar personas según su tipo.
 * Valida el tipo de persona y proporciona métodos para buscar y actualizar datos específicos.
 * 
 * @author CSC Salud Comunitaria
 */
public class ActualizarPersonaPorTipo {
    
    /**
     * Busca una persona por documento y valida su tipo.
     * 
     * @param documentoIdentidad Número de documento de la persona
     * @param tipoEsperado Clase esperada (Paciente.class, Medico.class, etc.)
     * @return La persona encontrada o null si no existe o no coincide el tipo
     */
    public static Persona buscarPersonaPorDocumento(int documentoIdentidad, Class<?> tipoEsperado) {
        List<Persona> personas = RegistrosPersonas.getPersonas();
        
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documentoIdentidad && tipoEsperado.isInstance(p)) {
                return p;
            }
        }
        return null;
    }
    
    /**
     * Busca una persona paciente por documento.
     * 
     * @param documentoIdentidad Número de documento
     * @return El Paciente encontrado o null
     */
    public static Paciente buscarPaciente(int documentoIdentidad) {
        return (Paciente) buscarPersonaPorDocumento(documentoIdentidad, Paciente.class);
    }
    
    /**
     * Busca una persona médico por documento.
     * 
     * @param documentoIdentidad Número de documento
     * @return El Medico encontrado o null
     */
    public static Medico buscarMedico(int documentoIdentidad) {
        return (Medico) buscarPersonaPorDocumento(documentoIdentidad, Medico.class);
    }
    
    /**
     * Busca una persona enfermero por documento.
     * 
     * @param documentoIdentidad Número de documento
     * @return El Enfermero encontrado o null
     */
    public static Enfermero buscarEnfermero(int documentoIdentidad) {
        return (Enfermero) buscarPersonaPorDocumento(documentoIdentidad, Enfermero.class);
    }
    
    /**
     * Busca una persona administrador por documento.
     * 
     * @param documentoIdentidad Número de documento
     * @return El Administrador encontrado o null
     */
    public static Administrador buscarAdministrador(int documentoIdentidad) {
        return (Administrador) buscarPersonaPorDocumento(documentoIdentidad, Administrador.class);
    }
    
    /**
     * Verifica si una persona con el documento existe.
     * 
     * @param documentoIdentidad Número de documento
     * @return true si existe, false si no
     */
    public static boolean existePersona(int documentoIdentidad) {
        List<Persona> personas = RegistrosPersonas.getPersonas();
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documentoIdentidad) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Obtiene el tipo de persona por su documento.
     * 
     * @param documentoIdentidad Número de documento
     * @return String con el tipo ("Paciente", "Medico", "Enfermero", "Administrador") o null
     */
    public static String obtenerTipoPersona(int documentoIdentidad) {
        List<Persona> personas = RegistrosPersonas.getPersonas();
        
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documentoIdentidad) {
                if (p instanceof Medico) return "MEDICO";
                else if (p instanceof Enfermero) return "ENFERMERO";
                else if (p instanceof Administrador) return "ADMINISTRADOR";
                else if (p instanceof Paciente) return "PACIENTE";
                else return "PERSONA";
            }
        }
        return null;
    }
}
