package Servicios.GestionPersona;

import java.util.List;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;

/**
 * Servicio para buscar personas registradas en el sistema CSC Salud Comunitaria.
 * Permite buscar por número de documento de identidad.
 */
public class BuscarPersona {

    /**
     * Busca una persona por su número de documento de identidad en la lista proporcionada.
     *
     * @param personas La lista de personas donde buscar
     * @param documento El número de documento de identidad
     * @return La persona encontrada o null si no existe
     */
    public static Persona buscarPorDocumento(List<Persona> personas, int documento) {
        if (personas == null) {
            return null;
        }
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documento) {
                return p;
            }
        }
        return null;
    }

    /**
     * Genera el texto con la información de una persona para mostrar en un diálogo.
     *
     * @param persona La persona encontrada
     * @return Texto detallado de la persona
     */
    public static String generarTextoPersona(Persona persona) {
        if (persona == null) {
            return "";
        }

        String tipo;
        if (persona instanceof Medico) {
            tipo = "Medico";
        } else if (persona instanceof Paciente) {
            tipo = "Paciente";
        } else if (persona instanceof Enfermero) {
            tipo = "Enfermero";
        } else if (persona instanceof Administrador) {
            tipo = "Administrador";
        } else {
            tipo = "Persona";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Tipo: ").append(tipo).append("\n");
        sb.append("Nombre: ").append(persona.getNombreCompleto()).append("\n");
        sb.append("Documento: ").append(persona.getDocumentoIdentidad())
          .append(" (").append(persona.getTipoDocumento()).append(")\n");
        sb.append("Edad: ").append(persona.getEdad()).append("\n");
        sb.append("Contacto: ").append(persona.getContacto()).append("\n");
        sb.append("Direccion: ").append(persona.getDireccion());
        return sb.toString();
    }
}
