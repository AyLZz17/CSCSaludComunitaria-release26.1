package Servicios.GestionPersona;

import java.util.List;

import Model.Persona.Persona;

public class EliminarPersona {

    /**
     * Elimina una persona por su número de documento de identidad.
     *
     * @param documento El número de documento de identidad
     * @return true si la persona fue eliminada, false si no se encontró
     */
    public static boolean eliminarPersonaPorDocumento(int documento) {
        List<Persona> personas = RegistrosPersonas.getPersonas();
        Persona personaAEliminar = null;
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documento) {
                personaAEliminar = p;
                break;
            }
        }
        if (personaAEliminar != null) {
            return personas.remove(personaAEliminar);
        }
        return false;
    }
}