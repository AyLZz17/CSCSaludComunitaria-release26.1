package Servicios.GestionPersona;

import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;

public class MostrarPersona {

    public static void mostrarMedicos() {
        System.out.println("\n==========================================================================================================");
        System.out.println("                                 LISTA DETALLADA DE MÉDICOS");
        System.out.println("==========================================================================================================");
        boolean hayMedicos = false;
        for (Persona p : RegistrosPersonas.getPersonas()) {
            if (p instanceof Medico) {
                Medico m = (Medico) p;
                System.out.printf("ID: %-10d | Nombre: %-18s | Especialidad: %-15s | Consultorio: %-12s | Salario: %-10.2f\n", 
                    m.getDocumentoIdentidad(), m.getNombreCompleto(), m.getEspecialidad(), m.getConsultorio(), m.getSalario());
                System.out.println("   -> Contacto: " + m.getContacto() + " | Horario: " + m.getHorario() + " | Licencia: " + m.getEstadoLicencia());
                System.out.println("----------------------------------------------------------------------------------------------------------");
                hayMedicos = true;
            }
        }
        if (!hayMedicos) System.out.println("No hay médicos registrados.");
    }

    public static void mostrarPacientes() {
        System.out.println("\n==========================================================================================================");
        System.out.println("                                 LISTA DETALLADA DE PACIENTES");
        System.out.println("==========================================================================================================");
        boolean hayPacientes = false;
        for (Persona p : RegistrosPersonas.getPersonas()) {
            if (p instanceof Paciente) {
                Paciente pac = (Paciente) p;
                System.out.printf("ID: %-10d | Nombre: %-18s | Edad: %-3d | EPS: %-12s | Estado Civil: %-10s\n", 
                    pac.getDocumentoIdentidad(), pac.getNombreCompleto(), pac.getEdad(), pac.getEps(), pac.getEstadoCivil());
                System.out.println("   -> Dirección: " + pac.getDireccion() + " | Hijos: " + pac.getHijos() + " | Origen: " + pac.getLugarNacimiento());
                System.out.println("----------------------------------------------------------------------------------------------------------");
                hayPacientes = true;
            }
        }
        if (!hayPacientes) System.out.println("No hay pacientes registrados.");
    }

    public static void mostrarEnfermeros() {
        System.out.println("\n==========================================================================================================");
        System.out.println("                                 LISTA DETALLADA DE ENFERMEROS");
        System.out.println("==========================================================================================================");
        boolean hayEnfermeros = false;
        for (Persona p : RegistrosPersonas.getPersonas()) {
            if (p instanceof Enfermero) {
                Enfermero e = (Enfermero) p;
                System.out.printf("ID: %-10d | Nombre: %-18s | Cargo: %-15s | Turno: %-10s | Médico Asig: %-15s\n", 
                    e.getDocumentoIdentidad(), e.getNombreCompleto(), e.getCargo(), e.getTurno(), e.getMedicoAsignado());
                System.out.println("   -> Salario: " + e.getSalario() + " | Horario Rotativo: " + e.getHorarioRotativo() + " | Estado: " + e.getEstadoContrato());
                System.out.println("----------------------------------------------------------------------------------------------------------");
                hayEnfermeros = true;
            }
        }
        if (!hayEnfermeros) System.out.println("No hay enfermeros registrados.");
    }

    public static void mostrarAdministradores() {
        System.out.println("\n==========================================================================================================");
        System.out.println("                               LISTA DETALLADA DE ADMINISTRADORES");
        System.out.println("==========================================================================================================");
        boolean hayAdmin = false;
        for (Persona p : RegistrosPersonas.getPersonas()) {
            if (p instanceof Administrador) {
                Administrador a = (Administrador) p;
                System.out.printf("ID: %-10d | Nombre: %-18s | Departamento: %-20s | Cargo: %-15s\n", 
                    a.getDocumentoIdentidad(), a.getNombreCompleto(), a.getDepartamento(), a.getCargo());
                System.out.println("   -> Salario: " + a.getSalario() + " | Contacto: " + a.getContacto() + " | Ubicación: " + a.getDireccion());
                System.out.println("----------------------------------------------------------------------------------------------------------");
                hayAdmin = true;
            }
        }
        if (!hayAdmin) System.out.println("No hay administradores registrados.");
    }
}
