package Servicios.GestionPersona;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import GUIServicioComunitarioCSC.GUIPrincipal;
import Model.Persona.Administrador;
import Model.Persona.Enfermero;
import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;


/**
 * Servicio para gestionar el registro de personas en el sistema CSC Salud Comunitaria.
 * Permite registrar pacientes, médicos, enfermeros y administradores, y obtener listas filtradas.
 */
public class RegistrosPersonas 
{
    // Lista estática que almacena todas las personas registradas
    private static final List<Persona> personas = new ArrayList<>();

    /**
     * Obtiene la lista completa de personas registradas.
     *
     * @return lista de todas las personas
     */
    public static List<Persona> getPersonas() {
        return personas;
    }

    /**
     * Elimina una persona por su número de documento de identidad.
     *
     * @param documento El número de documento de identidad
     * @return true si la persona fue eliminada, false si no se encontró
     */
    public static boolean eliminarPersonaPorDocumento(int documento) {
        Persona personaAEliminar = null;
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documento) {
                personaAEliminar = p;
                break;
            }
        }
        if (personaAEliminar != null) {
            return personas.remove(personaAEliminar);
        }
        return false;
    }

    /**
     * Obtiene una lista filtrada solo con los médicos registrados.
     *
     * @return lista de médicos
     */
    public static List<Medico> getMedicos() {
        List<Medico> medicos = new ArrayList<>();
        // Iterar sobre todas las personas y filtrar médicos
        for (Persona p : personas) {
            if (p instanceof Medico) {
                medicos.add((Medico) p);
            }
        }
        return medicos;
    }

    /**
     * Registra un nuevo paciente en el sistema.
     *
     * @param paciente El objeto Paciente a registrar
     * @return true si el registro fue exitoso, false en caso de error
     */
    public static boolean registrarPaciente(Paciente paciente) 
    {
        try 
        {
            // Crear una nueva instancia de Paciente con los datos proporcionados
            Paciente pac = new Paciente(paciente.getContacto(), paciente.getDocumentoIdentidad(), paciente.getEdad(), paciente.getGeneroNacimiento(), 
            paciente.getNombreCompleto(), paciente.getTipoDocumento(), paciente.getFechaNacimiento(), paciente.getDireccion(), paciente.getLugarNacimiento(),
            paciente.getEstadoCivil(), paciente.getHijos(), paciente.getEps());
            // Agregar a la lista de personas
            personas.add(pac);

        } catch (Exception ex) {
            // Registrar error en el log
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;

    }

    /**
     * Registra un nuevo médico en el sistema.
     *
     * @param medico El objeto Medico a registrar
     * @return true si el registro fue exitoso, false en caso de error
     */
    public static boolean registrarMedico(Medico medico) 
    {
        try 
        {
            // Crear una nueva instancia de Medico con cargo fijo "Medico"
            Medico med = new Medico(medico.getContacto(), medico.getDocumentoIdentidad(), medico.getEdad(), medico.getGeneroNacimiento(),
            medico.getNombreCompleto(), medico.getTipoDocumento(), medico.getFechaNacimiento(), medico.getDireccion(), medico.getLugarNacimiento(), 
            "Medico", medico.getCodigoTrabajador(), medico.getSalario(), medico.getEstadoContrato(), medico.getHorario(), medico.getHorarioRotativo(), medico.getTurno(), medico.getEspecialidad(), medico.getEstadoLicencia(), medico.getConsultorio());

            // Agregar a la lista de personas
            personas.add(med);

        } catch (Exception ex) {
            // Registrar error en el log
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
        
    }

    /**
     * Registra un nuevo enfermero en el sistema.
     *
     * @param enfermero El objeto Enfermero a registrar
     * @return true si el registro fue exitoso, false en caso de error
     */
    public static boolean registrarEnfermero(Enfermero enfermero) 
    {
        try 
        {
            // Crear una nueva instancia de Enfermero con cargo fijo "Enfermero"
            Enfermero enf = new Enfermero(enfermero.getContacto(), enfermero.getDocumentoIdentidad(), enfermero.getEdad(), enfermero.getGeneroNacimiento(),
            enfermero.getNombreCompleto(), enfermero.getTipoDocumento(), enfermero.getFechaNacimiento(), enfermero.getDireccion(), enfermero.getLugarNacimiento(), 
            "Enfermero", enfermero.getCodigoTrabajador(), enfermero.getSalario(), enfermero.getEstadoContrato(), 
            enfermero.getHorario(), enfermero.getHorarioRotativo(), enfermero.getTurno(), enfermero.getMedicoAsignado());

            // Agregar a la lista de personas
            personas.add(enf);

        } catch (Exception ex) {
            // Registrar error en el log
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
        
    }

    /**
     * Registra un nuevo administrador en el sistema.
     *
     * @param administrador El objeto Administrador a registrar
     * @return true si el registro fue exitoso, false en caso de error
     */
    public static boolean registrarAdministrador(Administrador administrador) 
    {
        try 
        {
            // Crear una nueva instancia de Administrador con cargo fijo "Administrador"
            Administrador admin = new Administrador(administrador.getContacto(), administrador.getDocumentoIdentidad(), administrador.getEdad(), administrador.getGeneroNacimiento(),
            administrador.getNombreCompleto(), administrador.getTipoDocumento(), administrador.getFechaNacimiento(), administrador.getDireccion(), administrador.getLugarNacimiento(), 
            "Administrador", administrador.getCodigoTrabajador(), administrador.getSalario(), administrador.getEstadoContrato(), administrador.getHorario(), administrador.getHorarioRotativo(), administrador.getTurno(), administrador.getDepartamento());

            // Agregar a la lista de personas
            personas.add(admin);

        } catch (Exception ex) {
            // Registrar error en el log
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
        
    }

    /**
     * Obtiene una lista de personas filtrada por tipo.
     *
     * @param tipoPersona Nombre del tipo de persona (TODAS, MEDICO, ENFERMERO, ADMINISTRADOR, PACIENTE)
     * @return lista de personas del tipo solicitado
     */
    public static List<Persona> getPersonasPorTipo(String tipoPersona) {
        if (tipoPersona == null) {
            return new ArrayList<>(personas);
        }

        if ("TODAS".equalsIgnoreCase(tipoPersona)) {
            return new ArrayList<>(personas);
        }

        List<Persona> resultado = new ArrayList<>();
        switch (tipoPersona.toUpperCase()) {
            case "MEDICO":
                for (Persona p : personas) {
                    if (p instanceof Medico) {
                        resultado.add(p);
                    }
                }
                break;
            case "ENFERMERO":
                for (Persona p : personas) {
                    if (p instanceof Enfermero) {
                        resultado.add(p);
                    }
                }
                break;
            case "ADMINISTRADOR":
                for (Persona p : personas) {
                    if (p instanceof Administrador) {
                        resultado.add(p);
                    }
                }
                break;
            case "PACIENTE":
                for (Persona p : personas) {
                    if (p instanceof Paciente) {
                        resultado.add(p);
                    }
                }
                break;
            default:
                break;
        }
        return resultado;
    }

}

