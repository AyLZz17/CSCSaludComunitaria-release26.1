package Servicios;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Servicio de notificaciones del sistema CSC Salud Comunitaria.
 * Gestiona una cola de notificaciones para procesar mensajes en orden FIFO.
 */
public class Notificaciones {

    // Cola de notificaciones usando LinkedList para orden FIFO
    private static Queue<String> colaNotificaciones = new LinkedList<>();

    /**
     * Agrega una nueva notificación a la cola.
     *
     * @param mensaje El mensaje de la notificación a agregar
     */
    public static void agregarNotificacion(String mensaje) {
        // Agregar al final de la cola
        colaNotificaciones.add(mensaje);
    }

    /**
     * Elimina la primera notificación de la cola (la más antigua).
     * Muestra un mensaje si no hay notificaciones.
     */
    public static void eliminarPrimeraNotificacion() {
        if (colaNotificaciones.isEmpty()) {
            // Mensaje si la cola está vacía
            System.out.println("No hay notificaciones pendientes para eliminar.");
        } else {
            // Extraer y eliminar el elemento del frente
            String eliminada = colaNotificaciones.poll(); 
            System.out.println("Se ha eliminado la notificacion mas antigua: " + eliminada);
        }
    }

    /**
     * Procesa todas las notificaciones en la cola, imprimiéndolas y eliminándolas.
     * Muestra un mensaje si la cola está vacía.
     */
    public static void procesarNotificaciones() {
        if (colaNotificaciones.isEmpty()) {
            // Mensaje si no hay notificaciones
            System.out.println("Buzon vacio.");
            return;
        }
        // Encabezado de la lista
        System.out.println("--- Lista de Notificaciones ---");
        // Procesar todas las notificaciones
        while (!colaNotificaciones.isEmpty()) {
            System.out.println("Procesada: " + colaNotificaciones.poll());
        }
    }
}