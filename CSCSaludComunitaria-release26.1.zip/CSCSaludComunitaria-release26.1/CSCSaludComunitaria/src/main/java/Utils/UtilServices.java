package Utils;

import java.util.List;

import Model.Persona.Medico;
import Model.Persona.Paciente;
import Model.Persona.Persona;

public class UtilServices 
{

    public static boolean validarExistenciaMedico(List<Persona> personas, String nombreMedico)
    {
        if (nombreMedico == null || personas == null) return false;
            
        for (Persona p : personas) 
        {
            if (p instanceof Medico && p.getNombreCompleto().equalsIgnoreCase(nombreMedico)) 
            {
                    return true;
            }
        }
        return false;
    }

    public static Persona buscarPersonaPorDocumento(List<Persona> personas, int documento)
    {
        if (personas == null) return null;
        for (Persona p : personas) {
            if (p.getDocumentoIdentidad() == documento) {
                return p;
            }
        }
        return null;
    }

    public static boolean existePaciente(List<Persona> personas, int documento) {
        Persona persona = buscarPersonaPorDocumento(personas, documento);
        return persona instanceof Paciente;
    }

    public static boolean existeMedico(List<Persona> personas, int documento) {
        Persona persona = buscarPersonaPorDocumento(personas, documento);
        return persona instanceof Medico;
    }
}
