package com.mycompany.cscsaludcomunitaria;

// Importaciones necesarias para la interfaz gráfica y servicios de auditoría
import GUIServicioComunitarioCSC.GUIPrincipal;
import Servicios.AuditoriaSistema;

/**
 * Clase principal del sistema CSC Salud Comunitaria.
 * Esta clase contiene el método main que inicia la aplicación.
 */
public class CSCSaludComunitaria {

    /**
     * Método principal que inicia la ejecución del programa.
     * Crea la interfaz gráfica principal, la hace visible, carga datos de demostración
     * y registra acciones en el sistema de auditoría.
     *
     * @param args argumentos de línea de comandos (no utilizados en este caso)
     */
    public static void main(String[] args) {
        // Crear una instancia de la interfaz gráfica principal
        GUIPrincipal gui = new GUIPrincipal();
        
        // Hacer visible la interfaz gráfica para que el usuario pueda interactuar
        gui.setVisible(true);
        
        // Cargar datos de demostración para simular el funcionamiento del sistema
        Utils.SimulacionDemo.cargarDatosDemo();
        
        // Registrar en el sistema de auditoría el inicio del sistema
        AuditoriaSistema.registrarAccion("AyLZz", "Inicio del sistema ");
        
        // Registrar en el sistema de auditoría la carga de datos demo
        AuditoriaSistema.registrarAccion("AyLZz", "Carga de datos demo");
    }

}